import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    TOKEN = os.getenv('DISCORD_TOKEN')
    DESK_CHANNEL_ID = int(os.getenv('DESK_CHANNEL_ID', 1444289919014014996))
    DISCORD_CHANNEL_ID = int(os.getenv('DISCORD_CHANNEL_ID', 1403086426710741003))
    ROLE_ID = int(os.getenv('DISCORD_ROLE_ID', 0))
    GEMINI_KEY = os.getenv('GEMINI_KEY')
    GROQ_API_KEY = os.getenv('GROQ_API_KEY')
    PORT = int(os.environ.get("PORT", 5000))
    
    # Desk.ms API
    DESK_OPERATOR_KEY = os.getenv('DESK_OPERATOR_KEY')
    DESK_ENVIRONMENT_KEY = os.getenv('DESK_ENVIRONMENT_KEY')
    DESK_API_URL = os.getenv('DESK_API_URL', 'https://api.desk.ms')

    FILES = {
        "feriados": "feriados.json",
        "config": "config.json",
        "pokedex": "pokedex.json"
    }

    DEFAULT_HOLIDAYS = {
        "01/01": "Confraternizacao Universal",
        "21/04": "Tiradentes",
        "01/05": "Dia do Trabalho",
        "07/09": "Independencia",
        "12/10": "Nossa Senhora Aparecida",
        "02/11": "Finados",
        "15/11": "Proclamacao da Republica",
        "25/12": "Natal"
    }

    DEFAULT_CONFIG = {"saida_hoje": "18:00"}

    BOT_PERSONALITY = """Voce e o assistente do time NextCompany. Seja prestativo, divertido e objetivo. 
Use linguagem informal brasileira. Seja breve nas respostas quando possivel.
Voce pode usar expressoes como 'bora', 'show', 'beleza', 'tranquilo'.
Se perguntarem sobre voce, diga que e o bot da NextCompany.

IMPORTANTE - MEMORIA DO CANAL:
- Voce tem historico das conversas recentes do canal
- SEMPRE lembre dos nomes de quem falou com voce (as pessoas estao listadas antes das perguntas)
- Se alguem pergunta sobre outra pessoa, use o historico para saber o que aquela pessoa disse
- Seja especifico: se Icaro disse que eh Rocky Balboa, lembre disso quando alguem perguntar sobre Icaro
- Lembre dos detalhes: nomes, profissoes, personagens, hobbies que as pessoas mencionaram"""
