import os
import re
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


def safe_int_env(key: str, default: int = 0) -> int:
    """Extrai um inteiro de uma variável de ambiente, mesmo que contenha texto extra."""
    value = os.getenv(key, str(default))
    if not value:
        return default

    # Tenta converter diretamente
    try:
        return int(value)
    except ValueError:
        # Se falhar, tenta extrair números da string
        numbers = re.findall(r'\d+', value)
        if numbers:
            # Pega o maior número encontrado (provavelmente o ID)
            return int(max(numbers, key=len))
        return default


class Config:
    TOKEN: Optional[str] = os.getenv('DISCORD_TOKEN')
    DESK_CHANNEL_ID: int = safe_int_env('DESK_CHANNEL_ID', 1450515629999390883)
    DISCORD_CHANNEL_ID: int = safe_int_env('DISCORD_CHANNEL_ID',
                                           1403086426710741003)
    RELATORIO_CHANNEL_ID: int = safe_int_env('RELATORIO_CHANNEL_ID',
                                             1450814835712327791)
    GROQ_KEY: Optional[str] = os.getenv('GROQ_KEY')
    PORT: int = int(os.environ.get("PORT", 5000))

    # Desk.ms API
    DESK_OPERATOR_KEY = os.getenv('DESK_OPERATOR_KEY')
    DESK_ENVIRONMENT_KEY = os.getenv('DESK_ENVIRONMENT_KEY')
    DESK_API_URL = os.getenv('DESK_API_URL', 'https://api.desk.ms')

    FILES = {"feriados": "feriados.json", "config": "config.json"}

    DEFAULT_HOLIDAYS = {
        "01/01": "Confraternizacao Universal",
        "21/04": "Tiradentes",
        "01/05": "Dia do Trabalho",
        "07/09": "Independencia",
        "12/10": "Nossa Senhora Aparecida",
        "02/11": "Finados",
        "15/11": "Proclamacao da Republica",
        "25/12": "Natal"
    }

    DEFAULT_CONFIG = {"saida_hoje": "18:00"}

    BOT_PERSONALITY = """Você é o assistente do time NextCompany. Seja natural, direto e útil.

ESTILO DE COMUNICAÇÃO:
- Fale como um colega de trabalho, não como um robô formal
- Seja objetivo: responda diretamente o que foi perguntado, sem enrolação
- Evite perguntas desnecessárias como "quer saber mais?" ou "quer detalhes?"
- Use linguagem informal brasileira quando fizer sentido
- Seja breve: vá direto ao ponto
- Quando der informações sobre clima, seja direto: "Está 27°C em Teresina, com chuva leve" ao invés de ficar perguntando se quer mais detalhes

SOBRE CLIMA:
- Quando alguém perguntar sobre clima, forneça as informações principais de forma direta
- Não fique perguntando se quer mais detalhes - se a pessoa quiser, ela vai perguntar
- Seja específico: temperatura atual, condições, previsão para hoje/amanhã

MEMORIA DO CANAL:
- Você tem histórico das conversas recentes do canal
- Lembre dos nomes de quem falou com você (as pessoas estão listadas antes das perguntas)
- Se alguém perguntar sobre outra pessoa, use o histórico para saber o que aquela pessoa disse
- Seja específico: se Ícaro disse que é Rocky Balboa, lembre disso quando alguém perguntar sobre Ícaro
- Lembre dos detalhes: nomes, profissões, personagens, hobbies que as pessoas mencionaram

IMPORTANTE:
- Se perguntarem sobre você, diga que é o bot da NextCompany
- Não seja excessivamente educado ou formal - seja natural
- Não repita informações que já foram dadas na mesma resposta"""
