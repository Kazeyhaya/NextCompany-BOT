from datetime import datetime, timedelta
from html import unescape
import json
import logging
import re
import ssl
from typing import Any, Dict, List, Optional, Tuple

import aiohttp
import certifi
import discord
from discord import app_commands
from discord.ext import commands

from ..config import Config

logger = logging.getLogger(__name__)


class DeskCog(commands.Cog):
    """Integração com Desk.ms (tickets, relatórios e base de conhecimento)."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.base_url = Config.DESK_API_URL.rstrip("/")
        self.operator_key = Config.DESK_OPERATOR_KEY
        self.environment_key = Config.DESK_ENVIRONMENT_KEY

        self.token: Optional[str] = None
        self.token_expires: Optional[datetime] = None
        self._ssl_context: Optional[ssl.SSLContext] = None

        # Cache: {id: "Nome Sobrenome"}
        self.operators_cache: Dict[str, str] = {}
        self.operators_cache_time: Optional[datetime] = None

        if not self.operator_key or not self.environment_key:
            logger.warning(
                "⚠️ Chaves Desk.ms não configuradas! "
                "Configure DESK_OPERATOR_KEY e DESK_ENVIRONMENT_KEY")
        else:
            logger.info("✅ Chaves Desk.ms carregadas com sucesso")

    # --------------------------------------------------------------------- #
    # Infraestrutura / utilitários
    # --------------------------------------------------------------------- #

    def _get_ssl_context(self) -> ssl.SSLContext:
        if self._ssl_context is None:
            self._ssl_context = ssl.create_default_context(
                cafile=certifi.where())
        return self._ssl_context

    async def get_operators_cache(self) -> Dict[str, str]:
        """Busca e cacheia lista de operadores da API (cache de 1h)."""
        now = datetime.now()

        # Retorna cache se válido (menos de 1 hora)
        if (self.operators_cache and self.operators_cache_time
                and (now - self.operators_cache_time).total_seconds() < 3600):
            logger.debug(
                "📋 Usando cache de operadores (%d operadores)",
                len(self.operators_cache),
            )
            return self.operators_cache

        try:
            logger.info("📥 Buscando lista de operadores da API...")
            payload = {
                "Pesquisa": "",  # ou o termo que você quiser
                "Tatual": "",
                "Ativo": "Todos",
                "StatusSLA": "N",
                "Colunas": {
                    "Chave": "on",
                    "CodChamado": "on",
                    "NomePrioridade": "on",
                    "DataCriacao": "on",
                    "HoraCriacao": "on",
                    "NomeStatus": "on",
                    "Assunto": "on",
                    "NomeUsuario": "on",
                    "SobrenomeUsuario": "on",
                    "NomeOperador": "on",
                    "SobrenomeOperador": "on",
                },
                "Ordem": [{
                    "Coluna": "Chave",
                    "Direcao": "true"
                }],
            }
            response = await self.api_request("POST",
                                              "/Operadores/lista",
                                              json=payload)

            if response and response.get("root"):
                cache: Dict[str, str] = {}
                for op in response.get("root", []):
                    chave = str(op.get("Chave", ""))
                    nome = op.get("Nome", "") or ""
                    sobrenome = op.get("Sobrenome", "") or ""
                    nome_completo = f"{nome} {sobrenome}".strip()

                    if chave and nome_completo:
                        cache[chave] = nome_completo

                self.operators_cache = cache
                self.operators_cache_time = now
                logger.info("✅ Cache de operadores atualizado com %d itens",
                            len(cache))
                return cache

            logger.warning("⚠️ Resposta vazia da API de operadores")
            return self.operators_cache or {}

        except Exception as e:  # pragma: no cover - proteção extra
            logger.error("❌ Erro ao buscar operadores: %s", e)
            return self.operators_cache or {}

    async def resolve_operator_name(self, operator_id: str) -> Optional[str]:
        """Resolve ID do operador para seu nome completo."""
        if not operator_id:
            return None

        cache = await self.get_operators_cache()
        operator_id_str = str(operator_id).strip()

        if operator_id_str in cache:
            logger.debug("✅ Operador %s resolvido: %s", operator_id_str,
                         cache[operator_id_str])
            return cache[operator_id_str]

        logger.warning("⚠️ Operador %s não encontrado no cache",
                       operator_id_str)
        return None

    @staticmethod
    def _limpar_html(texto: str) -> str:
        """Remove tags HTML e normaliza espaços."""
        if not texto:
            return ""
        texto = re.sub(r"<[^>]+>", "", texto)
        texto = unescape(texto)
        texto = re.sub(r"\s+", " ", texto).strip()
        return texto

    def _get_periodo_info(self,
                          periodo: Optional[str] = None
                          ) -> Tuple[str, str, str]:
        """Retorna (data_inicio, data_fim, descricao_periodo) baseado em calendário."""
        from zoneinfo import ZoneInfo

        now = datetime.now(ZoneInfo("America/Sao_Paulo"))

        if not periodo:
            periodo = "semestre"

        periodo_lower = periodo.lower().strip()

        if periodo_lower in [
                "semestre", "últimosemestre", "ultimo_semestre", "6m"
        ]:
            # Semestre atual
            if now.month >= 7:
                data_inicio = now.replace(
                    month=7,
                    day=1,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                descricao = "2º Semestre 2025"
            else:
                data_inicio = now.replace(
                    month=1,
                    day=1,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                descricao = "1º Semestre 2025"
        elif periodo_lower in [
                "trimestre", "últimotrimestre", "ultimo_trimestre", "3m"
        ]:
            # Trimestres: Q1(1-3), Q2(4-6), Q3(7-9), Q4(10-12)
            trimestre = (now.month - 1) // 3 + 1
            mes_inicio = (trimestre - 1) * 3 + 1
            data_inicio = now.replace(
                month=mes_inicio,
                day=1,
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )
            descricao = f"Q{trimestre} 2025"
        elif periodo_lower in [
                "mês", "mes", "meses", "últimomês", "ultimo_mes", "1m"
        ]:
            data_inicio = now.replace(
                day=1,
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )
            descricao = now.strftime("Mês atual (%B)")
        elif periodo_lower in [
                "semana", "últimasemana", "ultima_semana", "7d"
        ]:
            data_inicio = now - timedelta(days=7)
            descricao = "Últimos 7 dias"
        elif periodo_lower in ["hoje", "today", "1d"]:
            data_inicio = now.replace(
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )
            descricao = "Hoje"
        else:
            # Padrão: semestre atual
            if now.month >= 7:
                data_inicio = now.replace(
                    month=7,
                    day=1,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                descricao = "2º Semestre 2025"
            else:
                data_inicio = now.replace(
                    month=1,
                    day=1,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                descricao = "1º Semestre 2025"

        data_inicio_str = data_inicio.strftime("%d/%m/%Y")
        data_fim_str = now.strftime("%d/%m/%Y")
        return data_inicio_str, data_fim_str, descricao

    async def get_auth_token(self, retry_count: int = 0) -> Optional[str]:
        """Obter token de autenticação da API Desk (com cache e retry)."""
        if self.token and self.token_expires and datetime.now(
        ) < self.token_expires:
            logger.debug("🔑 Usando token em cache")
            return self.token

        if not self.operator_key or not self.environment_key:
            logger.error("❌ Chaves de API não configuradas")
            return None

        max_retries = 3

        try:
            url = f"{self.base_url}/Login/autenticar"
            headers = {
                "Authorization": self.operator_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
            payload = {"PublicKey": self.environment_key}

            logger.info("🔑 Autenticando na API Desk: %s", url)
            if self.operator_key:
                logger.debug("Headers: Authorization=***%s",
                             self.operator_key[-8:])

            timeout = aiohttp.ClientTimeout(total=30, connect=10)
            ssl_context = self._get_ssl_context()

            async with self.bot.session.post(
                    url,
                    json=payload,
                    headers=headers,
                    timeout=timeout,
                    ssl=ssl_context,
            ) as resp:
                content_type = resp.headers.get("Content-Type", "")
                text = await resp.text()

                logger.debug("Status: %s, Content-Type: %s", resp.status,
                             content_type)
                logger.debug("Resposta (primeiros 200 chars): %s", text[:200])

                if resp.status == 200:
                    token: Optional[str] = None

                    if "application/json" in content_type:
                        try:
                            data = json.loads(text)
                            if isinstance(data, dict):
                                token = (data.get("access_token")
                                         or data.get("token")
                                         or data.get("accessToken"))
                                if data.get("erro"):
                                    logger.error("❌ API retornou erro: %s",
                                                 data.get("erro"))
                                    return None
                            elif isinstance(data, str):
                                token = data
                        except json.JSONDecodeError:
                            text_clean = text.strip().strip('"')
                            if text_clean and not text_clean.startswith(
                                    "<") and len(text_clean) > 20:
                                token = text_clean
                    else:
                        text_clean = text.strip().strip('"')
                        if text_clean and not text_clean.startswith(
                                "<") and len(text_clean) > 20:
                            token = text_clean

                    if token:
                        self.token = token
                        self.token_expires = datetime.now() + timedelta(
                            hours=1)
                        logger.info(
                            "✅ Token obtido com sucesso! Válido por 1 hora")
                        logger.debug("Token: %s...%s", self.token[:20],
                                     self.token[-8:])
                        return self.token

                    logger.error("❌ Token não encontrado na resposta")
                    logger.error("Content-Type: %s", content_type)
                    logger.error("Resposta: %s", text[:300])
                    return None

                logger.error("❌ Erro ao autenticar: HTTP %s", resp.status)
                logger.error("Content-Type: %s", content_type)
                logger.error("Resposta: %s", text[:300])

                if resp.status in (500, 502, 503,
                                   504) and retry_count < max_retries:
                    import asyncio

                    logger.warning(
                        "⚠️ Tentando novamente... (%d/%d)",
                        retry_count + 1,
                        max_retries,
                    )
                    await asyncio.sleep(2**retry_count)
                    return await self.get_auth_token(retry_count + 1)

                return None

        except aiohttp.ClientSSLError as e:
            logger.error("❌ Erro SSL na conexão: %s", e)
            if retry_count < max_retries:
                import asyncio

                logger.warning(
                    "⚠️ Tentando novamente com SSL... (%d/%d)",
                    retry_count + 1,
                    max_retries,
                )
                await asyncio.sleep(2**retry_count)
                return await self.get_auth_token(retry_count + 1)
            return None

        except aiohttp.ClientConnectorError as e:
            logger.error("❌ Erro de conexão com API Desk: %s", e)
            if retry_count < max_retries:
                import asyncio

                logger.warning(
                    "⚠️ Tentando reconectar... (%d/%d)",
                    retry_count + 1,
                    max_retries,
                )
                await asyncio.sleep(2**retry_count)
                return await self.get_auth_token(retry_count + 1)
            return None

        except aiohttp.ClientError as e:
            logger.error("❌ Erro de cliente HTTP: %s", e)
            return None

        except Exception as e:  # pragma: no cover - fallback
            logger.error("❌ Erro inesperado ao obter token: %s: %s",
                         type(e).__name__, e)
            return None

    async def api_request(
        self,
        method: str,
        endpoint: str,
        retry_count: int = 0,
        **kwargs: Any,
    ) -> Optional[Dict[str, Any]]:
        """Fazer requisição à API do Desk com retry."""
        token = await self.get_auth_token()
        if not token:
            logger.error("❌ Não foi possível obter token de autenticação")
            return None

        max_retries = 3

        try:
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
            headers = {
                "Authorization": token,
                "Content-Type": "application/json",
                "Accept": "application/json",
            }

            logger.info("🔗 Requisição API: %s %s", method, url)

            if "json" in kwargs:
                try:
                    logger.info(
                        "📤 Payload: %s",
                        json.dumps(kwargs["json"], ensure_ascii=False),
                    )
                except Exception:
                    logger.debug("📤 Payload (não serializável para log)")

            timeout = aiohttp.ClientTimeout(total=30, connect=10)
            ssl_context = self._get_ssl_context()

            async with self.bot.session.request(
                    method,
                    url,
                    headers=headers,
                    timeout=timeout,
                    ssl=ssl_context,
                    **kwargs,
            ) as resp:
                text = await resp.text()

                if resp.status == 401:
                    logger.warning(
                        "⚠️ Token expirado ou inválido, tentando renovar...")
                    self.token = None
                    self.token_expires = None
                    if retry_count < 1:
                        return await self.api_request(
                            method,
                            endpoint,
                            retry_count + 1,
                            **kwargs,
                        )
                    return None

                if resp.status in (500, 502, 503,
                                   504) and retry_count < max_retries:
                    import asyncio

                    logger.warning(
                        "⚠️ Servidor indisponível, tentando novamente... (%d/%d)",
                        retry_count + 1,
                        max_retries,
                    )
                    await asyncio.sleep(2**retry_count)
                    return await self.api_request(
                        method,
                        endpoint,
                        retry_count + 1,
                        **kwargs,
                    )

                try:
                    data = json.loads(text)
                    if isinstance(data, dict):
                        if data.get("erro"):
                            logger.warning("⚠️ API retornou erro: %s",
                                           data.get("erro"))
                        total = data.get("total", "N/A")
                        root_count = (len(data.get("root", [])) if isinstance(
                            data.get("root"), list) else 0)
                        logger.info(
                            "📥 Resposta: total=%s, root_count=%s",
                            total,
                            root_count,
                        )
                        if root_count > 0:
                            sample = data["root"][0]
                            logger.info("📋 Campos: %s", list(sample.keys()))
                    return data  # type: ignore[return-value]

                except json.JSONDecodeError:
                    if "<html" in text.lower():
                        logger.error("❌ API retornou HTML em vez de JSON")
                        self.token = None
                        self.token_expires = None
                    else:
                        logger.error("❌ Erro ao parsear resposta: %s",
                                     text[:200])
                    return None

        except aiohttp.ClientConnectorError as e:
            logger.error("❌ Erro de conexão: %s", e)
            if retry_count < max_retries:
                import asyncio

                logger.warning(
                    "⚠️ Tentando reconectar... (%d/%d)",
                    retry_count + 1,
                    max_retries,
                )
                await asyncio.sleep(2**retry_count)
                return await self.api_request(
                    method,
                    endpoint,
                    retry_count + 1,
                    **kwargs,
                )
            return None

        except aiohttp.ClientError as e:
            logger.error("❌ Erro de conexão: %s", e)
            return None

        except Exception as e:  # pragma: no cover - fallback
            logger.error("❌ Erro na requisição API: %s: %s",
                         type(e).__name__, e)
            return None

    # --------------------------------------------------------------------- #
    # Comandos de texto (prefixo)
    # --------------------------------------------------------------------- #

    @commands.command(name="desk-status")
    async def desk_status(self, ctx: commands.Context) -> None:
        """Verificar status da conexão com Desk.ms."""
        async with ctx.typing():
            embed = discord.Embed(
                title="🔍 Status da Conexão Desk.ms",
                color=discord.Color.blue(),
            )

            has_keys = bool(self.operator_key and self.environment_key)
            embed.add_field(
                name="Chaves Configuradas",
                value="✅ Sim" if has_keys else "❌ Não",
                inline=True,
            )

            if has_keys:
                token = await self.get_auth_token()
                if token:
                    embed.add_field(
                        name="Autenticação",
                        value="✅ OK",
                        inline=True,
                    )
                    embed.add_field(
                        name="Token Expira",
                        value=(self.token_expires.strftime("%H:%M:%S")
                               if self.token_expires else "N/A"),
                        inline=True,
                    )
                    embed.color = discord.Color.green()

                    payload = {
                        "Pesquisa": "",
                        "Ordem": [{
                            "Coluna": "DataCriacao",
                            "Direcao": "false",
                        }],
                    }
                    response = await self.api_request(
                        "POST", "//ChamadosSuporte/lista", json=payload)
                    if response:
                        total = response.get("total", 0)
                        root_count = len(response.get("root", []))
                        embed.add_field(
                            name="Tickets Disponíveis",
                            value=f"{total} (retornou {root_count})",
                            inline=True,
                        )
                        if root_count > 0:
                            sample = response["root"][0]
                            cod = sample.get("CodChamado", "N/A")
                            embed.add_field(
                                name="Exemplo de ID",
                                value=cod,
                                inline=True,
                            )
                    else:
                        embed.add_field(
                            name="Tickets",
                            value="❌ Erro na consulta",
                            inline=True,
                        )
                else:
                    embed.add_field(
                        name="Autenticação",
                        value="❌ Falhou",
                        inline=True,
                    )
                    embed.color = discord.Color.red()

            embed.add_field(name="API URL", value=self.base_url, inline=False)
            await ctx.send(embed=embed)

    @commands.command(name="ticket")
    async def consultar_ticket(self, ctx: commands.Context,
                               ticket_id: str) -> None:
        """Consultar informações de um ticket."""
        async with ctx.typing():
            logger.info("🔍 Buscando ticket: %s", ticket_id)

            payload = {
                "Pesquisa": "",  # ou o termo que você quiser
                "Tatual": "",
                "Ativo": "Todos",
                "StatusSLA": "N",
                "Colunas": {
                    "Chave": "on",
                    "CodChamado": "on",
                    "NomePrioridade": "on",
                    "DataCriacao": "on",
                    "HoraCriacao": "on",
                    "NomeStatus": "on",
                    "Assunto": "on",
                    "NomeUsuario": "on",
                    "SobrenomeUsuario": "on",
                    "NomeOperador": "on",
                    "SobrenomeOperador": "on",
                },
                "Ordem": [{
                    "Coluna": "Chave",
                    "Direcao": "true"
                }],
            }
            response = await self.api_request("POST",
                                              "//ChamadosSuporte/lista",
                                              json=payload)

            if not response:
                await ctx.send("❌ Erro ao conectar com a API")
                return

            if response.get("erro"):
                await ctx.send(f"❌ Erro da API: {response.get('erro')}")
                return

            Tickets = response.get("root", [])
            total = response.get("total", 0)
            logger.info("📋 Resposta com pesquisa '%s': %s ticket(s)",
                        ticket_id, total)

            if not Tickets:
                payload_all = {
                    "Pesquisa": "",
                    "Ordem": [{
                        "Coluna": "DataCriacao",
                        "Direcao": "false",
                    }],
                }
                response_all = await self.api_request("POST",
                                                      "/ChamadosSuporte/lista",
                                                      json=payload_all)
                if response_all and response_all.get("root"):
                    Tickets = response_all.get("root", [])
                    total = response_all.get("total", 0)
                    logger.info("📋 Buscando em todos os %s Tickets...", total)

            if Tickets:
                sample = Tickets[0]
                logger.info("🔑 Campos do ticket: %s", list(sample.keys()))
                logger.info("📝 CodChamado exemplo: %s",
                            sample.get("CodChamado"))

            data = None
            ticket_id_clean = ticket_id.replace("-", "").lower().strip()
            ticket_id_numbers = "".join(filter(str.isdigit, ticket_id))

            for ticket in Tickets:
                cod = str(ticket.get("CodChamado", "")).lower()
                chave = str(ticket.get("Chave", "")).lower()
                cod_clean = cod.replace("-", "")
                chave_clean = chave.replace("-", "")
                cod_numbers = "".join(filter(str.isdigit, cod))

                if ticket_id_clean == cod_clean or ticket_id_clean == chave_clean:
                    data = ticket
                    logger.info("✅ Match exato: %s", cod)
                    break
                if ticket_id_clean in cod_clean or ticket_id_clean in chave_clean:
                    data = ticket
                    logger.info("✅ Match parcial: %s", cod)
                    break
                if ticket_id_numbers and ticket_id_numbers in cod_numbers:
                    data = ticket
                    logger.info("✅ Match numérico: %s", cod)
                    break

            if not data:
                await ctx.send(f"❌ Ticket `{ticket_id}` não encontrado")
                return

            assunto = data.get("Assunto", "Sem assunto")
            nome_status = data.get("NomeStatus", "")
            if isinstance(nome_status, list) and nome_status:
                status = nome_status[0].get("text", "Desconhecido")
            elif isinstance(nome_status, str) and nome_status:
                status = nome_status
            else:
                status = "Desconhecido"

            nome_usuario = data.get("NomeUsuario", "") or ""
            sobrenome_usuario = data.get("SobrenomeUsuario", "") or ""
            cliente = (f"{nome_usuario} {sobrenome_usuario}".strip()
                       ) or "Não informado"

            prioridade = data.get("NomePrioridade", "---")

            nome_operador = data.get("NomeOperador", "") or ""
            sobrenome_operador = data.get("SobrenomeOperador", "") or ""
            analista = (f"{nome_operador} {sobrenome_operador}".strip()
                        or "Não atribuído")

            descricao = (data.get("Descricao", "") or "")[:200]
            data_criacao = data.get("DataCriacao", "---")

            status_lower = status.lower()
            if any(x in status_lower
                   for x in ["resolvido", "finalizado", "encerrado"]):
                emoji, cor = "✅", discord.Color.green()
            elif any(x in status_lower for x in ["cancelado", "rejeitado"]):
                emoji, cor = "❌", discord.Color.red()
            elif any(x in status_lower for x in ["andamento", "atendimento"]):
                emoji, cor = "🔧", discord.Color.orange()
            else:
                emoji, cor = "🆕", discord.Color.blue()

            embed = discord.Embed(
                title=f"Ticket #{ticket_id}",
                description=f"{emoji} **{assunto}**",
                color=cor,
            )
            embed.add_field(name="Status", value=status, inline=True)
            embed.add_field(name="Prioridade", value=prioridade, inline=True)
            embed.add_field(name="Cliente", value=cliente, inline=False)
            embed.add_field(name="Analista", value=analista, inline=True)
            embed.add_field(name="Criado em", value=data_criacao, inline=True)
            if descricao:
                embed.add_field(
                    name="Descrição",
                    value=descricao,
                    inline=False,
                )

            embed.set_footer(text="Desk.ms Integration")
            await ctx.send(embed=embed)

    @commands.command(name="Tickets-fechados")
    async def listar_Tickets_fechados(self, ctx: commands.Context) -> None:
        """Listar últimos tickets fechados do sistema."""
        async with ctx.typing():
            payload = {
                "Pesquisa": "",  # ou o termo que você quiser
                "Tatual": "",
                "Ativo": "Todos",
                "StatusSLA": "N",
                "Colunas": {
                    "Chave": "on",
                    "CodChamado": "on",
                    "NomePrioridade": "on",
                    "DataCriacao": "on",
                    "HoraCriacao": "on",
                    "NomeStatus": "on",
                    "Assunto": "on",
                    "NomeUsuario": "on",
                    "SobrenomeUsuario": "on",
                    "NomeOperador": "on",
                    "SobrenomeOperador": "on",
                },
                "Ordem": [{
                    "Coluna": "Chave",
                    "Direcao": "true"
                }],
            }
            response = await self.api_request(
                "POST",
                "/ChamadosSuporte/lista",
                json=payload,
            )

            if not response or response.get("erro"):
                erro = response.get(
                    "erro") if response else "Nenhum ticket encontrado"
                await ctx.send(f"📋 {erro}")
                return

            Tickets_fechados: List[Dict[str, Any]] = []
            for ticket in response.get("root", []):
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "").lower()
                    if any(
                            x in status_text for x in
                        ["resolvido", "finalizado", "encerrado", "fechado"]):
                        Tickets_fechados.append(ticket)
                if len(Tickets_fechados) >= 10:
                    break

            if not Tickets_fechados:
                await ctx.send("📋 Nenhum ticket fechado encontrado.")
                return

            embed = discord.Embed(
                title=f"✅ Últimos Tickets Fechados ({len(Tickets_fechados)})",
                color=discord.Color.green(),
            )

            for ticket in Tickets_fechados:
                id_ticket = str(ticket.get("CodChamado", "N/A"))
                assunto = (ticket.get("Assunto", "Sem assunto") or "")[:50]
                nome_status = ticket.get("NomeStatus", [])
                status = (nome_status[0].get("text", "---")
                          if isinstance(nome_status, list) and nome_status else
                          "---")
                prioridade = ticket.get("NomePrioridade", "---")

                embed.add_field(
                    name=f"#{id_ticket} - {assunto}",
                    value=
                    f"**Status:** {status} | **Prioridade:** {prioridade}",
                    inline=False,
                )

            embed.set_footer(text="Use !ticket [ID] para mais detalhes")
            await ctx.send(embed=embed)

    @commands.command(name="tickets", aliases=["Tickets"])
    async def pesquisar_Tickets_usuario(
        self,
        ctx: commands.Context,
        *,
        filtro: Optional[str] = None,
    ) -> None:
        """Listar tickets em aberto (ou filtrar por status).

        Uso:
        - `!Tickets` - Tickets em aberto
        - `!Tickets [status]` - Tickets com esse status (ex: resolvido, andamento)
        """
        async with ctx.typing():
            payload = {
                "Pesquisa": "",  # ou o termo que você quiser
                "Tatual": "",
                "Ativo": "Todos",
                "StatusSLA": "N",
                "Colunas": {
                    "Chave": "on",
                    "CodChamado": "on",
                    "NomePrioridade": "on",
                    "DataCriacao": "on",
                    "HoraCriacao": "on",
                    "NomeStatus": "on",
                    "Assunto": "on",
                    "NomeUsuario": "on",
                    "SobrenomeUsuario": "on",
                    "NomeOperador": "on",
                    "SobrenomeOperador": "on",
                },
                "Ordem": [{
                    "Coluna": "Chave",
                    "Direcao": "true"
                }],
            }
            response = await self.api_request("POST",
                                              "/ChamadosSuporte/lista",
                                              json=payload)

            if not response or response.get("erro"):
                erro = response.get(
                    "erro") if response else "Nenhum ticket encontrado"
                await ctx.send(f"📋 {erro}")
                return

            todos_Tickets = response.get("root", [])

            if not todos_Tickets:
                await ctx.send("📋 Nenhum ticket encontrado.")
                return

            if filtro:
                filtro_lower = filtro.lower()
                Tickets_filtrados: List[Dict[str, Any]] = []
                for ticket in todos_Tickets:
                    nome_status = ticket.get("NomeStatus", [])
                    if isinstance(nome_status, list) and nome_status:
                        status_text = nome_status[0].get("text", "").lower()
                    else:
                        status_text = (str(nome_status).lower()
                                       if nome_status else "")

                    if filtro_lower in status_text:
                        Tickets_filtrados.append(ticket)

                if not Tickets_filtrados:
                    await ctx.send(
                        f"📋 Nenhum ticket encontrado com status `{filtro}`")
                    return

                Tickets_final = Tickets_filtrados[:25]
                titulo = (
                    f"🔍 Tickets com Status '{filtro}' ({len(Tickets_final)})")
            else:
                Tickets_abertos: List[Dict[str, Any]] = []
                for ticket in todos_Tickets:
                    nome_status = ticket.get("NomeStatus", [])
                    if isinstance(nome_status, list) and nome_status:
                        status_text = nome_status[0].get("text", "").lower()
                    else:
                        status_text = (str(nome_status).lower()
                                       if nome_status else "")

                    if not any(x in status_text for x in [
                            "resolvido",
                            "finalizado",
                            "encerrado",
                            "fechado",
                            "cancelado",
                            "rejeitado",
                    ]):
                        Tickets_abertos.append(ticket)

                if not Tickets_abertos:
                    await ctx.send("✅ Nenhum ticket em aberto! Parabéns!")
                    return

                Tickets_final = Tickets_abertos[:25]
                titulo = f"🆕 Tickets em Aberto ({len(Tickets_final)})"

            embed = discord.Embed(title=titulo, color=discord.Color.blue())

            for ticket in Tickets_final:
                id_ticket = str(ticket.get("CodChamado", "N/A"))
                assunto = (ticket.get("Assunto", "Sem assunto") or "")[:50]
                nome_status = ticket.get("NomeStatus", [])
                status = (nome_status[0].get("text", "---")
                          if isinstance(nome_status, list) and nome_status else
                          "---")
                prioridade = ticket.get("NomePrioridade", "---")

                embed.add_field(
                    name=f"#{id_ticket} - {assunto}",
                    value=
                    f"**Status:** {status} | **Prioridade:** {prioridade}",
                    inline=False,
                )

            embed.set_footer(text="Use !ticket [ID] para mais detalhes")
            await ctx.send(embed=embed)

    @commands.command(name="abrir-ticket")
    async def abrir_ticket(
        self,
        ctx: commands.Context,
        *,
        assunto: str,
    ) -> None:
        """Abrir um novo ticket."""
        if len(assunto) > 200:
            await ctx.send("❌ O assunto não pode ter mais de 200 caracteres.")
            return

        async with ctx.typing():
            payload = {
                "assunto": assunto,
                "usuario_nome": ctx.author.display_name,
                "descr": f"Aberto via Discord por {ctx.author.display_name}",
            }

            result = await self.api_request("POST", "/Tickets", json=payload)

            if not result or result.get("erro"):
                erro = result.get("erro") if result else "Erro ao criar ticket"
                await ctx.send(f"❌ {erro}")
                return

            ticket_id = result.get("chamado_cod", result.get("id", "N/A"))
            embed = discord.Embed(
                title="✅ Ticket Criado com Sucesso!",
                description=f"**ID do Ticket:** #{ticket_id}",
                color=discord.Color.green(),
            )
            embed.add_field(name="Assunto", value=assunto, inline=False)
            embed.add_field(
                name="Próximo Passo",
                value=f"Use `!ticket {ticket_id}` para acompanhar",
                inline=False,
            )
            await ctx.send(embed=embed)

    # --------------------------------------------------------------------- #
    # Rotina de relatório diário
    # --------------------------------------------------------------------- #

    async def enviar_relatorio_diario(
        self,
        channel: discord.TextChannel,
    ) -> None:
        """Envia um mini relatório automático do dia atual."""
        try:
            from zoneinfo import ZoneInfo

            now = datetime.now(ZoneInfo("America/Sao_Paulo"))
            data_hoje = now.strftime("%d/%m/%Y")

            Tickets, _stats = await self._buscar_Tickets_com_estatisticas(
                data_hoje,
                data_hoje,
            )

            if not Tickets:
                return

            operadores: Dict[str, int] = {}
            total_Tickets = len(Tickets)
            total_cancelados = 0

            for ticket in Tickets:
                status_ticket = str(ticket.get("Status", "")).lower()
                if "cancelado" in status_ticket:
                    total_cancelados += 1

                nome = ticket.get("NomeOperador", "") or ""
                sobrenome = ticket.get("SobrenomeOperador", "") or ""
                operador = f"{nome} {sobrenome}".strip() or "Não atribuído"
                operadores[operador] = operadores.get(operador, 0) + 1

            total_ativos = total_Tickets - total_cancelados

            ranking = sorted(operadores.items(),
                             key=lambda x: x[1],
                             reverse=True)

            descricao = (f"Total de Tickets hoje: **{total_Tickets}**\n"
                         f"✅ Ativos/Finalizados: **{total_ativos}**\n"
                         f"🚫 Cancelados: **{total_cancelados}**")

            embed = discord.Embed(
                title=f"📅 Resumo do Dia: {data_hoje}",
                description=descricao,
                color=discord.Color.purple(),
            )

            texto_ranking = ""
            medalhas = ["🥇", "🥈", "🥉"]
            for i, (op, qtd) in enumerate(ranking[:10]):
                icone = medalhas[i] if i < 3 else "▪️"
                texto_ranking += f"{icone} **{op}**: {qtd}\n"

            if texto_ranking:
                embed.add_field(
                    name="Atendimentos por Operador",
                    value=texto_ranking,
                    inline=False,
                )

            embed.set_footer(
                text="Relatório Automático Diário • NextCompany", )

            await channel.send(embed=embed)

        except Exception as e:  # pragma: no cover - fallback
            print(f"Erro ao enviar relatório diário: {e}")

    # --------------------------------------------------------------------- #
    # Base de conhecimento
    # --------------------------------------------------------------------- #

    @commands.command(name="kb-search")
    async def pesquisar_base_conhecimento(
        self,
        ctx: commands.Context,
        *,
        termo: str,
    ) -> None:
        """Pesquisar na base de conhecimento."""
        async with ctx.typing():
            logger.info("🔍 Pesquisando base de conhecimento: %s", termo)

            payload = {
                "Pesquisa": "",  # ou o termo que você quiser
                "Tatual": "",
                "Ativo": "Todos",
                "StatusSLA": "N",
                "Colunas": {
                    "Chave": "on",
                    "CodChamado": "on",
                    "NomePrioridade": "on",
                    "DataCriacao": "on",
                    "HoraCriacao": "on",
                    "NomeStatus": "on",
                    "Assunto": "on",
                    "NomeUsuario": "on",
                    "SobrenomeUsuario": "on",
                    "NomeOperador": "on",
                    "SobrenomeOperador": "on",
                },
                "Ordem": [{
                    "Coluna": "Chave",
                    "Direcao": "true"
                }],
            }
            response = await self.api_request("POST",
                                              "/BaseConhecimento/lista",
                                              json=payload)

            if not response:
                await ctx.send("❌ Erro ao conectar com a base de conhecimento")
                return

            if response.get("erro"):
                await ctx.send(f"❌ Erro: {response.get('erro')}")
                return

            artigos = response.get("root", [])
            total = response.get("total", 0)
            logger.info("📚 Encontrados %s artigos para '%s'", total, termo)

            if not artigos:
                await ctx.send(f"❌ Nenhum artigo encontrado para '{termo}'")
                return

            embed = discord.Embed(
                title="📚 Base de Conhecimento - Resultados",
                description=
                f"Pesquisa: `{termo}`\nEncontrados: {total} artigos",
                color=discord.Color.blue(),
            )

            for artigo in artigos[:10]:
                chave = artigo.get("Chave", "N/A")
                titulo = artigo.get("Titulo", "Sem título")
                categorias = artigo.get("Categoria", [])
                categoria_text = (categorias[0].get("text", "---")
                                  if categorias else "---")
                palavras_chave = artigo.get("PalavrasChave", "")

                valor = f"**Categoria:** {categoria_text}\n"
                if palavras_chave:
                    valor += f"**Tags:** {palavras_chave}"

                embed.add_field(
                    name=f"#{chave} - {titulo[:50]}",
                    value=valor,
                    inline=False,
                )

            embed.set_footer(text=("Use !kb-artigo [ID] para mais detalhes "
                                   f"| Total: {total} artigos"))
            await ctx.send(embed=embed)

    @commands.command(name="kb-artigo")
    async def ver_artigo_conhecimento(
        self,
        ctx: commands.Context,
        chave: str,
    ) -> None:
        """Ver artigo específico da base de conhecimento."""
        async with ctx.typing():
            chave_limpa = chave.replace("#", "").strip()
            logger.info("📖 Consultando artigo KB: %s (limpa: %s)", chave,
                        chave_limpa)

            payload = {"Chave": chave_limpa}
            response = await self.api_request(
                "POST",
                "/BaseConhecimento",
                json=payload,
            )

            if not response:
                await ctx.send("❌ Erro ao conectar com a base de conhecimento")
                return

            logger.debug("📝 Resposta completa: %s", response)
            artigo = response.get("TBaseConhecimento")
            if not artigo:
                logger.warning(
                    "⚠️ Artigo %s não encontrado. Keys: %s",
                    chave_limpa,
                    list(response.keys()),
                )
                await ctx.send(f"❌ Artigo #{chave_limpa} não encontrado")
                return

            titulo = artigo.get("Titulo", "Sem título")
            categorias = artigo.get("Categoria", [])
            categoria_text = (categorias[0].get("text", "---")
                              if categorias else "---")
            palavras_chave = artigo.get("PalavrasChave", "")
            conteudo = artigo.get("Conteudo", "") or artigo.get(
                "Comentarios", "")
            link_externo = artigo.get("LinkExterno", "")
            link_direto = artigo.get("LinkDireto", "")
            aprovador = artigo.get("Aprovador", "N/A")
            publico = artigo.get("Publico", "N") == "S"
            visivel_operadores = artigo.get("VisivelTodosOperadores",
                                            "N") == "S"
            visivel_usuarios = artigo.get("VisivelTodosUsuarios", "N") == "S"
            cat_adicionais = artigo.get("CatAdicionais", "")

            embed = discord.Embed(
                title=f"📖 {titulo}",
                color=discord.Color.blurple(),
            )

            embed.add_field(name="ID", value=f"#{chave}", inline=True)
            embed.add_field(name="Categoria",
                            value=categoria_text,
                            inline=True)

            if cat_adicionais:
                embed.add_field(
                    name="Categorias Adicionais",
                    value=cat_adicionais,
                    inline=True,
                )

            perms: List[str] = []
            if publico:
                perms.append("🌐 Pública")
            if visivel_operadores:
                perms.append("👨‍💼 Todos Operadores")
            if visivel_usuarios:
                perms.append("👥 Todos Usuários")
            if perms:
                embed.add_field(
                    name="Visibilidade",
                    value=" | ".join(perms),
                    inline=False,
                )

            cod_clientes = artigo.get("CodCliente", [])
            cod_depts = artigo.get("CodDepartamento", [])
            cod_grupos = artigo.get("CodGrupo", [])

            if cod_clientes:
                clientes_text = ", ".join(
                    [c.get("text", "") for c in cod_clientes[:3]])
                if len(cod_clientes) > 3:
                    clientes_text += f" +{len(cod_clientes) - 3}"
                embed.add_field(
                    name="Clientes Autorizados",
                    value=clientes_text,
                    inline=True,
                )

            if cod_depts:
                depts_text = ", ".join(
                    [d.get("text", "") for d in cod_depts[:2]])
                if len(cod_depts) > 2:
                    depts_text += f" +{len(cod_depts) - 2}"
                embed.add_field(
                    name="Departamentos",
                    value=depts_text,
                    inline=True,
                )

            if cod_grupos:
                grupos_text = ", ".join(
                    [g.get("text", "") for g in cod_grupos[:2]])
                if len(cod_grupos) > 2:
                    grupos_text += f" +{len(cod_grupos) - 2}"
                embed.add_field(
                    name="Grupos de Atendimento",
                    value=grupos_text,
                    inline=True,
                )

            if palavras_chave:
                embed.add_field(
                    name="Tags",
                    value=palavras_chave,
                    inline=False,
                )

            if conteudo:
                conteudo_limpo = self._limpar_html(conteudo)
                if len(conteudo_limpo) > 500:
                    conteudo_truncado = conteudo_limpo[:500] + "..."
                else:
                    conteudo_truncado = conteudo_limpo
                embed.add_field(
                    name="Conteúdo",
                    value=conteudo_truncado,
                    inline=False,
                )

            links_text = ""
            if link_direto:
                links_text += f"🔗 [Visualizar Artigo]({link_direto})\n"
            if link_externo:
                links_text += f"🌐 [Link Externo]({link_externo})"

            if links_text:
                embed.add_field(
                    name="📌 Acesso Rápido",
                    value=links_text,
                    inline=False,
                )

            embed.set_footer(
                text=f"Desk.ms Knowledge Base • Aprovador: {aprovador}")
            await ctx.send(embed=embed)

    # --------------------------------------------------------------------- #
    # Funções de apoio a relatórios
    # --------------------------------------------------------------------- #

    async def _buscar_relatorio_slideshow(
        self,
        data_inicio: str,
        data_fim: str,
    ) -> Dict[str, Any]:
        """Busca dados de relatório via endpoint SlideShow (sem limite de 3000)."""
        try:
            _ = datetime.strptime(data_inicio, "%d/%m/%Y")
            _ = datetime.strptime(data_fim, "%d/%m/%Y")
            logger.info(
                "📅 Tentando SlideShow com período: %s a %s",
                data_inicio,
                data_fim,
            )
        except Exception as e:
            logger.error("❌ Erro ao parsear datas: %s", e)
            return {}

        for chave in ["Tickets", "Tickets", ""]:
            try:
                payload = {"Chave": chave}
                logger.info("🔍 SlideShow com Chave='%s'...", chave)
                response = await self.api_request("POST",
                                                  "/SlideShow",
                                                  json=payload)

                if response and not response.get("erro"):
                    logger.info("✅ SlideShow %s disponível!", chave)
                    return response.get("rSlideShow", response)
            except Exception as e:  # pragma: no cover - fallback
                logger.debug("⚠️ SlideShow falhou com Chave='%s': %s", chave,
                             e)

        logger.warning(
            "⚠️ SlideShow não funcionou, usando /ChamadosSuporte/lista")
        return {}

    @staticmethod
    def _parse_date_flexible(data_str: str) -> Optional[datetime]:
        """Parse flexível para múltiplos formatos de data do Desk.ms."""
        if not data_str or not isinstance(data_str, str):
            return None

        data_str = data_str.strip()

        formatos = [
            "%d/%m/%Y %H:%M:%S",
            "%d/%m/%Y %H:%M",
            "%d/%m/%Y",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S.%fZ",
        ]

        for formato in formatos:
            try:
                return datetime.strptime(data_str, formato)
            except ValueError:
                continue

        return None

    async def _buscar_todos_Tickets(
        self,
        data_inicio: str,
        data_fim: str,
    ) -> List[Dict[str, Any]]:
        """Retorna tickets filtrando por período usando filtro da API + filtro local."""
        try:
            data_inicio_obj = datetime.strptime(data_inicio, "%d/%m/%Y")
            data_fim_obj = datetime.strptime(data_fim, "%d/%m/%Y").replace(
                hour=23,
                minute=59,
                second=59,
            )
        except Exception as e:
            logger.error("❌ Erro ao parsear datas do período: %s", e)
            return []

        payload = {
            "Pesquisa": "",
            "Ordem": [{
                "Coluna": "DataCriacao",
                "Direcao": "false",
            }],
            "Filtro": {
                "DataCriacao": {
                    "Inicio": data_inicio,
                    "Fim": f"{data_fim} 23:59:59",
                }
            },
        }

        response = await self.api_request(
            "POST",
            "//ChamadosSuporte/lista",
            json=payload,
        )

        if not response or response.get("erro"):
            logger.error(
                "❌ Erro ao buscar Tickets: %s",
                response.get("erro") if response else "Sem resposta",
            )
            return []

        todos_Tickets = response.get("root", [])
        total_api_raw = response.get("total", len(todos_Tickets))
        total_api = int(total_api_raw) if total_api_raw else len(todos_Tickets)
        logger.info(
            "📥 API retornou %s de %s Tickets (filtro: %s a %s)",
            len(todos_Tickets),
            total_api,
            data_inicio,
            data_fim,
        )

        Tickets_filtrados: List[Dict[str, Any]] = []
        datas_nao_reconhecidas = 0

        for ticket in todos_Tickets:
            data_str = ticket.get("DataCriacao", "")
            if not data_str:
                datas_nao_reconhecidas += 1
                continue

            data_obj = self._parse_date_flexible(str(data_str))
            if data_obj is None:
                datas_nao_reconhecidas += 1
                logger.debug("⚠️ Formato de data não reconhecido: '%s'",
                             data_str)
                continue

            if data_inicio_obj <= data_obj <= data_fim_obj:
                Tickets_filtrados.append(ticket)

        if datas_nao_reconhecidas > 0:
            logger.warning(
                "⚠️ %s tickets com data não reconhecida foram ignorados",
                datas_nao_reconhecidas,
            )

        if total_api > len(todos_Tickets):
            logger.warning(
                "⚠️ ATENÇÃO: API retornou apenas %s de %s Tickets (limite da API)",
                len(todos_Tickets),
                total_api,
            )

        logger.info(
            "✅ Filtrados: %s de %s Tickets no período %s a %s",
            len(Tickets_filtrados),
            len(todos_Tickets),
            data_inicio,
            data_fim,
        )
        return Tickets_filtrados

    async def _buscar_Tickets_com_estatisticas(
        self,
        data_inicio: str,
        data_fim: str,
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """Retorna tickets e estatísticas sobre a consulta usando filtro server-side."""
        try:
            data_inicio_obj = datetime.strptime(data_inicio, "%d/%m/%Y")
            data_fim_obj = datetime.strptime(data_fim, "%d/%m/%Y").replace(
                hour=23,
                minute=59,
                second=59,
            )
        except Exception as e:
            logger.error("❌ Erro ao parsear datas do período: %s", e)
            return [], {"erro": str(e)}

        payload = {
            "Pesquisa": "",
            "Ordem": [{
                "Coluna": "DataCriacao",
                "Direcao": "false",
            }],
            "Filtro": {
                "DataCriacao": {
                    "Inicio": data_inicio,
                    "Fim": f"{data_fim} 23:59:59",
                }
            },
        }

        response = await self.api_request(
            "POST",
            "//ChamadosSuporte/lista",
            json=payload,
        )

        if not response or response.get("erro"):
            return [], {
                "erro": response.get("erro") if response else "Sem resposta",
            }

        todos_Tickets = response.get("root", [])
        total_api_raw = response.get("total", len(todos_Tickets))
        total_api = int(total_api_raw) if total_api_raw else len(todos_Tickets)

        Tickets_filtrados: List[Dict[str, Any]] = []
        datas_nao_reconhecidas = 0

        for ticket in todos_Tickets:
            data_str = ticket.get("DataCriacao", "")
            if not data_str:
                datas_nao_reconhecidas += 1
                continue

            data_obj = self._parse_date_flexible(str(data_str))
            if data_obj is None:
                datas_nao_reconhecidas += 1
                continue

            if data_inicio_obj <= data_obj <= data_fim_obj:
                Tickets_filtrados.append(ticket)

        estatisticas = {
            "total_api": total_api,
            "retornados": len(todos_Tickets),
            "filtrados": len(Tickets_filtrados),
            "datas_invalidas": datas_nao_reconhecidas,
            "limite_atingido": total_api > len(todos_Tickets),
            "data_inicio": data_inicio,
            "data_fim": data_fim,
        }

        return Tickets_filtrados, estatisticas

    # --------------------------------------------------------------------- #
    # Relatórios (comandos prefixados)
    # --------------------------------------------------------------------- #

    @commands.command(name="relatorio-operadores")
    async def relatorio_por_operador(
        self,
        ctx: commands.Context,
        *,
        periodo: Optional[str] = None,
    ) -> None:
        """Relatório: Quantos tickets cada operador atendeu."""
        async with ctx.typing():
            from zoneinfo import ZoneInfo

            data_hora = datetime.now(
                ZoneInfo("America/Sao_Paulo")).strftime("%d/%m/%Y às %H:%M")

            data_inicio, data_fim, descricao_periodo = self._get_periodo_info(
                periodo)

            Tickets, stats = await self._buscar_Tickets_com_estatisticas(
                data_inicio,
                data_fim,
            )

            if stats.get("erro"):
                await ctx.send(f"❌ Erro ao buscar dados: {stats['erro']}")
                return

            if not Tickets:
                await ctx.send(
                    "📋 Nenhum ticket encontrado no período: "
                    f"**{descricao_periodo}** ({data_inicio} a {data_fim})")
                return

            operadores: Dict[str, int] = {}
            for ticket in Tickets:
                nome_operador = ticket.get("NomeOperador", "") or ""
                sobrenome_operador = ticket.get("SobrenomeOperador", "") or ""
                operador_completo = (
                    f"{nome_operador} {sobrenome_operador}".strip()
                    or "Não atribuído")
                operadores[operador_completo] = operadores.get(
                    operador_completo, 0) + 1

            operadores_ordenado = sorted(
                operadores.items(),
                key=lambda x: x[1],
                reverse=True,
            )

            descricao = (f"📅 **Período:** {descricao_periodo}\n"
                         f"📆 **De:** {data_inicio} **até:** {data_fim}\n"
                         f"🕐 **Atualizado:** {data_hora}")

            if stats["limite_atingido"]:
                descricao += (
                    "\n\n⚠️ **ATENÇÃO:** A API Desk.ms retornou "
                    f"{stats['retornados']} de {stats['total_api']} Tickets. "
                    "Os dados podem estar incompletos!")

            embed = discord.Embed(
                title="📊 Relatório: Tickets por Operador",
                description=descricao,
                color=discord.Color.orange()
                if stats["limite_atingido"] else discord.Color.gold(),
            )

            total_Tickets = len(Tickets)
            media_por_operador = total_Tickets / len(
                operadores) if operadores else 0

            embed.add_field(
                name="📋 Total de Tickets",
                value=str(total_Tickets),
                inline=True,
            )
            embed.add_field(
                name="👥 Operadores Ativos",
                value=str(len(operadores)),
                inline=True,
            )
            embed.add_field(
                name="📈 Média/Operador",
                value=f"{media_por_operador:.1f}",
                inline=True,
            )

            operadores_text = ""
            medalhas = ["🥇", "🥈", "🥉"]
            for i, (operador, count) in enumerate(operadores_ordenado[:15]):
                percentual = (count /
                              total_Tickets) * 100 if total_Tickets else 0
                medalha = medalhas[i] if i < 3 else "👤"
                operadores_text += (
                    f"{medalha} **{operador}**: {count} ({percentual:.1f}%)\n")

            if operadores_text:
                embed.add_field(
                    name="🏆 Ranking",
                    value=operadores_text,
                    inline=False,
                )

            footer_text = f"Período: {data_inicio} a {data_fim}"
            if stats["datas_invalidas"] > 0:
                footer_text += (
                    f" | ⚠️ {stats['datas_invalidas']} registros ignorados "
                    "(data inválida)")

            embed.set_footer(text=footer_text)
            await ctx.send(embed=embed)

    @commands.command(name="relatorio-resumo")
    async def relatorio_resumo(
        self,
        ctx: commands.Context,
        *,
        periodo: Optional[str] = None,
    ) -> None:
        """Relatório: Resumo geral de tickets por status."""
        async with ctx.typing():
            from zoneinfo import ZoneInfo

            data_hora = datetime.now(
                ZoneInfo("America/Sao_Paulo")).strftime("%d/%m/%Y às %H:%M")

            data_inicio, data_fim, descricao_periodo = self._get_periodo_info(
                periodo)

            Tickets, stats = await self._buscar_Tickets_com_estatisticas(
                data_inicio,
                data_fim,
            )

            if stats.get("erro"):
                await ctx.send(f"❌ Erro ao buscar dados: {stats['erro']}")
                return

            if not Tickets:
                await ctx.send(
                    "📋 Nenhum ticket encontrado no período: "
                    f"**{descricao_periodo}** ({data_inicio} a {data_fim})")
                return

            status_count: Dict[str, int] = {}
            prioridade_count: Dict[str, int] = {}
            resolvidos = 0
            em_aberto = 0

            for ticket in Tickets:
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "Desconhecido")
                else:
                    status_text = (str(nome_status)
                                   if nome_status else "Desconhecido")

                prioridade = ticket.get("NomePrioridade", "Não definida")

                status_count[status_text] = status_count.get(status_text,
                                                             0) + 1
                prioridade_count[prioridade] = prioridade_count.get(
                    prioridade, 0) + 1

                status_lower = status_text.lower()
                if any(x in status_lower for x in
                       ["resolvido", "finalizado", "encerrado", "fechado"]):
                    resolvidos += 1
                elif not any(x in status_lower
                             for x in ["cancelado", "rejeitado"]):
                    em_aberto += 1

            descricao = (f"📅 **Período:** {descricao_periodo}\n"
                         f"📆 **De:** {data_inicio} **até:** {data_fim}\n"
                         f"🕐 **Atualizado:** {data_hora}")

            if stats["limite_atingido"]:
                descricao += (
                    "\n\n⚠️ **ATENÇÃO:** A API Desk.ms retornou "
                    f"{stats['retornados']} de {stats['total_api']} Tickets. "
                    "Os dados podem estar incompletos!")

            embed = discord.Embed(
                title="📈 Relatório: Resumo de Tickets",
                description=descricao,
                color=discord.Color.orange()
                if stats["limite_atingido"] else discord.Color.blue(),
            )

            total = len(Tickets)
            taxa_resolucao = (resolvidos / total * 100) if total > 0 else 0

            embed.add_field(name="📋 Total", value=str(total), inline=True)
            embed.add_field(name="✅ Resolvidos",
                            value=str(resolvidos),
                            inline=True)
            embed.add_field(name="🔧 Em Aberto",
                            value=str(em_aberto),
                            inline=True)
            embed.add_field(
                name="📊 Taxa Resolução",
                value=f"{taxa_resolucao:.1f}%",
                inline=True,
            )

            status_text_embed = ""
            status_emojis = {
                "resolvido": "✅",
                "finalizado": "✅",
                "encerrado": "✅",
                "fechado": "✅",
                "novo": "🆕",
                "aberto": "🆕",
                "andamento": "🔧",
                "atendimento": "🔧",
                "aguardando": "⏳",
                "cancelado": "❌",
                "rejeitado": "❌",
            }

            for status, count in sorted(status_count.items(),
                                        key=lambda x: x[1],
                                        reverse=True)[:10]:
                emoji = "📌"
                for key, emj in status_emojis.items():
                    if key in status.lower():
                        emoji = emj
                        break
                percentual = (count / total) * 100 if total else 0
                status_text_embed += (
                    f"{emoji} **{status}**: {count} ({percentual:.1f}%)\n")

            if status_text_embed:
                embed.add_field(
                    name="📊 Por Status",
                    value=status_text_embed,
                    inline=False,
                )

            prioridade_text = ""
            prioridade_emojis = {
                "alta": "🔴",
                "média": "🟡",
                "media": "🟡",
                "baixa": "🟢",
                "crítica": "🚨",
                "critica": "🚨",
            }

            for prioridade, count in sorted(prioridade_count.items(),
                                            key=lambda x: x[1],
                                            reverse=True):
                emoji = "⚪"
                for key, emj in prioridade_emojis.items():
                    if key in prioridade.lower():
                        emoji = emj
                        break
                percentual = (count / total) * 100 if total else 0
                prioridade_text += (
                    f"{emoji} **{prioridade}**: {count} ({percentual:.1f}%)\n")

            if prioridade_text:
                embed.add_field(
                    name="🎯 Por Prioridade",
                    value=prioridade_text,
                    inline=False,
                )

            footer_text = f"Período: {data_inicio} a {data_fim}"
            if stats["datas_invalidas"] > 0:
                footer_text += (
                    f" | ⚠️ {stats['datas_invalidas']} registros ignorados")

            embed.set_footer(text=footer_text)
            await ctx.send(embed=embed)

    # --------------------------------------------------------------------- #
    # Slash commands helpers
    # --------------------------------------------------------------------- #

    async def periodo_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> List[app_commands.Choice[str]]:
        periodos = [
            ("Semestre atual", "semestre"),
            ("Trimestre atual", "trimestre"),
            ("Mes atual", "mes"),
            ("Ultimos 7 dias", "semana"),
            ("Hoje", "hoje"),
        ]

        if current:
            periodos = [(nome, valor) for nome, valor in periodos
                        if current.lower() in nome.lower()]

        return [
            app_commands.Choice(name=nome, value=valor)
            for nome, valor in periodos
        ]

    # --------------------------------------------------------------------- #
    # Slash commands (interactions)
    # --------------------------------------------------------------------- #

    @app_commands.command(name="tickets",
                          description="Listar Tickets do Desk.ms")
    @app_commands.describe(filtro="Filtrar por status (opcional)")
    async def slash_Tickets(
        self,
        interaction: discord.Interaction,
        filtro: Optional[str] = None,
    ) -> None:
        await interaction.response.defer()

        payload = {
            "Pesquisa": "",  # ou o termo que você quiser
            "Tatual": "",
            "Ativo": "Todos",
            "StatusSLA": "N",
            "Colunas": {
                "Chave": "on",
                "CodChamado": "on",
                "NomePrioridade": "on",
                "DataCriacao": "on",
                "HoraCriacao": "on",
                "NomeStatus": "on",
                "Assunto": "on",
                "NomeUsuario": "on",
                "SobrenomeUsuario": "on",
                "NomeOperador": "on",
                "SobrenomeOperador": "on",
            },
            "Ordem": [{
                "Coluna": "Chave",
                "Direcao": "true"
            }],
        }
        response = await self.api_request(
            "POST",
            "//ChamadosSuporte/lista",
            json=payload,
        )

        if not response or response.get("erro"):
            erro = response.get(
                "erro") if response else "Nenhum ticket encontrado"
            await interaction.followup.send(f"❌ {erro}")
            return

        todos_Tickets = response.get("root", [])

        if not todos_Tickets:
            await interaction.followup.send("📋 Nenhum ticket encontrado.")
            return

        if filtro:
            filtro_lower = filtro.lower()
            Tickets_filtrados: List[Dict[str, Any]] = []
            for ticket in todos_Tickets:
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "").lower()
                else:
                    status_text = str(
                        nome_status).lower() if nome_status else ""

                if filtro_lower in status_text:
                    Tickets_filtrados.append(ticket)

            if not Tickets_filtrados:
                await interaction.followup.send(
                    f"📋 Nenhum ticket com status `{filtro}`")
                return

            Tickets_final = Tickets_filtrados[:25]
            titulo = f"🔍 Tickets com Status '{filtro}' ({len(Tickets_final)})"
        else:
            Tickets_abertos: List[Dict[str, Any]] = []
            for ticket in todos_Tickets:
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "").lower()
                else:
                    status_text = str(
                        nome_status).lower() if nome_status else ""

                if not any(x in status_text for x in [
                        "resolvido",
                        "finalizado",
                        "encerrado",
                        "fechado",
                        "cancelado",
                        "rejeitado",
                ]):
                    Tickets_abertos.append(ticket)

            if not Tickets_abertos:
                await interaction.followup.send(
                    "✅ Nenhum ticket em aberto! Parabens!")
                return

            Tickets_final = Tickets_abertos[:25]
            titulo = f"🆕 Tickets em Aberto ({len(Tickets_final)})"

        embed = discord.Embed(title=titulo, color=discord.Color.blue())

        for ticket in Tickets_final[:15]:
            id_ticket = str(ticket.get("CodChamado", "N/A"))
            assunto = (ticket.get("Assunto", "Sem assunto") or "")[:50]
            nome_status = ticket.get("NomeStatus", [])
            status = (nome_status[0].get("text", "---") if
                      isinstance(nome_status, list) and nome_status else "---")
            prioridade = ticket.get("NomePrioridade", "---")

            embed.add_field(
                name=f"#{id_ticket} - {assunto}",
                value=f"**Status:** {status} | **Prioridade:** {prioridade}",
                inline=False,
            )

        if len(Tickets_final) > 15:
            embed.set_footer(
                text=(f"Mostrando 15 de {len(Tickets_final)} Tickets | "
                      "Use /ticket [ID] para detalhes"))
        else:
            embed.set_footer(text="Use /ticket [ID] para mais detalhes")

        await interaction.followup.send(embed=embed)

    @app_commands.command(name="ticket",
                          description="Ver detalhes de um ticket")
    @app_commands.describe(id="ID do ticket")
    async def slash_ticket(
        self,
        interaction: discord.Interaction,
        id: str,
    ) -> None:
        await interaction.response.defer()

        payload = {
            "Pesquisa": id,
            "Ordem": [{
                "Coluna": "DataCriacao",
                "Direcao": "false",
            }],
        }
        response = await self.api_request(
            "POST",
            "//ChamadosSuporte/lista",
            json=payload,
        )

        if not response:
            await interaction.followup.send("❌ Erro ao conectar com a API")
            return

        Tickets = response.get("root", [])

        data: Optional[Dict[str, Any]] = None
        ticket_id_clean = id.replace("-", "").lower().strip()

        for ticket in Tickets:
            cod = str(ticket.get("CodChamado", "")).lower().replace("-", "")
            if ticket_id_clean in cod or cod in ticket_id_clean:
                data = ticket
                break

        if not data:
            await interaction.followup.send(f"❌ Ticket `{id}` nao encontrado")
            return

        assunto = data.get("Assunto", "Sem assunto")
        nome_status = data.get("NomeStatus", "")
        if isinstance(nome_status, list) and nome_status:
            status = nome_status[0].get("text", "Desconhecido")
        else:
            status = str(nome_status) if nome_status else "Desconhecido"

        nome_usuario = data.get("NomeUsuario", "") or ""
        sobrenome_usuario = data.get("SobrenomeUsuario", "") or ""
        cliente = (
            f"{nome_usuario} {sobrenome_usuario}".strip()) or "Nao informado"

        prioridade = data.get("NomePrioridade", "---")

        nome_operador = data.get("NomeOperador", "") or ""
        sobrenome_operador = data.get("SobrenomeOperador", "") or ""
        analista = (f"{nome_operador} {sobrenome_operador}".strip()
                    or "Nao atribuido")

        data_criacao = data.get("DataCriacao", "---")

        status_lower = status.lower()
        if any(x in status_lower
               for x in ["resolvido", "finalizado", "encerrado"]):
            emoji, cor = "✅", discord.Color.green()
        elif any(x in status_lower for x in ["cancelado", "rejeitado"]):
            emoji, cor = "❌", discord.Color.red()
        elif any(x in status_lower for x in ["andamento", "atendimento"]):
            emoji, cor = "🔧", discord.Color.orange()
        else:
            emoji, cor = "🆕", discord.Color.blue()

        embed = discord.Embed(
            title=f"Ticket #{id}",
            description=f"{emoji} **{assunto}**",
            color=cor,
        )
        embed.add_field(name="📌 Status", value=status, inline=True)
        embed.add_field(name="🎯 Prioridade", value=prioridade, inline=True)
        embed.add_field(name="👤 Cliente", value=cliente, inline=False)
        embed.add_field(name="👨‍💻 Analista", value=analista, inline=True)
        embed.add_field(name="📅 Criado em", value=data_criacao, inline=True)

        await interaction.followup.send(embed=embed)

    @app_commands.command(name="relatorio",
                          description="Gerar relatorio de Tickets")
    @app_commands.describe(
        tipo="Tipo de relatorio",
        periodo="Periodo do relatorio",
    )
    @app_commands.choices(tipo=[
        app_commands.Choice(name="Resumo por Status", value="resumo"),
        app_commands.Choice(name="Por Operador", value="operadores"),
    ])
    @app_commands.autocomplete(periodo=periodo_autocomplete)
    async def slash_relatorio(
        self,
        interaction: discord.Interaction,
        tipo: str = "resumo",
        periodo: str = "semestre",
    ) -> None:
        await interaction.response.defer()

        from zoneinfo import ZoneInfo

        data_hora = datetime.now(
            ZoneInfo("America/Sao_Paulo")).strftime("%d/%m/%Y as %H:%M")

        data_inicio, data_fim, descricao_periodo = self._get_periodo_info(
            periodo)

        Tickets, stats = await self._buscar_Tickets_com_estatisticas(
            data_inicio,
            data_fim,
        )

        if stats.get("erro"):
            await interaction.followup.send(
                f"❌ Erro ao buscar dados: {stats['erro']}")
            return

        if not Tickets:
            await interaction.followup.send(
                f"📋 Nenhum ticket encontrado no periodo: **{descricao_periodo}**"
            )
            return

        if tipo == "operadores":
            operadores: Dict[str, int] = {}
            for ticket in Tickets:
                nome_operador = ticket.get("NomeOperador", "") or ""
                sobrenome_operador = ticket.get("SobrenomeOperador", "") or ""
                operador_completo = (
                    f"{nome_operador} {sobrenome_operador}".strip()
                    or "Nao atribuido")
                operadores[operador_completo] = operadores.get(
                    operador_completo, 0) + 1

            operadores_ordenado = sorted(
                operadores.items(),
                key=lambda x: x[1],
                reverse=True,
            )

            descricao = (f"📅 **Periodo:** {descricao_periodo}\n"
                         f"📆 **De:** {data_inicio} **ate:** {data_fim}\n"
                         f"🕐 **Atualizado:** {data_hora}")

            if stats["limite_atingido"]:
                descricao += (
                    "\n\n⚠️ **ATENCAO:** API retornou "
                    f"{stats['retornados']} de {stats['total_api']} Tickets")

            embed = discord.Embed(
                title="📊 Relatorio: Tickets por Operador",
                description=descricao,
                color=discord.Color.orange()
                if stats["limite_atingido"] else discord.Color.gold(),
            )

            total_Tickets = len(Tickets)
            media = total_Tickets / len(operadores) if operadores else 0

            embed.add_field(name="📋 Total",
                            value=str(total_Tickets),
                            inline=True)
            embed.add_field(
                name="👥 Operadores",
                value=str(len(operadores)),
                inline=True,
            )
            embed.add_field(name="📈 Media", value=f"{media:.1f}", inline=True)

            operadores_text = ""
            medalhas = ["🥇", "🥈", "🥉"]
            for i, (operador, count) in enumerate(operadores_ordenado[:15]):
                percentual = (count /
                              total_Tickets) * 100 if total_Tickets else 0
                medalha = medalhas[i] if i < 3 else "👤"
                operadores_text += (
                    f"{medalha} **{operador}**: {count} ({percentual:.1f}%)\n")

            if operadores_text:
                embed.add_field(
                    name="🏆 Ranking",
                    value=operadores_text,
                    inline=False,
                )
        else:
            status_count: Dict[str, int] = {}
            resolvidos = 0
            em_aberto = 0

            for ticket in Tickets:
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "Desconhecido")
                else:
                    status_text = (str(nome_status)
                                   if nome_status else "Desconhecido")

                status_count[status_text] = status_count.get(status_text,
                                                             0) + 1

                status_lower = status_text.lower()
                if any(x in status_lower for x in
                       ["resolvido", "finalizado", "encerrado", "fechado"]):
                    resolvidos += 1
                elif not any(x in status_lower
                             for x in ["cancelado", "rejeitado"]):
                    em_aberto += 1

            descricao = (f"📅 **Periodo:** {descricao_periodo}\n"
                         f"📆 **De:** {data_inicio} **ate:** {data_fim}\n"
                         f"🕐 **Atualizado:** {data_hora}")

            if stats["limite_atingido"]:
                descricao += (
                    "\n\n⚠️ **ATENCAO:** API retornou "
                    f"{stats['retornados']} de {stats['total_api']} Tickets")

            embed = discord.Embed(
                title="📈 Relatorio: Resumo de Tickets",
                description=descricao,
                color=discord.Color.orange()
                if stats["limite_atingido"] else discord.Color.blue(),
            )

            total = len(Tickets)
            taxa = (resolvidos / total * 100) if total > 0 else 0

            embed.add_field(name="📋 Total", value=str(total), inline=True)
            embed.add_field(name="✅ Resolvidos",
                            value=str(resolvidos),
                            inline=True)
            embed.add_field(name="🔧 Em Aberto",
                            value=str(em_aberto),
                            inline=True)
            embed.add_field(
                name="📊 Taxa Resolucao",
                value=f"{taxa:.1f}%",
                inline=True,
            )

            status_text_embed = ""
            for status, count in sorted(status_count.items(),
                                        key=lambda x: x[1],
                                        reverse=True)[:10]:
                percentual = (count / total) * 100 if total else 0
                status_text_embed += (
                    f"📌 **{status}**: {count} ({percentual:.1f}%)\n")

            if status_text_embed:
                embed.add_field(
                    name="📊 Por Status",
                    value=status_text_embed,
                    inline=False,
                )

        await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="desk-status",
        description="Verificar status da conexao com Desk.ms",
    )
    async def slash_desk_status(
        self,
        interaction: discord.Interaction,
    ) -> None:
        await interaction.response.defer()

        embed = discord.Embed(
            title="🔍 Status da Conexao Desk.ms",
            color=discord.Color.blue(),
        )

        has_keys = bool(self.operator_key and self.environment_key)
        embed.add_field(
            name="🔑 Chaves Configuradas",
            value="✅ Sim" if has_keys else "❌ Nao",
            inline=True,
        )

        if has_keys:
            token = await self.get_auth_token()
            if token:
                embed.add_field(
                    name="🔐 Autenticacao",
                    value="✅ OK",
                    inline=True,
                )
                embed.add_field(
                    name="⏰ Token Expira",
                    value=(self.token_expires.strftime("%H:%M:%S")
                           if self.token_expires else "N/A"),
                    inline=True,
                )
                embed.color = discord.Color.green()
            else:
                embed.add_field(
                    name="🔐 Autenticacao",
                    value="❌ Falhou",
                    inline=True,
                )
                embed.color = discord.Color.red()

        embed.add_field(name="🌐 API URL", value=self.base_url, inline=False)
        await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    cog = DeskCog(bot)
    await bot.add_cog(cog)
    logger.info("Cog Desk carregado com sucesso")
