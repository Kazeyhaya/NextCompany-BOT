# Standard library
import asyncio
import json
import logging
import re
import ssl
from datetime import datetime, timedelta
from html import unescape
from typing import Any, Dict, List, Optional, Tuple

# Third-party
import aiohttp
import certifi
import discord
from discord import app_commands
from discord.ext import commands

# Local
from ..config import Config
from ..utils.helpers import fix_text

logger = logging.getLogger(__name__)

# Constants
OPERATORS_CACHE_TTL_SECONDS = 3600  # 1 hora em segundos
RATE_LIMIT_DELAY_SECONDS = 0.5  # 500ms entre requisições
EMBED_FIELD_MAX_LENGTH = 1000  # Tamanho máximo de campo em embed


class DeskCog(commands.Cog):
    """Integração com Desk.ms (tickets, relatórios e base de conhecimento)."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.base_url = Config.DESK_API_URL.rstrip("/")
        self.operator_key = Config.DESK_OPERATOR_KEY
        self.environment_key = Config.DESK_ENVIRONMENT_KEY
        self.token: Optional[str] = None
        self.token_expires: Optional[datetime] = None
        self._ssl_context: Optional[ssl.SSLContext] = None

        # Cache: {id: "Nome Sobrenome"}
        self.operators_cache: Dict[str, str] = {}
        self.operators_cache_time: Optional[datetime] = None

        # Rate limiting: {endpoint: last_request_time}
        self._rate_limits: Dict[str, datetime] = {}
        self._rate_limit_delay = RATE_LIMIT_DELAY_SECONDS

    def _normalize_operator_name(self, name: str) -> str:
        """Normaliza nomes de operadores conhecidos (corrige acentos, etc)"""
        if not name:
            return name

        # IMPORTANTE: Aplicar fix_text PRIMEIRO para corrigir encoding básico
        name = fix_text(str(name))

        # CORREÇÃO PRIORITÁRIA 1: "Joséé" -> "José" (duplicação do "é")
        # Deve vir primeiro para garantir que seja corrigido antes de outras correções
        if 'Joséé' in name or 'JOSÉÉ' in name or 'joséé' in name:
            name = name.replace('Joséé', 'José').replace('JOSÉÉ', 'JOSÉ').replace('joséé', 'josé')
            name = re.sub(r'Joséé', 'José', name, flags=re.IGNORECASE)

        # CORREÇÃO PRIORITÁRIA 2: "caro" no início -> "Ícaro"
        # Caso: "caro Matheus" -> "Ícaro Matheus"
        name_lower = name.lower().strip()
        if name_lower.startswith('caro'):
            if len(name) >= 4:
                if len(name) > 4 and name[4] == ' ':
                    name = 'Ícaro' + name[4:]
                elif len(name) > 4 and name[4].isupper():
                    name = 'Ícaro' + name[4:]
                elif len(name) > 4:
                    name = 'Ícaro ' + name[4:]
                else:
                    name = 'Ícaro'

        # CORREÇÃO ESPECÍFICA: "Jos Arimatia" / "Jos Arimteia" -> "José Arimáteia"
        # Deve vir antes das correções individuais para pegar o padrão completo
        name = re.sub(r'\bJos\s+Arim(?:at|te)ia\b', 'José Arimáteia', name, flags=re.IGNORECASE)

        # Corrigir "Joo" -> "João" (caso comum de corrupção)
        name = re.sub(r'\bJoo\b', 'João', name, flags=re.IGNORECASE)
        name = name.replace('Joo ', 'João ')
        name = name.replace('JOO ', 'JOÃO ')
        name = name.replace('joo ', 'joão ')
        name = name.replace('Joo\n', 'João\n')
        if name.startswith('Joo') or name.startswith('JOO') or name.startswith('joo'):
            name = re.sub(r'^Joo', 'João', name, flags=re.IGNORECASE)

        # Corrigir "Icaro" -> "Ícaro" (perda de acento) - mas não se já tiver "Ícaro"
        if 'Ícaro' not in name and 'ícaro' not in name:
            name = re.sub(r'\bIcaro\b', 'Ícaro', name, flags=re.IGNORECASE)
            name = name.replace('Icaro ', 'Ícaro ')
            name = name.replace('Icaro\n', 'Ícaro\n')
            if name.startswith('Icaro'):
                name = 'Ícaro' + name[5:]

        # Corrigir "Jos" -> "José" (perda do "é") - mas não se já começar com "José"
        if not name.startswith('José'):
            name = re.sub(r'\bJos\b', 'José', name, flags=re.IGNORECASE)
            name = name.replace('Jos ', 'José ')
            name = name.replace('Jos\n', 'José\n')
            if name.startswith('Jos'):
                name = 'José' + name[3:]

        # Corrigir "Arimatia" / "Arimteia" -> "Arimáteia" (perda de acentos)
        name = re.sub(r'\bArim(?:at|te)ia\b', 'Arimáteia', name, flags=re.IGNORECASE)
        name = name.replace('Arimatia', 'Arimáteia')
        name = name.replace('ARIMATIA', 'ARIMÁTEIA')
        name = name.replace('Arimteia', 'Arimáteia')
        name = name.replace('ARIMTEIA', 'ARIMÁTEIA')

        # Corrigir "Lucia" -> "Lúcia" (perda de acento)
        name = re.sub(r'\bLucia\b', 'Lúcia', name, flags=re.IGNORECASE)
        name = name.replace('Lucia', 'Lúcia')
        name = name.replace('LUCIA', 'LÚCIA')

        # Corrigir "Construcoes" -> "Construções" (perda de acentos)
        name = re.sub(r'\bConstrucoes\b', 'Construções', name, flags=re.IGNORECASE)
        name = name.replace('Construcoes', 'Construções')
        name = name.replace('CONSTRUCOES', 'CONSTRUÇÕES')
        name = name.replace('construcoes', 'construções')

        # Aplicar fix_text novamente no final para garantir todas as correções
        name = fix_text(name)

        # VERIFICAÇÃO FINAL: Se ainda tiver problemas conhecidos, forçar correção
        name_lower_final = name.lower().strip()

        # Verificação final para "caro" -> "Ícaro"
        if name_lower_final.startswith('caro') and 'ícaro' not in name_lower_final:
            if len(name) >= 4:
                if len(name) > 4 and name[4] == ' ':
                    name = 'Ícaro' + name[4:]
                elif len(name) > 4:
                    name = 'Ícaro ' + name[4:]
                else:
                    name = 'Ícaro'

        # Verificação final para "Jos Arimatia" / "Jos Arimteia" -> "José Arimáteia"
        if 'Jos' in name and ('Arimatia' in name or 'Arimteia' in name or 'arimatia' in name.lower() or 'arimteia' in name.lower()):
            name = re.sub(r'\bJos\s+Arim(?:at|te)ia\b', 'José Arimáteia', name, flags=re.IGNORECASE)
            name = name.replace('Jos Arimatia', 'José Arimáteia')
            name = name.replace('Jos Arimteia', 'José Arimáteia')
            name = name.replace('JOS ARIMATIA', 'JOSÉ ARIMÁTEIA')
            name = name.replace('JOS ARIMTEIA', 'JOSÉ ARIMÁTEIA')

        # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Joo" -> "João" (caso tenha passado despercebido)
        if 'Joo' in name or 'JOO' in name or 'joo' in name:
            name = re.sub(r'\bJoo\b', 'João', name, flags=re.IGNORECASE)
            name = name.replace('Joo ', 'João ').replace('JOO ', 'JOÃO ').replace('joo ', 'joão ')
            if name.startswith('Joo') or name.startswith('JOO') or name.startswith('joo'):
                name = re.sub(r'^Joo', 'João', name, flags=re.IGNORECASE)

        return name

    # --------------------------------------------------------------------- #
    # Infraestrutura / utilitários
    # --------------------------------------------------------------------- #

    def _get_ssl_context(self) -> ssl.SSLContext:
        if self._ssl_context is None:
            self._ssl_context = ssl.create_default_context(cafile=certifi.where())
        return self._ssl_context

    async def get_operators_cache(self) -> Dict[str, str]:
        """Busca e cacheia lista de operadores da API (cache de 1h)."""
        now = datetime.now()

        # Retorna cache se válido (menos de 1 hora)
        if (
            self.operators_cache
            and self.operators_cache_time
            and (now - self.operators_cache_time).total_seconds() < OPERATORS_CACHE_TTL_SECONDS
        ):
            logger.debug(
                "📋 Usando cache de operadores (%d operadores)",
                len(self.operators_cache),
            )
            return self.operators_cache

        try:
            logger.info("📥 Buscando lista de operadores da API...")
            payload = {
                "Colunas": {
                    "Chave": "on",
                    "Nome": "on",
                    "Sobrenome": "on",
                    "Email": "on",
                },
                "Pesquisa": "",
                "Ativo": "S",
                "Filtro": {},
                "Ordem": [{"Coluna": "Nome", "Direcao": True}],
            }

            response = await self.api_request("POST", "/Operadores/lista", json=payload)

            if response and response.get("root"):
                cache: Dict[str, str] = {}
                for op in response.get("root", []):
                    chave = str(op.get("Chave", ""))
                    nome = op.get("Nome", "") or ""
                    sobrenome = op.get("Sobrenome", "") or ""
                    nome_completo = f"{nome} {sobrenome}".strip()

                    if chave and nome_completo:
                        cache[chave] = nome_completo

                self.operators_cache = cache
                self.operators_cache_time = now
                logger.info("✅ Cache de operadores atualizado com %d itens", len(cache))
                return cache

            logger.warning("⚠️ Resposta vazia da API de operadores")
            return self.operators_cache or {}

        except Exception as e:  # pragma: no cover - proteção extra
            logger.error("❌ Erro ao buscar operadores: %s", e)
            return self.operators_cache or {}

    async def resolve_operator_name(self, operator_id: str) -> Optional[str]:
        """Resolve ID do operador para seu nome completo."""
        if not operator_id:
            return None

        cache = await self.get_operators_cache()
        operator_id_str = str(operator_id).strip()

        if operator_id_str in cache:
            logger.debug("✅ Operador %s resolvido: %s", operator_id_str, cache[operator_id_str])
            return cache[operator_id_str]

        logger.warning("⚠️ Operador %s não encontrado no cache", operator_id_str)
        return None

    @staticmethod
    def _limpar_html(texto: str) -> str:
        """Remove tags HTML e normaliza espaços."""
        if not texto:
            return ""
        texto = re.sub(r"<[^>]+>", "", texto)
        texto = unescape(texto)
        texto = re.sub(r"\s+", " ", texto).strip()
        return texto

    def _get_periodo_info(self, periodo: Optional[str] = None) -> Tuple[str, str, str]:
        """Retorna (data_inicio, data_fim, descricao_periodo) baseado em calendário."""
        from zoneinfo import ZoneInfo

        now = datetime.now(ZoneInfo("America/Sao_Paulo"))

        if not periodo:
            periodo = "semestre"

        periodo_lower = periodo.lower().strip()

        current_year = now.year
        if periodo_lower in ["semestre", "últimosemestre", "ultimo_semestre", "6m"]:
            # Semestre atual
            if now.month >= 7:
                data_inicio = now.replace(
                    month=7,
                    day=1,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                descricao = f"2º Semestre {current_year}"
            else:
                data_inicio = now.replace(
                    month=1,
                    day=1,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                descricao = f"1º Semestre {current_year}"
        elif periodo_lower in ["trimestre", "últimotrimestre", "ultimo_trimestre", "3m"]:
            # Trimestres: Q1(1-3), Q2(4-6), Q3(7-9), Q4(10-12)
            trimestre = (now.month - 1) // 3 + 1
            mes_inicio = (trimestre - 1) * 3 + 1
            data_inicio = now.replace(
                month=mes_inicio,
                day=1,
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )
            descricao = f"Q{trimestre} {current_year}"
        elif periodo_lower in ["mês", "mes", "meses", "últimomês", "ultimo_mes", "1m"]:
            data_inicio = now.replace(
                day=1,
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )
            descricao = now.strftime("Mês atual (%B)")
        elif periodo_lower in ["semana", "últimasemana", "ultima_semana", "7d"]:
            data_inicio = now - timedelta(days=7)
            descricao = "Últimos 7 dias"
        elif periodo_lower in ["hoje", "today", "1d"]:
            data_inicio = now.replace(
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )
            descricao = "Hoje"
        else:
            # Padrão: semestre atual
            if now.month >= 7:
                data_inicio = now.replace(
                    month=7,
                    day=1,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                descricao = f"2º Semestre {current_year}"
            else:
                data_inicio = now.replace(
                    month=1,
                    day=1,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                descricao = f"1º Semestre {current_year}"

        data_inicio_str = data_inicio.strftime("%d/%m/%Y")
        data_fim_str = now.strftime("%d/%m/%Y")
        return data_inicio_str, data_fim_str, descricao

    async def get_auth_token(self, retry_count: int = 0) -> Optional[str]:
        """Obter token de autenticação da API Desk (com cache e retry)."""
        if self.token and self.token_expires and datetime.now() < self.token_expires:
            logger.debug("🔑 Usando token em cache")
            return self.token

        if not self.operator_key or not self.environment_key:
            logger.error("❌ Chaves de API não configuradas")
            return None

        max_retries = 3

        try:
            url = f"{self.base_url}/Login/autenticar"
            headers = {
                "Authorization": self.operator_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
            payload = {"PublicKey": self.environment_key}

            logger.info("🔑 Autenticando na API Desk: %s", url)
            if self.operator_key:
                logger.debug(
                    "Headers: Authorization=***%s", self.operator_key[-8:]
                )

            timeout = aiohttp.ClientTimeout(total=30, connect=10)
            ssl_context = self._get_ssl_context()

            session = getattr(self.bot, 'session', None)  # type: ignore[attr-defined]
            if not session:
                logger.error("❌ Bot session não disponível")
                return None

            async with session.post(
                url,
                json=payload,
                headers=headers,
                timeout=timeout,
                ssl=ssl_context,
            ) as resp:
                content_type = resp.headers.get("Content-Type", "")
                text = await resp.text()

                logger.debug("Status: %s, Content-Type: %s", resp.status, content_type)
                logger.debug("Resposta (primeiros 200 chars): %s", text[:200])

                if resp.status == 200:
                    token: Optional[str] = None

                    if "application/json" in content_type:
                        try:
                            data = json.loads(text)
                            if isinstance(data, dict):
                                token = (
                                    data.get("access_token")
                                    or data.get("token")
                                    or data.get("accessToken")
                                )
                                if data.get("erro"):
                                    logger.error(
                                        "❌ API retornou erro: %s", data.get("erro")
                                    )
                                    return None
                            elif isinstance(data, str):
                                token = data
                        except json.JSONDecodeError:
                            text_clean = text.strip().strip('"')
                            if text_clean and not text_clean.startswith("<") and len(
                                text_clean
                            ) > 20:
                                token = text_clean
                    else:
                        text_clean = text.strip().strip('"')
                        if text_clean and not text_clean.startswith("<") and len(
                            text_clean
                        ) > 20:
                            token = text_clean

                    if token:
                        self.token = token
                        self.token_expires = datetime.now() + timedelta(hours=1)
                        logger.info("✅ Token obtido com sucesso! Válido por 1 hora")
                        logger.debug(
                            "Token: %s...%s", self.token[:20], self.token[-8:]
                        )
                        return self.token

                    logger.error("❌ Token não encontrado na resposta")
                    logger.error("Content-Type: %s", content_type)
                    logger.error("Resposta: %s", text[:300])
                    return None

                logger.error("❌ Erro ao autenticar: HTTP %s", resp.status)
                logger.error("Content-Type: %s", content_type)
                logger.error("Resposta: %s", text[:300])

                if resp.status in (500, 502, 503, 504) and retry_count < max_retries:
                    import asyncio

                    logger.warning(
                        "⚠️ Tentando novamente... (%d/%d)",
                        retry_count + 1,
                        max_retries,
                    )
                    await asyncio.sleep(2**retry_count)
                    return await self.get_auth_token(retry_count + 1)

                return None

        except aiohttp.ClientSSLError as e:
            logger.error("❌ Erro SSL na conexão: %s", e)
            if retry_count < max_retries:
                logger.warning(
                    "⚠️ Tentando novamente com SSL... (%d/%d)",
                    retry_count + 1,
                    max_retries,
                )
                await asyncio.sleep(2**retry_count)  # type: ignore[attr-defined]
                return await self.get_auth_token(retry_count + 1)
            return None

        except aiohttp.ClientConnectorError as e:
            logger.error("❌ Erro de conexão com API Desk: %s", e)
            if retry_count < max_retries:
                logger.warning(
                    "⚠️ Tentando reconectar... (%d/%d)",
                    retry_count + 1,
                    max_retries,
                )
                await asyncio.sleep(2**retry_count)  # type: ignore[attr-defined]
                return await self.get_auth_token(retry_count + 1)
            return None

        except aiohttp.ClientError as e:
            logger.error("❌ Erro de cliente HTTP: %s", e)
            return None

        except Exception as e:  # pragma: no cover - fallback
            logger.error("❌ Erro inesperado ao obter token: %s: %s", type(e).__name__, e)
            return None

    async def api_request(
        self,
        method: str,
        endpoint: str,
        retry_count: int = 0,
        **kwargs: Any,
    ) -> Optional[Dict[str, Any]]:
        """Fazer requisição à API do Desk com retry e rate limiting."""
        token = await self.get_auth_token()
        if not token:
            logger.error("❌ Não foi possível obter token de autenticação")
            return None

        max_retries = 3

        # Rate limiting: aguardar se necessário
        endpoint_key = f"{method}:{endpoint}"
        if endpoint_key in self._rate_limits:
            last_request = self._rate_limits[endpoint_key]
            time_since_last = (datetime.now() - last_request).total_seconds()
            if time_since_last < self._rate_limit_delay:
                wait_time = self._rate_limit_delay - time_since_last
                await asyncio.sleep(wait_time)  # type: ignore[attr-defined]

        self._rate_limits[endpoint_key] = datetime.now()

        try:
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
            headers = {
                "Authorization": token,
                "Content-Type": "application/json",
                "Accept": "application/json",
            }

            logger.info("🔗 Requisição API: %s %s", method, url)

            if "json" in kwargs:
                try:
                    logger.info(
                        "📤 Payload: %s",
                        json.dumps(kwargs["json"], ensure_ascii=False),
                    )
                except Exception:
                    logger.debug("📤 Payload (não serializável para log)")

            timeout = aiohttp.ClientTimeout(total=30, connect=10)
            ssl_context = self._get_ssl_context()

            session = getattr(self.bot, 'session', None)  # type: ignore[attr-defined]
            if not session:
                logger.error("❌ Bot session não disponível")
                return None

            async with session.request(
                method,
                url,
                headers=headers,
                timeout=timeout,
                ssl=ssl_context,
                **kwargs,
            ) as resp:
                text = await resp.text()

                if resp.status == 401:
                    logger.warning("⚠️ Token expirado ou inválido, tentando renovar...")
                    self.token = None
                    self.token_expires = None
                    if retry_count < 1:
                        return await self.api_request(
                            method,
                            endpoint,
                            retry_count + 1,
                            **kwargs,
                        )
                    return None

                if resp.status in (500, 502, 503, 504) and retry_count < max_retries:
                    import asyncio

                    logger.warning(
                        "⚠️ Servidor indisponível, tentando novamente... (%d/%d)",
                        retry_count + 1,
                        max_retries,
                    )
                    await asyncio.sleep(2**retry_count)
                    return await self.api_request(
                        method,
                        endpoint,
                        retry_count + 1,
                        **kwargs,
                    )

                try:
                    data = json.loads(text)
                    if isinstance(data, dict):
                        if data.get("erro"):
                            logger.warning("⚠️ API retornou erro: %s", data.get("erro"))
                        total = data.get("total", "N/A")
                        root_count = (
                            len(data.get("root", []))
                            if isinstance(data.get("root"), list)
                            else 0
                        )
                        logger.info(
                            "📥 Resposta: total=%s, root_count=%s",
                            total,
                            root_count,
                        )
                        if root_count > 0:
                            sample = data["root"][0]
                            logger.info("📋 Campos: %s", list(sample.keys()))
                    return data  # type: ignore[return-value]

                except json.JSONDecodeError:
                    if "<html" in text.lower():
                        logger.error("❌ API retornou HTML em vez de JSON")
                        self.token = None
                        self.token_expires = None
                    else:
                        logger.error("❌ Erro ao parsear resposta: %s", text[:200])
                    return None

        except aiohttp.ClientConnectorError as e:
            logger.error("❌ Erro de conexão: %s", e)
            if retry_count < max_retries:
                import asyncio

                logger.warning(
                    "⚠️ Tentando reconectar... (%d/%d)",
                    retry_count + 1,
                    max_retries,
                )
                await asyncio.sleep(2**retry_count)
                return await self.api_request(
                    method,
                    endpoint,
                    retry_count + 1,
                    **kwargs,
                )
            return None

        except aiohttp.ClientError as e:
            logger.error("❌ Erro de conexão: %s", e)
            return None

        except Exception as e:  # pragma: no cover - fallback
            logger.error("❌ Erro na requisição API: %s: %s", type(e).__name__, e)
            return None

    # --------------------------------------------------------------------- #
    # Comandos de texto (prefixo)
    # --------------------------------------------------------------------- #

    @commands.command(name="desk-status")
    async def desk_status(self, ctx: commands.Context) -> None:
        """Verificar status da conexão com Desk.ms."""
        async with ctx.typing():
            embed = discord.Embed(
                title="🔍 Status da Conexão Desk.ms",
                color=discord.Color.blue(),
            )

            has_keys = bool(self.operator_key and self.environment_key)
            embed.add_field(
                name="Chaves Configuradas",
                value="✅ Sim" if has_keys else "❌ Não",
                inline=True,
            )

            if has_keys:
                token = await self.get_auth_token()
                if token:
                    embed.add_field(
                        name="Autenticação",
                        value="✅ OK",
                        inline=True,
                    )
                    embed.add_field(
                        name="Token Expira",
                        value=(
                            self.token_expires.strftime("%H:%M:%S")
                            if self.token_expires
                            else "N/A"
                        ),
                        inline=True,
                    )
                    embed.color = discord.Color.green()

                    # Usar exatamente o mesmo payload e lógica do !tickets que funciona
                    payload = {
                        "Pesquisa": "",
                        "Tatual": "",
                        "Ativo": "Todos",
                        "StatusSLA": "N",
                        "Colunas": {
                            "Chave": "on",
                            "CodChamado": "on",
                            "NomePrioridade": "on",
                            "DataCriacao": "on",
                            "HoraCriacao": "on",
                            "NomeStatus": "on",
                            "Assunto": "on",
                            "NomeUsuario": "on",
                            "SobrenomeUsuario": "on",
                            "NomeOperador": "on",
                            "SobrenomeOperador": "on",
                        },
                        "Ordem": [
                            {
                                "Coluna": "DataCriacao",
                                "Direcao": "false",
                            }
                        ],
                    }

                    response = await self.api_request(
                        "POST", "/ChamadosSuporte/lista", json=payload
                    )

                    if not response or response.get("erro"):
                        erro = response.get("erro") if response else "Erro na consulta"
                        embed.add_field(
                            name="Tickets",
                            value=f"⚠️ {erro}",
                            inline=True,
                        )
                        embed.color = discord.Color.orange()
                    else:
                        todos_Tickets = response.get("root", [])
                        total = response.get("total", len(todos_Tickets) if todos_Tickets else 0)
                        root_count = len(todos_Tickets) if isinstance(todos_Tickets, list) else 0

                        embed.add_field(
                            name="Tickets Disponíveis",
                            value=f"✅ {total} (retornou {root_count})",
                            inline=True,
                        )

                        if root_count > 0 and isinstance(todos_Tickets, list):
                            sample = todos_Tickets[0]
                            cod = sample.get("CodChamado", "N/A")
                            embed.add_field(
                                name="Exemplo de ID",
                                value=cod,
                                inline=True,
                            )
                else:
                    embed.add_field(
                        name="Autenticação",
                        value="❌ Falhou",
                        inline=True,
                    )
                    embed.color = discord.Color.red()

            embed.add_field(name="API URL", value=self.base_url, inline=False)
            await ctx.send(embed=embed)

    @commands.command(name="ticket")
    async def consultar_ticket(self, ctx: commands.Context, ticket_id: str) -> None:
        """Consultar informações de um ticket."""
        async with ctx.typing():
            logger.info("🔍 Buscando ticket: %s", ticket_id)

            payload = {
                "Pesquisa": ticket_id,
                "Tatual": "",
                "Ativo": "Todos",
                "StatusSLA": "N",
                "Colunas": {
                    "Chave": "on",
                    "CodChamado": "on",
                    "NomePrioridade": "on",
                    "DataCriacao": "on",
                    "HoraCriacao": "on",
                    "NomeStatus": "on",
                    "Assunto": "on",
                    "NomeUsuario": "on",
                    "SobrenomeUsuario": "on",
                    "NomeOperador": "on",
                    "SobrenomeOperador": "on",
                },
                "Ordem": [
                    {
                        "Coluna": "DataCriacao",
                        "Direcao": "false",
                    }
                ],
            }
            response = await self.api_request(
                "POST", "/ChamadosSuporte/lista", json=payload
            )

            if not response:
                await ctx.send("❌ Erro ao conectar com a API")
                return

            if response.get("erro"):
                await ctx.send(f"❌ Erro da API: {response.get('erro')}")
                return

            Tickets = response.get("root", [])
            total = response.get("total", 0)
            logger.info("📋 Resposta com pesquisa '%s': %s ticket(s)", ticket_id, total)

            if not Tickets:
                payload_all = {
                    "Pesquisa": "",
                    "Tatual": "",
                    "Ativo": "Todos",
                    "StatusSLA": "N",
                    "Colunas": {
                        "Chave": "on",
                        "CodChamado": "on",
                        "NomePrioridade": "on",
                        "DataCriacao": "on",
                        "HoraCriacao": "on",
                        "NomeStatus": "on",
                        "Assunto": "on",
                        "NomeUsuario": "on",
                        "SobrenomeUsuario": "on",
                        "NomeOperador": "on",
                        "SobrenomeOperador": "on",
                    },
                    "Ordem": [
                        {
                            "Coluna": "DataCriacao",
                            "Direcao": "false",
                        }
                    ],
                }
                response_all = await self.api_request(
                    "POST", "/ChamadosSuporte/lista", json=payload_all
                )
                if response_all and response_all.get("root"):
                    Tickets = response_all.get("root", [])
                    total = response_all.get("total", 0)
                    logger.info("📋 Buscando em todos os %s Tickets...", total)

            if Tickets:
                sample = Tickets[0]
                logger.info("🔑 Campos do ticket: %s", list(sample.keys()))
                logger.info("📝 CodChamado exemplo: %s", sample.get("CodChamado"))

            data = None
            ticket_id_clean = ticket_id.replace("-", "").lower().strip()
            ticket_id_numbers = "".join(filter(str.isdigit, ticket_id))

            for ticket in Tickets:
                cod = str(ticket.get("CodChamado", "")).lower()
                chave = str(ticket.get("Chave", "")).lower()
                cod_clean = cod.replace("-", "")
                chave_clean = chave.replace("-", "")
                cod_numbers = "".join(filter(str.isdigit, cod))

                if ticket_id_clean == cod_clean or ticket_id_clean == chave_clean:
                    data = ticket
                    logger.info("✅ Match exato: %s", cod)
                    break
                if ticket_id_clean in cod_clean or ticket_id_clean in chave_clean:
                    data = ticket
                    logger.info("✅ Match parcial: %s", cod)
                    break
                if ticket_id_numbers and ticket_id_numbers in cod_numbers:
                    data = ticket
                    logger.info("✅ Match numérico: %s", cod)
                    break

            if not data:
                await ctx.send(f"❌ Ticket `{ticket_id}` não encontrado")
                return

            assunto = data.get("Assunto", "Sem assunto")
            nome_status = data.get("NomeStatus", "")
            if isinstance(nome_status, list) and nome_status:
                status = nome_status[0].get("text", "Desconhecido")
            elif isinstance(nome_status, str) and nome_status:
                status = nome_status
            else:
                status = "Desconhecido"

            nome_usuario = data.get("NomeUsuario", "") or ""
            sobrenome_usuario = data.get("SobrenomeUsuario", "") or ""
            cliente = (f"{nome_usuario} {sobrenome_usuario}".strip()) or "Não informado"

            prioridade = data.get("NomePrioridade", "---")

            nome_operador = data.get("NomeOperador", "") or ""
            sobrenome_operador = data.get("SobrenomeOperador", "") or ""
            analista = (
                f"{nome_operador} {sobrenome_operador}".strip() or "Não atribuído"
            )

            descricao = (data.get("Descricao", "") or "")[:200]
            data_criacao = data.get("DataCriacao", "---")

            status_lower = status.lower()
            if any(x in status_lower for x in ["resolvido", "finalizado", "encerrado"]):
                emoji, cor = "✅", discord.Color.green()
            elif any(x in status_lower for x in ["cancelado", "rejeitado"]):
                emoji, cor = "❌", discord.Color.red()
            elif any(x in status_lower for x in ["andamento", "atendimento"]):
                emoji, cor = "🔧", discord.Color.orange()
            else:
                emoji, cor = "🆕", discord.Color.blue()

            embed = discord.Embed(
                title=f"Ticket #{ticket_id}",
                description=f"{emoji} **{assunto}**",
                color=cor,
            )
            embed.add_field(name="Status", value=status, inline=True)
            embed.add_field(name="Prioridade", value=prioridade, inline=True)
            embed.add_field(name="Cliente", value=cliente, inline=False)
            embed.add_field(name="Analista", value=analista, inline=True)
            embed.add_field(name="Criado em", value=data_criacao, inline=True)
            if descricao:
                embed.add_field(
                    name="Descrição",
                    value=descricao,
                    inline=False,
                )

            embed.set_footer(text="Desk.ms Integration")
            await ctx.send(embed=embed)

    @commands.command(name="Tickets-fechados")
    async def listar_Tickets_fechados(self, ctx: commands.Context) -> None:
        """Listar últimos tickets fechados do sistema."""
        async with ctx.typing():
            payload = {
                "Pesquisa": "",
                "Tatual": "",
                "Ativo": "Todos",
                "StatusSLA": "N",
                "Colunas": {
                    "Chave": "on",
                    "CodChamado": "on",
                    "NomePrioridade": "on",
                    "DataCriacao": "on",
                    "HoraCriacao": "on",
                    "NomeStatus": "on",
                    "Assunto": "on",
                    "NomeUsuario": "on",
                    "SobrenomeUsuario": "on",
                    "NomeOperador": "on",
                    "SobrenomeOperador": "on",
                },
                "Ordem": [
                    {
                        "Coluna": "DataCriacao",
                        "Direcao": "false",
                    }
                ],
            }
            response = await self.api_request(
                "POST", "/ChamadosSuporte/lista", json=payload
            )

            if not response or response.get("erro"):
                erro = response.get("erro") if response else "Nenhum ticket encontrado"
                await ctx.send(f"📋 {erro}")
                return

            Tickets_fechados: List[Dict[str, Any]] = []
            for ticket in response.get("root", []):
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "").lower()
                    if any(
                        x in status_text
                        for x in ["resolvido", "finalizado", "encerrado", "fechado"]
                    ):
                        Tickets_fechados.append(ticket)
                if len(Tickets_fechados) >= 10:
                    break

            if not Tickets_fechados:
                await ctx.send("📋 Nenhum ticket fechado encontrado.")
                return

            embed = discord.Embed(
                title=f"✅ Últimos Tickets Fechados ({len(Tickets_fechados)})",
                color=discord.Color.green(),
            )

            for ticket in Tickets_fechados:
                id_ticket = str(ticket.get("CodChamado", "N/A"))
                assunto = (ticket.get("Assunto", "Sem assunto") or "")[:50]
                nome_status = ticket.get("NomeStatus", [])
                status = (
                    nome_status[0].get("text", "---")
                    if isinstance(nome_status, list) and nome_status
                    else "---"
                )
                prioridade = ticket.get("NomePrioridade", "---")

                embed.add_field(
                    name=f"#{id_ticket} - {assunto}",
                    value=f"**Status:** {status} | **Prioridade:** {prioridade}",
                    inline=False,
                )

            embed.set_footer(text="Use !ticket [ID] para mais detalhes")
            await ctx.send(embed=embed)

    @commands.command(name="tickets", aliases=["Tickets"])
    async def pesquisar_Tickets_usuario(
        self,
        ctx: commands.Context,
        *,
        filtro: Optional[str] = None,
    ) -> None:
        """Listar tickets em aberto (ou filtrar por status).

        Uso:
        - `!Tickets` - Tickets em aberto
        - `!Tickets [status]` - Tickets com esse status (ex: resolvido, andamento)
        """
        async with ctx.typing():
            payload = {
                "Pesquisa": "",
                "Tatual": "",
                "Ativo": "Todos",
                "StatusSLA": "N",
                "Colunas": {
                    "Chave": "on",
                    "CodChamado": "on",
                    "NomePrioridade": "on",
                    "DataCriacao": "on",
                    "HoraCriacao": "on",
                    "NomeStatus": "on",
                    "Assunto": "on",
                    "NomeUsuario": "on",
                    "SobrenomeUsuario": "on",
                    "NomeOperador": "on",
                    "SobrenomeOperador": "on",
                },
                "Ordem": [
                    {
                        "Coluna": "DataCriacao",
                        "Direcao": "false",
                    }
                ],
            }
            response = await self.api_request(
                "POST", "/ChamadosSuporte/lista", json=payload
            )

            if not response or response.get("erro"):
                erro = response.get("erro") if response else "Nenhum ticket encontrado"
                await ctx.send(f"📋 {erro}")
                return

            todos_Tickets = response.get("root", [])

            if not todos_Tickets:
                await ctx.send("📋 Nenhum ticket encontrado.")
                return

            if filtro:
                filtro_lower = filtro.lower()
                Tickets_filtrados: List[Dict[str, Any]] = []
                for ticket in todos_Tickets:
                    nome_status = ticket.get("NomeStatus", [])
                    if isinstance(nome_status, list) and nome_status:
                        status_text = nome_status[0].get("text", "").lower()
                    else:
                        status_text = (
                            str(nome_status).lower() if nome_status else ""
                        )

                    if filtro_lower in status_text:
                        Tickets_filtrados.append(ticket)

                if not Tickets_filtrados:
                    await ctx.send(
                        f"📋 Nenhum ticket encontrado com status `{filtro}`"
                    )
                    return

                Tickets_final = Tickets_filtrados[:25]
                titulo = (
                    f"🔍 Tickets com Status '{filtro}' ({len(Tickets_final)})"
                )
            else:
                Tickets_abertos: List[Dict[str, Any]] = []
                for ticket in todos_Tickets:
                    nome_status = ticket.get("NomeStatus", [])
                    if isinstance(nome_status, list) and nome_status:
                        status_text = nome_status[0].get("text", "").lower()
                    else:
                        status_text = (
                            str(nome_status).lower() if nome_status else ""
                        )

                    if not any(
                        x in status_text
                        for x in [
                            "resolvido",
                            "finalizado",
                            "encerrado",
                            "fechado",
                            "cancelado",
                            "rejeitado",
                        ]
                    ):
                        Tickets_abertos.append(ticket)

                if not Tickets_abertos:
                    await ctx.send("✅ Nenhum ticket em aberto! Parabéns!")
                    return

                Tickets_final = Tickets_abertos[:25]
                titulo = f"🆕 Tickets em Aberto ({len(Tickets_final)})"

            embed = discord.Embed(title=titulo, color=discord.Color.blue())

            for ticket in Tickets_final:
                id_ticket = str(ticket.get("CodChamado", "N/A"))
                assunto = (ticket.get("Assunto", "Sem assunto") or "")[:50]
                nome_status = ticket.get("NomeStatus", [])
                status = (
                    nome_status[0].get("text", "---")
                    if isinstance(nome_status, list) and nome_status
                    else "---"
                )
                prioridade = ticket.get("NomePrioridade", "---")

                embed.add_field(
                    name=f"#{id_ticket} - {assunto}",
                    value=f"**Status:** {status} | **Prioridade:** {prioridade}",
                    inline=False,
                )

            embed.set_footer(text="Use !ticket [ID] para mais detalhes")
            await ctx.send(embed=embed)

    @commands.command(name="abrir-ticket")
    async def abrir_ticket(
        self,
        ctx: commands.Context,
        *,
        assunto: str,
    ) -> None:
        """Abrir um novo ticket."""
        if len(assunto) > 200:
            await ctx.send("❌ O assunto não pode ter mais de 200 caracteres.")
            return

        async with ctx.typing():
            payload = {
                "assunto": assunto,
                "usuario_nome": ctx.author.display_name,
                "descr": f"Aberto via Discord por {ctx.author.display_name}",
            }

            result = await self.api_request("POST", "/Tickets", json=payload)

            if not result or result.get("erro"):
                erro = result.get("erro") if result else "Erro ao criar ticket"
                await ctx.send(f"❌ {erro}")
                return

            ticket_id = result.get("chamado_cod", result.get("id", "N/A"))
            embed = discord.Embed(
                title="✅ Ticket Criado com Sucesso!",
                description=f"**ID do Ticket:** #{ticket_id}",
                color=discord.Color.green(),
            )
            embed.add_field(name="Assunto", value=assunto, inline=False)
            embed.add_field(
                name="Próximo Passo",
                value=f"Use `!ticket {ticket_id}` para acompanhar",
                inline=False,
            )
            await ctx.send(embed=embed)

    # --------------------------------------------------------------------- #
    # Rotina de relatório diário
    # --------------------------------------------------------------------- #
    # Nota: A implementação completa está mais abaixo (linha ~2502)

    # --------------------------------------------------------------------- #
    # Base de conhecimento
    # --------------------------------------------------------------------- #

    @commands.command(name="kb-search")
    async def pesquisar_base_conhecimento(
        self,
        ctx: commands.Context,
        *,
        termo: str,
    ) -> None:
        """Pesquisar na base de conhecimento."""
        async with ctx.typing():
            logger.info("🔍 Pesquisando base de conhecimento: %s", termo)

            payload = {
                "Pesquisa": termo,
                "Ordem": [
                    {
                        "Coluna": "Titulo",
                        "Direcao": "true",
                    }
                ],
            }
            response = await self.api_request(
                "POST", "/BaseConhecimento/lista", json=payload
            )

            if not response:
                await ctx.send("❌ Erro ao conectar com a base de conhecimento")
                return

            if response.get("erro"):
                await ctx.send(f"❌ Erro: {response.get('erro')}")
                return

            artigos = response.get("root", [])
            total = response.get("total", 0)
            logger.info("📚 Encontrados %s artigos para '%s'", total, termo)

            if not artigos:
                await ctx.send(f"❌ Nenhum artigo encontrado para '{termo}'")
                return

            embed = discord.Embed(
                title="📚 Base de Conhecimento - Resultados",
                description=f"Pesquisa: `{termo}`\nEncontrados: {total} artigos",
                color=discord.Color.blue(),
            )

            for artigo in artigos[:10]:
                chave = artigo.get("Chave", "N/A")
                titulo = artigo.get("Titulo", "Sem título")
                categorias = artigo.get("Categoria", [])
                categoria_text = (
                    categorias[0].get("text", "---") if categorias else "---"
                )
                palavras_chave = artigo.get("PalavrasChave", "")

                valor = f"**Categoria:** {categoria_text}\n"
                if palavras_chave:
                    valor += f"**Tags:** {palavras_chave}"

                embed.add_field(
                    name=f"#{chave} - {titulo[:50]}",
                    value=valor,
                    inline=False,
                )

            embed.set_footer(
                text=(
                    "Use !kb-artigo [ID] para mais detalhes "
                    f"| Total: {total} artigos"
                )
            )
            await ctx.send(embed=embed)

    @commands.command(name="kb-artigo")
    async def ver_artigo_conhecimento(
        self,
        ctx: commands.Context,
        chave: str,
    ) -> None:
        """Ver artigo específico da base de conhecimento."""
        async with ctx.typing():
            chave_limpa = chave.replace("#", "").strip()
            logger.info("📖 Consultando artigo KB: %s (limpa: %s)", chave, chave_limpa)

            payload = {"Chave": chave_limpa}
            response = await self.api_request(
                "POST",
                "/BaseConhecimento",
                json=payload,
            )

            if not response:
                await ctx.send("❌ Erro ao conectar com a base de conhecimento")
                return

            logger.debug("📝 Resposta completa: %s", response)
            artigo = response.get("TBaseConhecimento")
            if not artigo:
                logger.warning(
                    "⚠️ Artigo %s não encontrado. Keys: %s",
                    chave_limpa,
                    list(response.keys()),
                )
                await ctx.send(f"❌ Artigo #{chave_limpa} não encontrado")
                return

            titulo = artigo.get("Titulo", "Sem título")
            categorias = artigo.get("Categoria", [])
            categoria_text = (
                categorias[0].get("text", "---") if categorias else "---"
            )
            palavras_chave = artigo.get("PalavrasChave", "")
            conteudo = artigo.get("Conteudo", "") or artigo.get("Comentarios", "")
            link_externo = artigo.get("LinkExterno", "")
            link_direto = artigo.get("LinkDireto", "")
            aprovador = artigo.get("Aprovador", "N/A")
            publico = artigo.get("Publico", "N") == "S"
            visivel_operadores = artigo.get("VisivelTodosOperadores", "N") == "S"
            visivel_usuarios = artigo.get("VisivelTodosUsuarios", "N") == "S"
            cat_adicionais = artigo.get("CatAdicionais", "")

            embed = discord.Embed(
                title=f"📖 {titulo}",
                color=discord.Color.blurple(),
            )

            embed.add_field(name="ID", value=f"#{chave}", inline=True)
            embed.add_field(name="Categoria", value=categoria_text, inline=True)

            if cat_adicionais:
                embed.add_field(
                    name="Categorias Adicionais",
                    value=cat_adicionais,
                    inline=True,
                )

            perms: List[str] = []
            if publico:
                perms.append("🌐 Pública")
            if visivel_operadores:
                perms.append("👨‍💼 Todos Operadores")
            if visivel_usuarios:
                perms.append("👥 Todos Usuários")
            if perms:
                embed.add_field(
                    name="Visibilidade",
                    value=" | ".join(perms),
                    inline=False,
                )

            cod_clientes = artigo.get("CodCliente", [])
            cod_depts = artigo.get("CodDepartamento", [])
            cod_grupos = artigo.get("CodGrupo", [])

            if cod_clientes:
                clientes_text = ", ".join(
                    [c.get("text", "") for c in cod_clientes[:3]]
                )
                if len(cod_clientes) > 3:
                    clientes_text += f" +{len(cod_clientes) - 3}"
                embed.add_field(
                    name="Clientes Autorizados",
                    value=clientes_text,
                    inline=True,
                )

            if cod_depts:
                depts_text = ", ".join([d.get("text", "") for d in cod_depts[:2]])
                if len(cod_depts) > 2:
                    depts_text += f" +{len(cod_depts) - 2}"
                embed.add_field(
                    name="Departamentos",
                    value=depts_text,
                    inline=True,
                )

            if cod_grupos:
                grupos_text = ", ".join([g.get("text", "") for g in cod_grupos[:2]])
                if len(cod_grupos) > 2:
                    grupos_text += f" +{len(cod_grupos) - 2}"
                embed.add_field(
                    name="Grupos de Atendimento",
                    value=grupos_text,
                    inline=True,
                )

            if palavras_chave:
                embed.add_field(
                    name="Tags",
                    value=palavras_chave,
                    inline=False,
                )

            if conteudo:
                conteudo_limpo = self._limpar_html(conteudo)
                if len(conteudo_limpo) > 500:
                    conteudo_truncado = conteudo_limpo[:500] + "..."
                else:
                    conteudo_truncado = conteudo_limpo
                embed.add_field(
                    name="Conteúdo",
                    value=conteudo_truncado,
                    inline=False,
                )

            links_text = ""
            if link_direto:
                links_text += f"🔗 [Visualizar Artigo]({link_direto})\n"
            if link_externo:
                links_text += f"🌐 [Link Externo]({link_externo})"

            if links_text:
                embed.add_field(
                    name="📌 Acesso Rápido",
                    value=links_text,
                    inline=False,
                )

            embed.set_footer(text=f"Desk.ms Knowledge Base • Aprovador: {aprovador}")
            await ctx.send(embed=embed)

    # --------------------------------------------------------------------- #
    # Funções de apoio a relatórios
    # --------------------------------------------------------------------- #

    async def _buscar_relatorio_slideshow(
        self,
        data_inicio: str,
        data_fim: str,
    ) -> Dict[str, Any]:
        """Busca dados de relatório via endpoint SlideShow (sem limite de 3000)."""
        try:
            _ = datetime.strptime(data_inicio, "%d/%m/%Y")
            _ = datetime.strptime(data_fim, "%d/%m/%Y")
            logger.info(
                "📅 Tentando SlideShow com período: %s a %s",
                data_inicio,
                data_fim,
            )
        except Exception as e:
            logger.error("❌ Erro ao parsear datas: %s", e)
            return {}

        for chave in ["Tickets", ""]:
            try:
                payload = {"Chave": chave}
                logger.info("🔍 SlideShow com Chave='%s'...", chave)
                response = await self.api_request("POST", "/SlideShow", json=payload)

                if response and not response.get("erro"):
                    logger.info("✅ SlideShow %s disponível!", chave)
                    return response.get("rSlideShow", response)
            except Exception as e:  # pragma: no cover - fallback
                logger.debug("⚠️ SlideShow falhou com Chave='%s': %s", chave, e)

        logger.warning("⚠️ SlideShow não funcionou, usando ChamadosSuporte/lista")
        return {}

    @staticmethod
    def _parse_date_flexible(data_str: str) -> Optional[datetime]:
        """Parse flexível para múltiplos formatos de data do Desk.ms."""
        if not data_str or not isinstance(data_str, str):
            return None

        data_str = data_str.strip()

        formatos = [
            "%d/%m/%Y %H:%M:%S",
            "%d/%m/%Y %H:%M",
            "%d/%m/%Y",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S.%fZ",
        ]

        for formato in formatos:
            try:
                return datetime.strptime(data_str, formato)
            except ValueError:
                continue

        return None

    async def _buscar_todos_Tickets(
        self,
        data_inicio: str,
        data_fim: str,
    ) -> List[Dict[str, Any]]:
        """Retorna tickets filtrando por período usando filtro da API + filtro local."""
        try:
            data_inicio_obj = datetime.strptime(data_inicio, "%d/%m/%Y")
            data_fim_obj = datetime.strptime(data_fim, "%d/%m/%Y").replace(
                hour=23,
                minute=59,
                second=59,
            )
        except Exception as e:
            logger.error("❌ Erro ao parsear datas do período: %s", e)
            return []

        payload = {
            "Pesquisa": "",
            "Tatual": "",
            "Ativo": "Todos",
            "StatusSLA": "N",
            "Colunas": {
                "Chave": "on",
                "CodChamado": "on",
                "NomePrioridade": "on",
                "DataCriacao": "on",
                "HoraCriacao": "on",
                "NomeStatus": "on",
                "Assunto": "on",
                "NomeUsuario": "on",
                "SobrenomeUsuario": "on",
                "NomeOperador": "on",
                "SobrenomeOperador": "on",
            },
            "Ordem": [
                {
                    "Coluna": "DataCriacao",
                    "Direcao": "false",
                }
            ],
            "Filtro": {
                "DataCriacao": {
                    "Inicio": data_inicio,
                    "Fim": f"{data_fim} 23:59:59",
                }
            },
        }

        response = await self.api_request(
            "POST",
            "/ChamadosSuporte/lista",
            json=payload,
        )

        if not response or response.get("erro"):
            logger.error(
                "❌ Erro ao buscar Tickets: %s",
                response.get("erro") if response else "Sem resposta",
            )
            return []

        todos_Tickets = response.get("root", [])
        total_api_raw = response.get("total", len(todos_Tickets))
        total_api = int(total_api_raw) if total_api_raw else len(todos_Tickets)
        logger.info(
            "📥 API retornou %s de %s Tickets (filtro: %s a %s)",
            len(todos_Tickets),
            total_api,
            data_inicio,
            data_fim,
        )

        Tickets_filtrados: List[Dict[str, Any]] = []
        datas_nao_reconhecidas = 0

        for ticket in todos_Tickets:
            data_str = ticket.get("DataCriacao", "")
            if not data_str:
                datas_nao_reconhecidas += 1
                continue

            data_obj = self._parse_date_flexible(str(data_str))
            if data_obj is None:
                datas_nao_reconhecidas += 1
                logger.debug("⚠️ Formato de data não reconhecido: '%s'", data_str)
                continue

            if data_inicio_obj <= data_obj <= data_fim_obj:
                Tickets_filtrados.append(ticket)

        if datas_nao_reconhecidas > 0:
            logger.warning(
                "⚠️ %s tickets com data não reconhecida foram ignorados",
                datas_nao_reconhecidas,
            )

        if total_api > len(todos_Tickets):
            logger.warning(
                "⚠️ ATENÇÃO: API retornou apenas %s de %s Tickets (limite da API)",
                len(todos_Tickets),
                total_api,
            )

        logger.info(
            "✅ Filtrados: %s de %s Tickets no período %s a %s",
            len(Tickets_filtrados),
            len(todos_Tickets),
            data_inicio,
            data_fim,
        )
        return Tickets_filtrados

    async def _buscar_Tickets_com_estatisticas(
        self,
        data_inicio: str,
        data_fim: str,
        usar_data_finalizacao: bool = False,
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """Retorna tickets e estatísticas sobre a consulta usando filtro server-side.

        Args:
            data_inicio: Data de início no formato dd/mm/yyyy
            data_fim: Data de fim no formato dd/mm/yyyy
            usar_data_finalizacao: Se True, busca tickets finalizados no período (não apenas criados)
        """
        try:
            data_inicio_obj = datetime.strptime(data_inicio, "%d/%m/%Y")
            data_fim_obj = datetime.strptime(data_fim, "%d/%m/%Y").replace(
                hour=23,
                minute=59,
                second=59,
            )
        except Exception as e:
            logger.error("❌ Erro ao parsear datas do período: %s", e)
            return [], {"erro": str(e)}

        # Se usar_data_finalizacao, buscar em período maior para pegar tickets finalizados no dia
        # mas que podem ter sido criados antes
        if usar_data_finalizacao:
            # Buscar tickets criados nos últimos 90 dias (para pegar tickets finalizados hoje)
            data_busca_inicio = (data_inicio_obj - timedelta(days=90)).strftime("%d/%m/%Y")
            filtro_data = {
                "Inicio": data_busca_inicio,
                "Fim": f"{data_fim} 23:59:59",
            }
        else:
            filtro_data = {
                "Inicio": data_inicio,
                "Fim": f"{data_fim} 23:59:59",
            }

        payload = {
            "Pesquisa": "",
            "Tatual": "",
            "Ativo": "Todos",
            "StatusSLA": "N",
            "Colunas": {
                "Chave": "on",
                "CodChamado": "on",
                "NomePrioridade": "on",
                "DataCriacao": "on",
                "HoraCriacao": "on",
                "NomeStatus": "on",
                "Assunto": "on",
                "NomeUsuario": "on",
                "SobrenomeUsuario": "on",
                "NomeOperador": "on",
                "SobrenomeOperador": "on",
            },
            "Ordem": [
                {
                    "Coluna": "DataCriacao",
                    "Direcao": "false",
                }
            ],
            "Filtro": {
                "DataCriacao": filtro_data,
            },
        }

        response = await self.api_request(
            "POST",
            "/ChamadosSuporte/lista",
            json=payload,
        )

        if not response or response.get("erro"):
            return [], {
                "erro": response.get("erro") if response else "Sem resposta",
            }

        todos_Tickets = response.get("root", [])
        total_api_raw = response.get("total", len(todos_Tickets))
        total_api = int(total_api_raw) if total_api_raw else len(todos_Tickets)

        Tickets_filtrados: List[Dict[str, Any]] = []
        datas_nao_reconhecidas = 0

        for ticket in todos_Tickets:
            if usar_data_finalizacao:
                # Filtrar apenas tickets finalizados/resolvidos no período
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "")
                else:
                    status_text = str(nome_status) if nome_status else ""

                status_lower = status_text.lower()
                # Verificar se está finalizado/resolvido
                is_finalizado = any(
                    x in status_lower
                    for x in ["resolvido", "finalizado", "encerrado", "concluído"]
                )

                if not is_finalizado:
                    continue  # Ignorar tickets não finalizados

                # Verificar data de criação (tickets finalizados no dia devem ter sido criados ou atualizados no período)
                data_str = ticket.get("DataCriacao", "")
                if not data_str:
                    datas_nao_reconhecidas += 1
                    continue

                data_obj = self._parse_date_flexible(str(data_str))
                if data_obj is None:
                    datas_nao_reconhecidas += 1
                    continue

                # Incluir apenas tickets criados no período (ou muito próximos, até 7 dias antes)
                # Como não temos data de finalização, vamos incluir apenas tickets criados no período
                # ou até 7 dias antes (para pegar tickets que podem ter sido criados antes mas finalizados no dia)
                data_limite_inicio = data_inicio_obj - timedelta(days=7)
                if data_limite_inicio <= data_obj <= data_fim_obj:
                    Tickets_filtrados.append(ticket)
            else:
                # Filtro normal: apenas tickets criados no período
                data_str = ticket.get("DataCriacao", "")
                if not data_str:
                    datas_nao_reconhecidas += 1
                    continue

                data_obj = self._parse_date_flexible(str(data_str))
                if data_obj is None:
                    datas_nao_reconhecidas += 1
                    continue

                if data_inicio_obj <= data_obj <= data_fim_obj:
                    Tickets_filtrados.append(ticket)

        estatisticas = {
            "total_api": total_api,
            "retornados": len(todos_Tickets),
            "filtrados": len(Tickets_filtrados),
            "datas_invalidas": datas_nao_reconhecidas,
            "limite_atingido": total_api > len(todos_Tickets),
            "data_inicio": data_inicio,
            "data_fim": data_fim,
        }

        return Tickets_filtrados, estatisticas

    # --------------------------------------------------------------------- #
    # Relatórios (comandos prefixados)
    # --------------------------------------------------------------------- #

    @commands.command(name="relatorio-operadores")
    async def relatorio_por_operador(
        self,
        ctx: commands.Context,
        *,
        periodo: Optional[str] = None,
    ) -> None:
        """Relatório: Quantos tickets cada operador atendeu."""
        async with ctx.typing():
            from zoneinfo import ZoneInfo

            data_hora = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime(
                "%d/%m/%Y às %H:%M"
            )

            data_inicio, data_fim, descricao_periodo = self._get_periodo_info(periodo)

            Tickets, stats = await self._buscar_Tickets_com_estatisticas(
                data_inicio,
                data_fim,
            )

            if stats.get("erro"):
                await ctx.send(f"❌ Erro ao buscar dados: {stats['erro']}")
                return

            if not Tickets:
                await ctx.send(
                    "📋 Nenhum ticket encontrado no período: "
                    f"**{descricao_periodo}** ({data_inicio} a {data_fim})"
                )
                return

            operadores: Dict[str, int] = {}  # Contar apenas RESOLVIDOS por operador
            for ticket in Tickets:
                # Verificar se o ticket está resolvido
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "Desconhecido")
                else:
                    status_text = str(nome_status) if nome_status else "Desconhecido"

                status_lower = status_text.lower()
                is_resolvido = any(
                    x in status_lower
                    for x in ["resolvido", "finalizado", "encerrado", "concluído"]
                )

                # Contar apenas se estiver resolvido
                if is_resolvido:
                    nome_operador = ticket.get("NomeOperador", "") or ""
                    sobrenome_operador = ticket.get("SobrenomeOperador", "") or ""
                    operador_completo = (
                        f"{nome_operador} {sobrenome_operador}".strip() or "Não atribuído"
                    )
                    # Normalizar nome do operador (corrigir acentos, etc)
                    if operador_completo != "Não atribuído":
                        operador_completo = self._normalize_operator_name(operador_completo)
                    operadores[operador_completo] = operadores.get(operador_completo, 0) + 1

            operadores_ordenado = sorted(
                operadores.items(),
                key=lambda x: x[1],
                reverse=True,
            )

            descricao = (
                f"📅 **Período:** {descricao_periodo}\n"
                f"📆 **De:** {data_inicio} **até:** {data_fim}\n"
                f"🕐 **Atualizado:** {data_hora}"
            )

            if stats["limite_atingido"]:
                descricao += (
                    "\n\n⚠️ **ATENÇÃO:** A API Desk.ms retornou "
                    f"{stats['retornados']} de {stats['total_api']} Tickets. "
                    "Os dados podem estar incompletos!"
                )

            embed = discord.Embed(
                title="📊 Relatório: Tickets por Operador - Resolvidos",
                description=descricao,
                color=discord.Color.orange()
                if stats["limite_atingido"]
                else discord.Color.gold(),
            )

            total_Tickets = len(Tickets)
            total_resolvidos_operadores = sum(operadores.values())
            media_por_operador = total_resolvidos_operadores / len(operadores) if operadores else 0

            embed.add_field(
                name="📋 Total de Tickets",
                value=str(total_Tickets),
                inline=True,
            )
            embed.add_field(
                name="👥 Operadores Ativos",
                value=str(len(operadores)),
                inline=True,
            )
            embed.add_field(
                name="📈 Média/Operador (Resolvidos)",
                value=f"{media_por_operador:.1f}",
                inline=True,
            )

            operadores_text = ""
            medalhas = ["🥇", "🥈", "🥉"]
            for i, (operador, count) in enumerate(operadores_ordenado[:15]):
                # Calcular percentual baseado nos resolvidos, não no total
                percentual = (count / total_resolvidos_operadores * 100) if total_resolvidos_operadores > 0 else 0
                medalha = medalhas[i] if i < 3 else "👤"
                operadores_text += (
                    f"{medalha} **{operador}**: {count} ({percentual:.1f}%)\n"
                )

            if operadores_text:
                embed.add_field(
                    name="🏆 Ranking",
                    value=operadores_text,
                    inline=False,
                )

            footer_text = f"Período: {data_inicio} a {data_fim}"
            if stats["datas_invalidas"] > 0:
                footer_text += (
                    f" | ⚠️ {stats['datas_invalidas']} registros ignorados "
                    "(data inválida)"
                )

            embed.set_footer(text=footer_text)
            await ctx.send(embed=embed)

    @commands.command(name="relatorio-resumo")
    async def relatorio_resumo(
        self,
        ctx: commands.Context,
        *,
        periodo: Optional[str] = None,
    ) -> None:
        """Relatório: Resumo geral de tickets por status."""
        async with ctx.typing():
            from zoneinfo import ZoneInfo

            data_hora = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime(
                "%d/%m/%Y às %H:%M"
            )

            data_inicio, data_fim, descricao_periodo = self._get_periodo_info(periodo)

            Tickets, stats = await self._buscar_Tickets_com_estatisticas(
                data_inicio,
                data_fim,
            )

            if stats.get("erro"):
                await ctx.send(f"❌ Erro ao buscar dados: {stats['erro']}")
                return

            if not Tickets:
                await ctx.send(
                    "📋 Nenhum ticket encontrado no período: "
                    f"**{descricao_periodo}** ({data_inicio} a {data_fim})"
                )
                return

            status_count: Dict[str, int] = {}
            prioridade_count: Dict[str, int] = {}
            resolvidos = 0
            em_aberto = 0

            for ticket in Tickets:
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "Desconhecido")
                else:
                    status_text = (
                        str(nome_status) if nome_status else "Desconhecido"
                    )

                prioridade = ticket.get("NomePrioridade", "Não definida")

                status_count[status_text] = status_count.get(status_text, 0) + 1
                prioridade_count[prioridade] = prioridade_count.get(prioridade, 0) + 1

                status_lower = status_text.lower()
                if any(
                    x in status_lower
                    for x in ["resolvido", "finalizado", "encerrado", "fechado"]
                ):
                    resolvidos += 1
                elif not any(x in status_lower for x in ["cancelado", "rejeitado"]):
                    em_aberto += 1

            descricao = (
                f"📅 **Período:** {descricao_periodo}\n"
                f"📆 **De:** {data_inicio} **até:** {data_fim}\n"
                f"🕐 **Atualizado:** {data_hora}"
            )

            if stats["limite_atingido"]:
                descricao += (
                    "\n\n⚠️ **ATENÇÃO:** A API Desk.ms retornou "
                    f"{stats['retornados']} de {stats['total_api']} Tickets. "
                    "Os dados podem estar incompletos!"
                )

            embed = discord.Embed(
                title="📈 Relatório: Resumo de Tickets",
                description=descricao,
                color=discord.Color.orange()
                if stats["limite_atingido"]
                else discord.Color.blue(),
            )

            total = len(Tickets)
            taxa_resolucao = (resolvidos / total * 100) if total > 0 else 0

            embed.add_field(name="📋 Total", value=str(total), inline=True)
            embed.add_field(name="✅ Resolvidos", value=str(resolvidos), inline=True)
            embed.add_field(name="🔧 Na Fila", value=str(em_aberto), inline=True)
            embed.add_field(
                name="📊 Taxa Resolução",
                value=f"{taxa_resolucao:.1f}%",
                inline=True,
            )

            status_text_embed = ""
            status_emojis = {
                "resolvido": "✅",
                "finalizado": "✅",
                "encerrado": "✅",
                "fechado": "✅",
                "novo": "🆕",
                "aberto": "🆕",
                "andamento": "🔧",
                "atendimento": "🔧",
                "aguardando": "⏳",
                "cancelado": "❌",
                "rejeitado": "❌",
            }

            for status, count in sorted(
                status_count.items(), key=lambda x: x[1], reverse=True
            )[:10]:
                emoji = "📌"
                for key, emj in status_emojis.items():
                    if key in status.lower():
                        emoji = emj
                        break
                percentual = (count / total) * 100 if total else 0
                status_text_embed += (
                    f"{emoji} **{status}**: {count} ({percentual:.1f}%)\n"
                )

            if status_text_embed:
                embed.add_field(
                    name="📊 Por Status",
                    value=status_text_embed,
                    inline=False,
                )

            prioridade_text = ""
            prioridade_emojis = {
                "alta": "🔴",
                "média": "🟡",
                "media": "🟡",
                "baixa": "🟢",
                "crítica": "🚨",
                "critica": "🚨",
            }

            for prioridade, count in sorted(
                prioridade_count.items(), key=lambda x: x[1], reverse=True
            ):
                emoji = "⚪"
                for key, emj in prioridade_emojis.items():
                    if key in prioridade.lower():
                        emoji = emj
                        break
                percentual = (count / total) * 100 if total else 0
                prioridade_text += (
                    f"{emoji} **{prioridade}**: {count} ({percentual:.1f}%)\n"
                )

            if prioridade_text:
                embed.add_field(
                    name="🎯 Por Prioridade",
                    value=prioridade_text,
                    inline=False,
                )

            footer_text = f"Período: {data_inicio} a {data_fim}"
            if stats["datas_invalidas"] > 0:
                footer_text += (
                    f" | ⚠️ {stats['datas_invalidas']} registros ignorados"
                )

            embed.set_footer(text=footer_text)
            await ctx.send(embed=embed)

    # --------------------------------------------------------------------- #
    # Slash commands helpers
    # --------------------------------------------------------------------- #

    async def periodo_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> List[app_commands.Choice[str]]:
        periodos = [
            ("Semestre atual", "semestre"),
            ("Trimestre atual", "trimestre"),
            ("Mes atual", "mes"),
            ("Ultimos 7 dias", "semana"),
            ("Hoje", "hoje"),
        ]

        if current:
            periodos = [
                (nome, valor)
                for nome, valor in periodos
                if current.lower() in nome.lower()
            ]

        return [app_commands.Choice(name=nome, value=valor) for nome, valor in periodos]

    # --------------------------------------------------------------------- #
    # Slash commands (interactions)
    # --------------------------------------------------------------------- #

    @app_commands.command(name="tickets", description="Listar Tickets do Desk.ms")
    @app_commands.describe(filtro="Filtrar por status (opcional)")
    async def slash_Tickets(
        self,
        interaction: discord.Interaction,
        filtro: Optional[str] = None,
    ) -> None:
        await interaction.response.defer()

        payload = {
            "Pesquisa": "",
            "Tatual": "",
            "Ativo": "Todos",
            "StatusSLA": "N",
            "Colunas": {
                "Chave": "on",
                "CodChamado": "on",
                "NomePrioridade": "on",
                "DataCriacao": "on",
                "HoraCriacao": "on",
                "NomeStatus": "on",
                "Assunto": "on",
                "NomeUsuario": "on",
                "SobrenomeUsuario": "on",
                "NomeOperador": "on",
                "SobrenomeOperador": "on",
            },
            "Ordem": [
                {
                    "Coluna": "DataCriacao",
                    "Direcao": "false",
                }
            ],
        }
        response = await self.api_request(
            "POST",
            "/ChamadosSuporte/lista",
            json=payload,
        )

        if not response or response.get("erro"):
            erro = response.get("erro") if response else "Nenhum ticket encontrado"
            await interaction.followup.send(f"❌ {erro}")
            return

        todos_Tickets = response.get("root", [])

        if not todos_Tickets:
            await interaction.followup.send("📋 Nenhum ticket encontrado.")
            return

        if filtro:
            filtro_lower = filtro.lower()
            Tickets_filtrados: List[Dict[str, Any]] = []
            for ticket in todos_Tickets:
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "").lower()
                else:
                    status_text = str(nome_status).lower() if nome_status else ""

                if filtro_lower in status_text:
                    Tickets_filtrados.append(ticket)

            if not Tickets_filtrados:
                await interaction.followup.send(
                    f"📋 Nenhum ticket com status `{filtro}`"
                )
                return

            Tickets_final = Tickets_filtrados[:25]
            titulo = f"🔍 Tickets com Status '{filtro}' ({len(Tickets_final)})"
        else:
            Tickets_abertos: List[Dict[str, Any]] = []
            for ticket in todos_Tickets:
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "").lower()
                else:
                    status_text = str(nome_status).lower() if nome_status else ""

                if not any(
                    x in status_text
                    for x in [
                        "resolvido",
                        "finalizado",
                        "encerrado",
                        "fechado",
                        "cancelado",
                        "rejeitado",
                    ]
                ):
                    Tickets_abertos.append(ticket)

            if not Tickets_abertos:
                await interaction.followup.send("✅ Nenhum ticket em aberto! Parabens!")
                return

            Tickets_final = Tickets_abertos[:25]
            titulo = f"🆕 Tickets em Aberto ({len(Tickets_final)})"

        embed = discord.Embed(title=titulo, color=discord.Color.blue())

        for ticket in Tickets_final[:15]:
            id_ticket = str(ticket.get("CodChamado", "N/A"))
            assunto = (ticket.get("Assunto", "Sem assunto") or "")[:50]
            nome_status = ticket.get("NomeStatus", [])
            status = (
                nome_status[0].get("text", "---")
                if isinstance(nome_status, list) and nome_status
                else "---"
            )
            prioridade = ticket.get("NomePrioridade", "---")

            embed.add_field(
                name=f"#{id_ticket} - {assunto}",
                value=f"**Status:** {status} | **Prioridade:** {prioridade}",
                inline=False,
            )

        if len(Tickets_final) > 15:
            embed.set_footer(
                text=(
                    f"Mostrando 15 de {len(Tickets_final)} Tickets | "
                    "Use /ticket [ID] para detalhes"
                )
            )
        else:
            embed.set_footer(text="Use /ticket [ID] para mais detalhes")

        await interaction.followup.send(embed=embed)

    @app_commands.command(name="ticket", description="Ver detalhes de um ticket")
    @app_commands.describe(id="ID do ticket")
    async def slash_ticket(
        self,
        interaction: discord.Interaction,
        id: str,
    ) -> None:
        # Validar input do ID
        if not id or len(id.strip()) == 0:
            await interaction.response.send_message("❌ ID do ticket não pode estar vazio.", ephemeral=True)
            return

        if len(id) > 50:
            await interaction.response.send_message("❌ ID do ticket muito longo (máx 50 caracteres).", ephemeral=True)
            return

        await interaction.response.defer()

        payload = {
            "Pesquisa": id,
            "Ordem": [
                {
                    "Coluna": "DataCriacao",
                    "Direcao": "false",
                }
            ],
        }
        try:
            response = await self.api_request(
                "POST",
                "/ChamadosSuporte/lista",
                json=payload,
            )

            if not response:
                await interaction.followup.send(
                    "❌ **Erro ao conectar com a API Desk.ms**\n"
                    "Por favor, tente novamente em alguns instantes. "
                    "Se o problema persistir, verifique a conexão com a internet."
                )
                return

            Tickets = response.get("root", [])

            if not Tickets:
                await interaction.followup.send(
                    f"📋 **Nenhum ticket encontrado**\n"
                    f"Não foi possível encontrar um ticket com o ID `{id}`.\n"
                    f"Verifique se o ID está correto e tente novamente."
                )
                return

            data: Optional[Dict[str, Any]] = None
            ticket_id_clean = id.replace("-", "").lower().strip()

            for ticket in Tickets:
                cod = str(ticket.get("CodChamado", "")).lower().replace("-", "")
                if ticket_id_clean in cod or cod in ticket_id_clean:
                    data = ticket
                    break

            if not data:
                await interaction.followup.send(
                    f"📋 **Ticket não encontrado**\n"
                    f"O ticket `{id}` não foi encontrado no sistema.\n"
                    f"Verifique se o ID está correto ou se o ticket ainda existe."
                )
                return
        except Exception as e:
            logger.error(f"Erro ao buscar ticket {id}: {e}", exc_info=True)
            await interaction.followup.send(
                "❌ **Erro inesperado ao buscar ticket**\n"
                "Ocorreu um erro ao processar sua solicitação. "
                "Por favor, tente novamente mais tarde."
            )
            return

        assunto = data.get("Assunto", "Sem assunto")
        nome_status = data.get("NomeStatus", "")
        if isinstance(nome_status, list) and nome_status:
            status = nome_status[0].get("text", "Desconhecido")
        else:
            status = str(nome_status) if nome_status else "Desconhecido"

        nome_usuario = data.get("NomeUsuario", "") or ""
        sobrenome_usuario = data.get("SobrenomeUsuario", "") or ""
        cliente = (f"{nome_usuario} {sobrenome_usuario}".strip()) or "Não informado"

        prioridade = data.get("NomePrioridade", "---")

        nome_operador = data.get("NomeOperador", "") or ""
        sobrenome_operador = data.get("SobrenomeOperador", "") or ""
        analista = (
            f"{nome_operador} {sobrenome_operador}".strip() or "Não atribuído"
        )

        data_criacao = data.get("DataCriacao", "---")

        status_lower = status.lower()
        if any(x in status_lower for x in ["resolvido", "finalizado", "encerrado"]):
            emoji, cor = "✅", discord.Color.green()
        elif any(x in status_lower for x in ["cancelado", "rejeitado"]):
            emoji, cor = "❌", discord.Color.red()
        elif any(x in status_lower for x in ["andamento", "atendimento"]):
            emoji, cor = "🔧", discord.Color.orange()
        else:
            emoji, cor = "🆕", discord.Color.blue()

        embed = discord.Embed(
            title=f"Ticket #{id}",
            description=f"{emoji} **{assunto}**",
            color=cor,
        )
        embed.add_field(name="📌 Status", value=status, inline=True)
        embed.add_field(name="🎯 Prioridade", value=prioridade, inline=True)
        embed.add_field(name="👤 Cliente", value=cliente, inline=False)
        embed.add_field(name="👨‍💻 Analista", value=analista, inline=True)
        embed.add_field(name="📅 Criado em", value=data_criacao, inline=True)

        await interaction.followup.send(embed=embed)

    @app_commands.command(name="relatorio", description="Gerar relatório de Tickets")
    @app_commands.describe(
        tipo="Tipo de relatório",
        periodo="Período do relatório",
    )
    @app_commands.choices(
        tipo=[
            app_commands.Choice(name="Resumo por Status", value="resumo"),
            app_commands.Choice(name="Por Operador", value="operadores"),
        ]
    )
    @app_commands.autocomplete(periodo=periodo_autocomplete)
    async def slash_relatorio(
        self,
        interaction: discord.Interaction,
        tipo: str = "resumo",
        periodo: str = "semestre",
    ) -> None:
        await interaction.response.defer()

        from zoneinfo import ZoneInfo

        data_hora = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime(
            "%d/%m/%Y as %H:%M"
        )

        data_inicio, data_fim, descricao_periodo = self._get_periodo_info(periodo)

        Tickets, stats = await self._buscar_Tickets_com_estatisticas(
            data_inicio,
            data_fim,
        )

        if stats.get("erro"):
            await interaction.followup.send(
                f"❌ Erro ao buscar dados: {stats['erro']}"
            )
            return

        if not Tickets:
            await interaction.followup.send(
                f"📋 Nenhum ticket encontrado no período: **{descricao_periodo}**"
            )
            return

        if tipo == "operadores":
            operadores: Dict[str, int] = {}  # Contar apenas RESOLVIDOS por operador
            for ticket in Tickets:
                # Verificar se o ticket está resolvido
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "Desconhecido")
                else:
                    status_text = str(nome_status) if nome_status else "Desconhecido"

                status_lower = status_text.lower()
                is_resolvido = any(
                    x in status_lower
                    for x in ["resolvido", "finalizado", "encerrado", "concluído"]
                )

                # Contar apenas se estiver resolvido
                if is_resolvido:
                    nome_operador = ticket.get("NomeOperador", "") or ""
                    sobrenome_operador = ticket.get("SobrenomeOperador", "") or ""
                    operador_completo = (
                        f"{nome_operador} {sobrenome_operador}".strip()
                        or "Nao atribuido"
                    )
                    # Normalizar nome do operador (corrigir acentos, etc)
                    if operador_completo != "Nao atribuido":
                        operador_completo = self._normalize_operator_name(operador_completo)
                    operadores[operador_completo] = operadores.get(operador_completo, 0) + 1

            operadores_ordenado = sorted(
                operadores.items(),
                key=lambda x: x[1],
                reverse=True,
            )

            descricao = (
                f"📅 **Período:** {descricao_periodo}\n"
                f"📆 **De:** {data_inicio} **até:** {data_fim}\n"
                f"🕐 **Atualizado:** {data_hora}"
            )

            if stats["limite_atingido"]:
                descricao += (
                    "\n\n⚠️ **ATENÇÃO:** API retornou "
                    f"{stats['retornados']} de {stats['total_api']} Tickets"
                )

            embed = discord.Embed(
                title="📊 Relatório: Tickets por Operador - Resolvidos",
                description=descricao,
                color=discord.Color.orange()
                if stats["limite_atingido"]
                else discord.Color.gold(),
            )

            total_Tickets = len(Tickets)
            total_resolvidos_operadores = sum(operadores.values())
            media = total_resolvidos_operadores / len(operadores) if operadores else 0

            embed.add_field(name="📋 Total", value=str(total_Tickets), inline=True)
            embed.add_field(
                name="👥 Operadores",
                value=str(len(operadores)),
                inline=True,
            )
            embed.add_field(name="📈 Media (Resolvidos)", value=f"{media:.1f}", inline=True)

            operadores_text = ""
            medalhas = ["🥇", "🥈", "🥉"]
            for i, (operador, count) in enumerate(operadores_ordenado[:15]):
                # Calcular percentual baseado nos resolvidos, não no total
                percentual = (count / total_resolvidos_operadores * 100) if total_resolvidos_operadores > 0 else 0
                medalha = medalhas[i] if i < 3 else "👤"
                operadores_text += (
                    f"{medalha} **{operador}**: {count} ({percentual:.1f}%)\n"
                )

            if operadores_text:
                embed.add_field(
                    name="🏆 Ranking",
                    value=operadores_text,
                    inline=False,
                )
        else:
            status_count: Dict[str, int] = {}
            resolvidos = 0
            em_aberto = 0

            for ticket in Tickets:
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "Desconhecido")
                else:
                    status_text = (
                        str(nome_status) if nome_status else "Desconhecido"
                    )

                status_count[status_text] = status_count.get(status_text, 0) + 1

                status_lower = status_text.lower()
                if any(
                    x in status_lower
                    for x in ["resolvido", "finalizado", "encerrado", "fechado"]
                ):
                    resolvidos += 1
                elif not any(x in status_lower for x in ["cancelado", "rejeitado"]):
                    em_aberto += 1

            descricao = (
                f"📅 **Período:** {descricao_periodo}\n"
                f"📆 **De:** {data_inicio} **até:** {data_fim}\n"
                f"🕐 **Atualizado:** {data_hora}"
            )

            if stats["limite_atingido"]:
                descricao += (
                    "\n\n⚠️ **ATENÇÃO:** API retornou "
                    f"{stats['retornados']} de {stats['total_api']} Tickets"
                )

            embed = discord.Embed(
                title="📈 Relatório: Resumo de Tickets",
                description=descricao,
                color=discord.Color.orange()
                if stats["limite_atingido"]
                else discord.Color.blue(),
            )

            total = len(Tickets)
            taxa = (resolvidos / total * 100) if total > 0 else 0

            embed.add_field(name="📋 Total", value=str(total), inline=True)
            embed.add_field(name="✅ Resolvidos", value=str(resolvidos), inline=True)
            embed.add_field(name="🔧 Na Fila", value=str(em_aberto), inline=True)
            embed.add_field(
                name="📊 Taxa Resolucao",
                value=f"{taxa:.1f}%",
                inline=True,
            )

            status_text_embed = ""
            for status, count in sorted(
                status_count.items(), key=lambda x: x[1], reverse=True
            )[:10]:
                percentual = (count / total) * 100 if total else 0
                status_text_embed += (
                    f"📌 **{status}**: {count} ({percentual:.1f}%)\n"
                )

            if status_text_embed:
                embed.add_field(
                    name="📊 Por Status",
                    value=status_text_embed,
                    inline=False,
                )

        await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="desk-ajuda",
        description="Ver ajuda sobre os comandos do Desk Manager",
    )
    async def slash_desk_ajuda(
        self,
        interaction: discord.Interaction,
    ) -> None:
        """Comando de ajuda específico para comandos do Desk Manager."""
        embed = discord.Embed(
            title="📚 Comandos do Desk Manager",
            description="Comandos para gerenciar tickets e relatórios do Desk.ms",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="🎫 Comandos Slash (/)",
            value=(
                "`/tickets [filtro]` - Listar tickets abertos (ou filtrar por status)\n"
                "`/ticket [id]` - Ver detalhes de um ticket específico\n"
                "`/relatorio [tipo] [periodo]` - Gerar relatórios (resumo ou por operador)\n"
                "`/desk-status` - Verificar status da conexão com Desk.ms\n"
                "`/desk-ajuda` - Ver esta lista de comandos"
            ),
            inline=False
        )

        embed.add_field(
            name="🔧 Comandos Prefix (!)",
            value=(
                "`!tickets [status]` - Listar tickets (igual ao slash)\n"
                "`!ticket [id]` - Ver detalhes de um ticket\n"
                "`!desk-status` - Verificar status da conexão\n"
                "`!Tickets-fechados` - Listar últimos tickets fechados\n"
                "`!abrir-ticket [assunto]` - Abrir um novo ticket\n"
                "`!relatorio-operadores [periodo]` - Relatório por operador\n"
                "`!relatorio-resumo [periodo]` - Relatório resumo geral\n"
                "`!kb-artigo [chave]` - Ver artigo da base de conhecimento"
            ),
            inline=False
        )

        embed.add_field(
            name="📊 Períodos para Relatórios",
            value=(
                "`semestre` - Semestre atual\n"
                "`trimestre` - Trimestre atual\n"
                "`mes` - Mês atual\n"
                "`semana` - Últimos 7 dias\n"
                "`hoje` - Dia atual"
            ),
            inline=False
        )

        embed.add_field(
            name="💡 Dicas",
            value=(
                "• Use `/tickets` sem filtro para ver todos os tickets em aberto\n"
                "• Use `/ticket` com o ID do ticket (ex: `1225-000437`)\n"
                "• Os relatórios podem ser gerados para diferentes períodos\n"
                "• O comando `/desk-status` verifica se a API está funcionando"
            ),
            inline=False
        )

        embed.set_footer(text="Desk Manager - NextCompany Bot")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(
        name="desk-help",
        description="Ver ajuda sobre os comandos do Desk Manager (alias de /desk-ajuda)",
    )
    async def slash_desk_help(
        self,
        interaction: discord.Interaction,
    ) -> None:
        """Alias para /desk-ajuda"""
        await self.slash_desk_ajuda(interaction)  # type: ignore[misc]

    @app_commands.command(
        name="desk-status",
        description="Verificar status da conexao com Desk.ms",
    )
    async def slash_desk_status(
        self,
        interaction: discord.Interaction,
    ) -> None:
        await interaction.response.defer()

        embed = discord.Embed(
            title="🔍 Status da Conexao Desk.ms",
            color=discord.Color.blue(),
        )

        has_keys = bool(self.operator_key and self.environment_key)
        embed.add_field(
            name="🔑 Chaves Configuradas",
            value="✅ Sim" if has_keys else "❌ Nao",
            inline=True,
        )

        if has_keys:
            token = await self.get_auth_token()
            if token:
                embed.add_field(
                    name="🔐 Autenticacao",
                    value="✅ OK",
                    inline=True,
                )
                embed.add_field(
                    name="⏰ Token Expira",
                    value=(
                        self.token_expires.strftime("%H:%M:%S")
                        if self.token_expires
                        else "N/A"
                    ),
                    inline=True,
                )
                embed.color = discord.Color.green()
            else:
                embed.add_field(
                    name="🔐 Autenticacao",
                    value="❌ Falhou",
                    inline=True,
                )
                embed.color = discord.Color.red()

        embed.add_field(name="🌐 API URL", value=self.base_url, inline=False)
        await interaction.followup.send(embed=embed)

    async def enviar_relatorio_diario(
        self,
        channel: discord.TextChannel,
        data_relatorio: Optional[str] = None,
    ) -> None:
        """Envia relatório diário completo com estatísticas detalhadas."""
        try:
            from zoneinfo import ZoneInfo

            # Se não foi especificada uma data, calcular baseado no dia da semana
            hoje = datetime.now(ZoneInfo("America/Sao_Paulo"))
            weekday = hoje.weekday()  # 0=segunda, 5=sábado, 6=domingo
            is_semana_passada = False  # Flag para indicar se está buscando semana passada inteira

            if not data_relatorio:
                # Se for segunda-feira (0), buscar semana passada inteira (segunda a sábado)
                if weekday == 0:
                    # Segunda-feira anterior (9 dias atrás)
                    segunda_anterior = hoje - timedelta(days=9)
                    # Sábado anterior (3 dias atrás)
                    sabado_anterior = hoje - timedelta(days=3)
                    data_inicio = segunda_anterior.strftime("%d/%m/%Y")
                    data_fim = sabado_anterior.strftime("%d/%m/%Y")
                    is_semana_passada = True
                # Se for domingo (6), usar sábado (1 dia atrás)
                elif weekday == 6:
                    data_inicio = (hoje - timedelta(days=1)).strftime("%d/%m/%Y")
                    data_fim = data_inicio
                # Caso contrário, usar hoje
                else:
                    data_inicio = hoje.strftime("%d/%m/%Y")
                    data_fim = data_inicio
            else:
                # Garantir formato correto
                try:
                    datetime.strptime(data_relatorio, "%d/%m/%Y")
                    # Se foi especificada uma data e for segunda-feira, verificar se deve buscar semana passada
                    if weekday == 0:
                        # Verificar se a data especificada é de uma segunda-feira anterior
                        data_parseada = datetime.strptime(data_relatorio, "%d/%m/%Y")
                        if data_parseada.weekday() == 0:  # Se a data especificada é uma segunda
                            # Buscar da segunda até o sábado daquela semana
                            data_inicio = data_relatorio
                            sabado_da_semana = data_parseada + timedelta(days=5)
                            data_fim = sabado_da_semana.strftime("%d/%m/%Y")
                            is_semana_passada = True
                        else:
                            data_inicio = data_relatorio
                            data_fim = data_relatorio
                    else:
                        data_inicio = data_relatorio
                        data_fim = data_relatorio
                except ValueError:
                    logger.error(f"Formato de data inválido: {data_relatorio}")
                    return

            data_hora = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime(
                "%d/%m/%Y às %H:%M"
            )

            # Buscar tickets finalizados no período (para corresponder ao dashboard do Desk.ms)
            # O dashboard conta tickets finalizados/resolvidos no período, não apenas criados
            Tickets, stats = await self._buscar_Tickets_com_estatisticas(
                data_inicio,
                data_fim,
                usar_data_finalizacao=True,  # Contar tickets finalizados no período
            )

            if stats.get("erro"):
                await channel.send(
                    f"❌ Erro ao gerar relatório diário: {stats['erro']}"
                )
                return

            # Processar estatísticas
            total = len(Tickets)
            status_count: Dict[str, int] = {}
            resolvidos = 0
            cancelados = 0
            em_aberto = 0
            em_atendimento = 0
            operadores: Dict[str, int] = {}  # Contar apenas RESOLVIDOS por operador
            causas: Dict[str, int] = {}  # Contar causas dos chamados

            for ticket in Tickets:
                # Status
                nome_status = ticket.get("NomeStatus", [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get("text", "Desconhecido")
                else:
                    status_text = str(nome_status) if nome_status else "Desconhecido"

                status_count[status_text] = status_count.get(status_text, 0) + 1
                status_lower = status_text.lower()

                is_resolvido = any(
                    x in status_lower
                    for x in ["resolvido", "finalizado", "encerrado", "concluído"]
                )
                is_cancelado = any(x in status_lower for x in ["cancelado", "rejeitado"])
                is_em_atendimento = any(
                    x in status_lower
                    for x in ["andamento", "progresso", "atendimento", "em análise"]
                )

                if is_resolvido:
                    resolvidos += 1
                elif is_cancelado:
                    cancelados += 1
                elif is_em_atendimento:
                    em_atendimento += 1
                else:
                    em_aberto += 1

                # Operadores - CONTAR APENAS OS RESOLVIDOS
                if is_resolvido:
                    nome_operador = ticket.get("NomeOperador", "") or ""
                    sobrenome_operador = ticket.get("SobrenomeOperador", "") or ""

                    # Aplicar fix_text primeiro para corrigir encoding
                    nome_operador = fix_text(str(nome_operador)) if nome_operador else ""
                    sobrenome_operador = fix_text(str(sobrenome_operador)) if sobrenome_operador else ""

                    operador_completo = (
                        f"{nome_operador} {sobrenome_operador}".strip() or "Não atribuído"
                    )
                    # Normalizar nome do operador (corrigir acentos, etc)
                    if operador_completo != "Não atribuído":
                        operador_completo = self._normalize_operator_name(operador_completo)
                    operadores[operador_completo] = (
                        operadores.get(operador_completo, 0) + 1
                    )

                # Causas dos chamados
                causa = (
                    ticket.get("Causa")
                    or ticket.get("causa")
                    or ticket.get("CausaNome")
                    or ticket.get("causa_nome")
                    or ticket.get("NomeCausa")
                    or ticket.get("nome_causa")
                )
                # Tentar também campos extras
                if not causa:
                    campos_extras = ticket.get("CamposExtras") or ticket.get("campos_extras") or ticket.get("ExtraFields")
                    if isinstance(campos_extras, list):
                        for campo in campos_extras:
                            if isinstance(campo, dict):
                                nome_campo = campo.get("nome") or campo.get("Nome") or campo.get("name")
                                if nome_campo and "Causa" in str(nome_campo):
                                    causa = campo.get("valor") or campo.get("Valor") or campo.get("value")
                                    break
                    elif isinstance(campos_extras, dict):
                        causa = campos_extras.get("Causa") or campos_extras.get("causa")

                if causa:
                    causa_text = fix_text(str(causa)).strip()
                    if causa_text and causa_text != "None" and len(causa_text) > 0:
                        causas[causa_text] = causas.get(causa_text, 0) + 1

            # Calcular taxa de resolução
            taxa_resolucao = (resolvidos / total * 100) if total > 0 else 0

            # Criar embed
            # Determinar se é relatório do dia anterior ou da semana passada
            hoje_str = hoje.strftime("%d/%m/%Y")

            # Garantir que as datas estão no formato correto
            try:
                data_inicio_parseada = datetime.strptime(data_inicio, "%d/%m/%Y")
                data_fim_parseada = datetime.strptime(data_fim, "%d/%m/%Y")
                data_inicio_formatada = data_inicio_parseada.strftime("%d/%m/%Y")
                data_fim_formatada = data_fim_parseada.strftime("%d/%m/%Y")
            except (ValueError, TypeError):
                logger.error(f"Erro ao formatar datas do relatório: {data_inicio} - {data_fim}")
                data_inicio_formatada = data_inicio
                data_fim_formatada = data_fim

            # Montar texto da data
            if is_semana_passada:
                # Se for semana passada inteira, mostrar período
                data_info = f"📅 **Data dos Tickets:** {data_inicio_formatada} a {data_fim_formatada} (última semana)"
            elif data_inicio_formatada == data_fim_formatada:
                # Se for apenas um dia
                data_info = f"📅 **Data dos Tickets:** {data_inicio_formatada}"
                if data_inicio_formatada != hoje_str:
                    data_info += " (dia anterior)"
            else:
                # Se for um período diferente
                data_info = f"📅 **Data dos Tickets:** {data_inicio_formatada} a {data_fim_formatada}"

            data_info += f"\n🕐 **Relatório gerado em:** {data_hora}"
            if is_semana_passada:
                data_info += "\n📊 **Critério:** Tickets finalizados/resolvidos na última semana (segunda a sábado)"
            else:
                data_info += "\n📊 **Critério:** Tickets finalizados/resolvidos no dia (igual ao dashboard Desk.ms)"

            descricao = data_info

            # Título do relatório
            if is_semana_passada:
                titulo = f"📊 Relatório Diário - {data_inicio_formatada} a {data_fim_formatada}"
            elif data_inicio_formatada == data_fim_formatada:
                titulo = f"📊 Relatório Diário - {data_inicio_formatada}"
            else:
                titulo = f"📊 Relatório Diário - {data_inicio_formatada} a {data_fim_formatada}"

            embed = discord.Embed(
                title=titulo,
                description=descricao,
                color=discord.Color.blue(),
            )

            # Estatísticas principais
            embed.add_field(name="📋 Total de Chamados", value=str(total), inline=True)
            embed.add_field(
                name="✅ Resolvidos", value=str(resolvidos), inline=True
            )
            embed.add_field(
                name="❌ Cancelados", value=str(cancelados), inline=True
            )
            embed.add_field(
                name="🔧 Em Atendimento",
                value=str(em_atendimento),
                inline=True,
            )
            embed.add_field(
                name="⏳ Na Fila", value=str(em_aberto), inline=True
            )
            embed.add_field(
                name="📈 Taxa de Resolução",
                value=f"{taxa_resolucao:.1f}%",
                inline=True,
            )

            # Status detalhados
            if status_count:
                status_text = ""
                for status, count in sorted(
                    status_count.items(), key=lambda x: x[1], reverse=True
                )[:8]:
                    percentual = (count / total * 100) if total > 0 else 0
                    status_text += f"📌 **{status}**: {count} ({percentual:.1f}%)\n"
                if status_text:
                    embed.add_field(
                        name="📊 Por Status", value=status_text, inline=False
                    )

            # Operadores (top 10) - APENAS RESOLVIDOS
            if operadores:
                operadores_ordenado = sorted(
                    operadores.items(), key=lambda x: x[1], reverse=True
                )[:10]
                operadores_text = ""
                medalhas = ["🥇", "🥈", "🥉"]
                total_resolvidos_operadores = sum(operadores.values())
                for i, (operador, count) in enumerate(operadores_ordenado):
                    # Calcular percentual baseado nos resolvidos, não no total
                    percentual = (count / total_resolvidos_operadores * 100) if total_resolvidos_operadores > 0 else 0
                    medalha = medalhas[i] if i < 3 else "👤"
                    operadores_text += (
                        f"{medalha} **{operador}**: {count} ({percentual:.1f}%)\n"
                    )
                if operadores_text:
                    embed.add_field(
                        name="👥 Por Operador - Resolvidos (Top 10)",
                        value=operadores_text,
                        inline=False,
                    )

            # Maiores Causas de Chamados
            if causas:
                causas_ordenado = sorted(
                    causas.items(), key=lambda x: x[1], reverse=True
                )[:10]
                causas_text = ""
                for causa_nome, count in causas_ordenado:
                    percentual = (count / total * 100) if total > 0 else 0
                    # Limitar tamanho do nome da causa para não quebrar o embed
                    causa_display = causa_nome[:50] + "..." if len(causa_nome) > 50 else causa_nome
                    causas_text += (
                        f"🔍 **{causa_display}**: {count} ({percentual:.1f}%)\n"
                    )
                if causas_text:
                    embed.add_field(
                        name="🎯 Maiores Causas de Chamados",
                        value=causas_text,
                        inline=False,
                    )

            embed.set_footer(text="Desk.ms - Relatório Automático Diário")
            await channel.send(embed=embed)

        except Exception as e:
            logger.error(
                f"Erro ao enviar relatório diário: {e}", exc_info=True
            )
            try:
                await channel.send(
                    f"❌ Erro ao gerar relatório diário: {str(e)}"
                )
            except (discord.HTTPException, discord.Forbidden, Exception):
                pass


async def setup(bot: commands.Bot) -> None:
    cog = DeskCog(bot)
    await bot.add_cog(cog)
    logger.info("Cog Desk carregado com sucesso")
