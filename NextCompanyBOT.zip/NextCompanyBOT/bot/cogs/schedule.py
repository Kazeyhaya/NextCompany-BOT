# Standard library
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, TYPE_CHECKING
from zoneinfo import ZoneInfo

if TYPE_CHECKING:
    from .desk import DeskCog

# Third-party
import discord
from discord.ext import commands

# Local
from ..config import Config
from ..utils.cooldown import CooldownManager
from ..utils.database import JsonDatabase
from ..utils.helpers import format_time_delta, parse_time_input, fix_text

logger = logging.getLogger(__name__)

# Constants
TZ_BR = ZoneInfo("America/Sao_Paulo")
REMINDER_CHECK_INTERVAL = 10  # seconds
COOLDOWN_CLEANUP_INTERVAL = 3600  # 1 hour in seconds
MAX_REMINDER_HOURS = 24
MAX_REMINDER_MINUTES = MAX_REMINDER_HOURS * 60
MIN_REMINDER_MINUTES = 1
MAX_REMINDER_MESSAGE_LENGTH = 200
MAX_HOLIDAY_NAME_LENGTH = 100
MIN_HOLIDAY_NAME_LENGTH = 2
EMBED_FIELD_MAX_LENGTH = 1000  # Tamanho máximo de campo em embed do Discord


class ScheduleCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.holidays: dict[str, str] = {}
        self.config: dict[str, str] = {}
        self.lembretes: list[dict] = []
        self.cooldown_manager = CooldownManager()
        self.load_data()

    def load_data(self) -> None:
        """Carregar dados iniciais do bot."""
        self.holidays = JsonDatabase.load(Config.FILES['feriados'], Config.DEFAULT_HOLIDAYS)
        self.config = JsonDatabase.load(Config.FILES['config'], Config.DEFAULT_CONFIG)
        # Carregar lembretes salvos
        self.load_lembretes()

    def load_lembretes(self) -> None:
        """Carregar lembretes salvos do arquivo JSON."""
        try:
            lembretes_data = JsonDatabase.load('lembretes.json', [])
            if not isinstance(lembretes_data, list):
                lembretes_data = []

            # Converter strings de data de volta para datetime
            for lembrete in lembretes_data:
                if isinstance(lembrete.get('quando'), str):
                    try:
                        # Parse ISO format and make timezone-aware
                        dt = datetime.fromisoformat(lembrete['quando'])
                        if dt.tzinfo is None:
                            dt = dt.replace(tzinfo=TZ_BR)
                        lembrete['quando'] = dt
                    except (ValueError, TypeError):
                        continue  # Ignorar lembretes com data inválida

            # Filtrar lembretes que já passaram (usando timezone-aware)
            now = datetime.now(TZ_BR)
            self.lembretes = [
                lembrete_item for lembrete_item in lembretes_data 
                if isinstance(lembrete_item.get('quando'), datetime) and lembrete_item['quando'] > now
            ]
            logger.info(f"Carregados {len(self.lembretes)} lembretes pendentes")
        except Exception as e:
            logger.error(f"Erro ao carregar lembretes: {e}", exc_info=True)
            self.lembretes = []

    def save_lembretes(self):
        """Salvar lembretes no arquivo JSON."""
        try:
            # Converter datetime para string ISO para JSON
            lembretes_serialized = []
            for lembrete in self.lembretes:
                lembrete_copy = lembrete.copy()
                if isinstance(lembrete_copy.get('quando'), datetime):
                    lembrete_copy['quando'] = lembrete_copy['quando'].isoformat()
                lembretes_serialized.append(lembrete_copy)

            JsonDatabase.save('lembretes.json', lembretes_serialized)
        except Exception as e:
            logger.error(f"Erro ao salvar lembretes: {e}", exc_info=True)

    def get_time_br(self) -> datetime:
        """Retorna o horário atual do Brasil com timezone."""
        return datetime.now(TZ_BR).replace(second=0, microsecond=0)

    def build_embed(self, title: str, description: str, color: discord.Color) -> discord.Embed:
        """Cria um embed padronizado."""
        embed = discord.Embed(title=title, description=description, color=color)
        embed.set_footer(text="NextCompany System")
        return embed

    def check_cooldown(self, user_id: int, command: str, seconds: int) -> bool:
        """Verificar cooldown do usuário"""
        return self.cooldown_manager.check_cooldown(user_id, command, seconds)

    def get_cooldown_remaining(self, user_id: int, command: str, seconds: int) -> int:
        """Obter tempo restante do cooldown"""
        return self.cooldown_manager.get_cooldown_remaining(user_id, command, seconds)

    async def start_background_tasks(self):
        self.bot.loop.create_task(self.schedule_check())
        self.bot.loop.create_task(self.check_reminders())

    async def schedule_check(self):
        """Verifica eventos agendados de forma otimizada."""
        await self.bot.wait_until_ready()

        # Horários relevantes para verificar (em minutos desde meia-noite)
        relevant_times = {
            8 * 60,      # 08:00
            8 * 60 + 10, # 08:10
            11 * 60 + 40, # 11:40 (sábado - relatório)
            12 * 60,     # 12:00
            14 * 60,     # 14:00
            17 * 60 + 30, # 17:30
            18 * 60,     # 18:00
        }

        last_checked_minute = -1

        while not self.bot.is_closed():
            try:
                now = self.get_time_br()
                current_minute = now.hour * 60 + now.minute

                # Verificar apenas se mudou de minuto E se é um horário relevante
                if current_minute != last_checked_minute and current_minute in relevant_times:
                    await self.check_time_events(now)
                    last_checked_minute = current_minute

            except (ValueError, TypeError, AttributeError) as e:
                logger.error(f"Erro de tipo no schedule_check: {e}", exc_info=True)
            except Exception as e:
                logger.error(f"Erro inesperado no schedule_check: {e}", exc_info=True)

            # Dormir até o próximo minuto
            current_second = datetime.now(TZ_BR).second
            sleep_time = max(1, 60 - current_second)
            await asyncio.sleep(sleep_time)

    async def check_reminders(self) -> None:
        """Verifica e envia lembretes pendentes."""
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                now = datetime.now(TZ_BR)
                lembretes_removidos: list[dict] = []

                # Processar lembretes que devem ser enviados
                for lembrete in self.lembretes[:]:
                    if now >= lembrete['quando']:
                        channel = self.bot.get_channel(lembrete['channel_id'])
                        # Verificar se o canal é um tipo que suporta send()
                        if channel and isinstance(channel, (discord.TextChannel, discord.DMChannel, discord.Thread)):
                            try:
                                mensagem_corrigida = fix_text(lembrete['mensagem'])  # Corrigir encoding
                                embed = discord.Embed(
                                    title="⏰ Lembrete!",
                                    description=mensagem_corrigida,
                                    color=discord.Color.orange()
                                )
                                await channel.send(f"<@{lembrete['user_id']}>", embed=embed)
                            except Exception as e:
                                logger.error(f"Erro ao enviar lembrete: {e}", exc_info=True)
                        lembretes_removidos.append(lembrete)

                # Remover lembretes enviados de forma eficiente (list comprehension)
                if lembretes_removidos:
                    self.lembretes = [
                        lembrete_item for lembrete_item in self.lembretes 
                        if lembrete_item not in lembretes_removidos
                    ]
                    self.save_lembretes()

            except (discord.HTTPException, discord.Forbidden, discord.NotFound) as e:
                logger.error(f"Erro do Discord ao enviar lembrete: {e}", exc_info=True)
            except Exception as e:
                logger.error(f"Erro inesperado no check_reminders: {e}", exc_info=True)
            await asyncio.sleep(REMINDER_CHECK_INTERVAL)

    async def check_time_events(self, now: datetime) -> None:
        """Verifica eventos agendados e envia relatórios se necessário."""
        try:
            weekday = now.weekday()  # 0=segunda, 5=sábado, 6=domingo
            current_minute = now.hour * 60 + now.minute

            # Sábado às 11:40 - enviar relatório do sábado
            if weekday == 5 and current_minute == 11 * 60 + 40:
                desk_cog: Optional['DeskCog'] = self.bot.get_cog('DeskCog')  # type: ignore
                if desk_cog:
                    channel = self.bot.get_channel(Config.RELATORIO_CHANNEL_ID)
                    if isinstance(channel, discord.TextChannel):
                        # Usar None para que a função calcule automaticamente (será sábado)
                        await desk_cog.enviar_relatorio_diario(channel, None)
                        logger.info("📊 Relatório diário enviado (sábado às 11:40)")

            # Segunda-feira às 08:10 - enviar relatório da última semana
            if weekday == 0 and current_minute == 8 * 60 + 10:
                desk_cog: Optional['DeskCog'] = self.bot.get_cog('DeskCog')  # type: ignore
                if desk_cog:
                    channel = self.bot.get_channel(Config.RELATORIO_CHANNEL_ID)
                    if isinstance(channel, discord.TextChannel):
                        # Passar None para que a função calcule automaticamente a última semana
                        await desk_cog.enviar_relatorio_diario(channel, None)
                        logger.info("📊 Relatório diário enviado (segunda às 08:10 - dados da última semana)")
        except (AttributeError, TypeError) as e:
            logger.error(f"Erro de tipo ao verificar eventos agendados: {e}", exc_info=True)
        except Exception as e:
            logger.error(f"Erro inesperado ao verificar eventos agendados: {e}", exc_info=True)

    @commands.command(name='tempo')
    async def check_time(self, ctx: commands.Context) -> None:
        now = self.get_time_br()
        weekday = now.weekday()
        saida_str = self.config.get("saida_hoje", "18:00")
        h_saida, m_saida = map(int, saida_str.split(':'))
        targets = {
            "e": now.replace(hour=8, minute=0),
            "a": now.replace(hour=12, minute=0),
            "v": now.replace(hour=14, minute=0),
            "s": now.replace(hour=h_saida, minute=m_saida)
        }

        msg, cor, emoji = "🌙 Expediente encerrado. Bom descanso!", discord.Color.dark_grey(), ""

        if weekday < 5:
            if now < targets['e']:
                msg, cor, emoji = f"⏰ Começamos em **{format_time_delta(targets['e'] - now)}**", discord.Color.orange(), "🌅"
            elif now < targets['a']:
                msg, cor, emoji = f"🍽️ Almoço em **{format_time_delta(targets['a'] - now)}**", discord.Color.blue(), "🍴"
            elif now < targets['v']:
                msg, cor, emoji = f"💼 Retorno em **{format_time_delta(targets['v'] - now)}**", discord.Color.gold(), "✨"
            elif now < targets['s']:
                prefix = "🚨 **PLANTÃO**: " if saida_str != "18:00" else ""
                cor_saida = discord.Color.magenta() if saida_str != "18:00" else discord.Color.purple()
                msg, cor, emoji = f"{prefix}Saída em **{format_time_delta(targets['s'] - now)}**", cor_saida, "🏃"
        elif weekday == 5:
            targets_sab = {"e": now.replace(hour=8, minute=0), "s": now.replace(hour=12, minute=0)}
            if now < targets_sab['e']:
                msg, cor, emoji = f"📅 Sábado! Começamos em **{format_time_delta(targets_sab['e'] - now)}**", discord.Color.orange(), "⏰"
            elif now < targets_sab['s']:
                msg, cor, emoji = f"🎉 Fim de semana em **{format_time_delta(targets_sab['s'] - now)}**", discord.Color.green(), "🎊"

        embed = discord.Embed(title=f"{emoji} Cronômetro do Expediente", description=msg, color=cor)
        embed.set_footer(text="NextCompany System")
        await ctx.send(embed=embed)

    @commands.command(name='horaextra')
    async def set_hora_extra(self, ctx: commands.Context, horario: Optional[str] = None) -> None:
        if not horario:
            await ctx.send("Use: `!horaextra HH:MM` (ex: !horaextra 20:00)")
            return

        # Validar formato e valores
        try:
            horario_str = str(horario) if horario else ""
            if len(horario_str) != 5 or horario_str[2] != ':':
                raise ValueError("Formato inválido")

            hora, minuto = map(int, horario_str.split(':'))
            if not (0 <= hora <= 23 and 0 <= minuto <= 59):
                raise ValueError("Hora ou minuto inválido")

            horario_str = str(horario) if horario else "18:00"
            self.config["saida_hoje"] = horario_str
            JsonDatabase.save(Config.FILES["config"], self.config)
            await ctx.send(f"✅ Combinado! Saída ajustada para **{horario_str}**.")
        except (ValueError, AttributeError) as e:
            logger.warning(f"Tentativa de definir hora extra inválida: {horario} - {e}")
            await ctx.send("❌ Formato inválido. Use HH:MM (ex: 20:00)")

    @commands.command(name='normal')
    async def set_hora_normal(self, ctx: commands.Context) -> None:
        self.config["saida_hoje"] = "18:00"
        JsonDatabase.save(Config.FILES["config"], self.config)
        await ctx.send("✅ Feito! Horário resetado para **18:00**.")

    @commands.command(name='feriados')
    async def list_feriados(self, ctx: commands.Context) -> None:
        if not self.holidays:
            await ctx.send("Nenhum feriado cadastrado.")
            return

        sorted_holidays = sorted(self.holidays.items(), key=lambda x: (int(x[0].split('/')[1]), int(x[0].split('/')[0])))

        embed = discord.Embed(title="Feriados Cadastrados", color=discord.Color.green())

        chunks = []
        current_chunk = ""
        for data, nome in sorted_holidays:
            nome_str = str(nome) if nome else "Sem nome"
            nome_str = fix_text(nome_str)  # Corrigir encoding
            line = f"**{data}** - {nome_str}\n"
            if len(current_chunk) + len(line) > EMBED_FIELD_MAX_LENGTH:
                chunks.append(current_chunk)
                current_chunk = line
            else:
                current_chunk += line
        if current_chunk:
            chunks.append(current_chunk)

        for i, chunk in enumerate(chunks):
            field_name = "Lista" if i == 0 else f"Lista (cont. {i+1})"
            embed.add_field(name=field_name, value=chunk, inline=False)

        embed.set_footer(text=f"Total: {len(self.holidays)} feriados")
        await ctx.send(embed=embed)

    @commands.command(name='addferiado')
    async def add_feriado(self, ctx: commands.Context, data: Optional[str] = None, *, nome: Optional[str] = None) -> None:
        if not self.check_cooldown(ctx.author.id, 'addferiado', 3):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'addferiado', 3)
            await ctx.send(f"⏳ Espere {remaining}s antes de adicionar outro feriado.")
            return

        if not data or not nome:
            await ctx.send("Use: `!addferiado DD/MM Nome do Feriado`\nEx: `!addferiado 20/11 Consciência Negra`")
            return

        # Validar formato e valores da data
        try:
            data_str = str(data) if data else ""
            nome_str = str(nome) if nome else ""

            if len(data_str) < 4 or '/' not in data_str:
                raise ValueError("Formato inválido")

            partes = data_str.split('/')
            if len(partes) != 2:
                raise ValueError("Formato deve ser DD/MM")

            dia, mes = int(partes[0]), int(partes[1])

            # Validar limites de dia e mês
            if not (1 <= mes <= 12):
                raise ValueError("Mês deve estar entre 1 e 12")

            # Validar dia baseado no mês
            dias_por_mes = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
            if not (1 <= dia <= dias_por_mes[mes - 1]):
                raise ValueError(f"Dia inválido para o mês {mes}")

            # Validar nome do feriado
            if len(nome_str.strip()) < MIN_HOLIDAY_NAME_LENGTH:
                raise ValueError(f"Nome do feriado muito curto (mín {MIN_HOLIDAY_NAME_LENGTH} caracteres)")
            if len(nome_str) > MAX_HOLIDAY_NAME_LENGTH:
                raise ValueError(f"Nome do feriado muito longo (máx {MAX_HOLIDAY_NAME_LENGTH} caracteres)")

            data_formatada = f"{dia:02d}/{mes:02d}"

            # Verificar se já existe
            if data_formatada in self.holidays:
                await ctx.send(f"⚠️ Feriado **{data_formatada}** já existe: {self.holidays[data_formatada]}")
                return

        except ValueError as e:
            logger.warning(f"Tentativa de adicionar feriado inválido: {data} - {e}")
            await ctx.send(f"❌ Data inválida: {str(e)}. Use o formato DD/MM")
            return
        except Exception as e:
            logger.error(f"Erro ao adicionar feriado: {e}", exc_info=True)
            await ctx.send("❌ Erro ao processar data. Use o formato DD/MM")
            return

        nome_str = str(nome) if nome else "Sem nome"
        nome_str = fix_text(nome_str.strip())  # Corrigir encoding
        self.holidays[data_formatada] = nome_str
        JsonDatabase.save(Config.FILES["feriados"], self.holidays)
        await ctx.send(f"✅ Feriado adicionado: **{data_formatada}** - {nome_str}")

    @commands.command(name='rmferiado')
    async def remove_feriado(self, ctx: commands.Context, data: Optional[str] = None) -> None:
        if not self.check_cooldown(ctx.author.id, 'rmferiado', 3):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'rmferiado', 3)
            await ctx.send(f"⏳ Espere {remaining}s antes de remover outro feriado.")
            return

        if not data:
            await ctx.send("Use: `!rmferiado DD/MM`\nEx: `!rmferiado 20/11`")
            return

        # Validar formato da data
        try:
            data_str = str(data) if data else ""

            if len(data_str) < 4 or '/' not in data_str:
                raise ValueError("Formato inválido")

            partes = data_str.split('/')
            if len(partes) != 2:
                raise ValueError("Formato deve ser DD/MM")

            dia, mes = int(partes[0]), int(partes[1])

            # Validar mês
            if not (1 <= mes <= 12):
                raise ValueError("Mês deve estar entre 1 e 12")

            # Validar dia baseado no mês
            dias_por_mes = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
            if not (1 <= dia <= dias_por_mes[mes - 1]):
                raise ValueError(f"Dia inválido para o mês {mes}")

            data_formatada = f"{dia:02d}/{mes:02d}"
        except (ValueError, AttributeError) as e:
            logger.warning(f"Tentativa de remover feriado com data inválida: {data} - {e}")
            await ctx.send("❌ Data inválida. Use o formato DD/MM")
            return

        if data_formatada in self.holidays:
            nome = self.holidays.pop(data_formatada)
            JsonDatabase.save(Config.FILES["feriados"], self.holidays)
            await ctx.send(f"✅ Feriado removido: **{data_formatada}** - {nome}")
        else:
            await ctx.send(f"❌ Feriado não encontrado: {data_formatada}")

    @commands.command(name='lembrete')
    async def set_reminder(self, ctx: commands.Context, tempo: Optional[str] = None, *, mensagem: Optional[str] = None) -> None:
        if not tempo or not mensagem:
            await ctx.send("Use: `!lembrete [tempo] [mensagem]`\nExemplos:\n- `!lembrete 30m Reuniao`\n- `!lembrete 2h Almocar`\n- `!lembrete 1h30m Ligar cliente`")
            return

        try:
            total_minutes = parse_time_input(tempo)

            if total_minutes <= 0:
                raise ValueError("Tempo deve ser positivo")
            if total_minutes > MAX_REMINDER_MINUTES:
                await ctx.send(f"Limite de {MAX_REMINDER_HOURS} horas para lembretes.")
                return
            if total_minutes < MIN_REMINDER_MINUTES:
                await ctx.send(f"Tempo minimo de {MIN_REMINDER_MINUTES} minuto para lembretes.")
                return

            if not mensagem or len(mensagem) > MAX_REMINDER_MESSAGE_LENGTH:
                await ctx.send(f"Mensagem muito longa (max {MAX_REMINDER_MESSAGE_LENGTH} caracteres).")
                return

            # Usar timezone do Brasil para consistência
            quando = datetime.now(TZ_BR) + timedelta(minutes=total_minutes)

            mensagem_str = str(mensagem) if mensagem else ""
            mensagem_str = fix_text(mensagem_str)  # Corrigir encoding
            lembrete = {
                'user_id': ctx.author.id,
                'channel_id': ctx.channel.id,
                'mensagem': mensagem_str,
                'quando': quando
            }
            self.lembretes.append(lembrete)

            # Salvar lembretes após adicionar
            self.save_lembretes()

            hora_lembrete = quando.strftime("%H:%M")
            mensagem_display = mensagem_str if mensagem_str else "Sem mensagem"
            await ctx.send(f"✅ Lembrete configurado para **{hora_lembrete}** ({total_minutes} minutos)\nMensagem: *{mensagem_display}*")

        except ValueError as e:
            await ctx.send(f"Tempo invalido: {str(e)}")
        except (ValueError, TypeError) as e:
            logger.warning(f"Erro de validação ao criar lembrete: {e}")
            await ctx.send("Formato inválido. Use: 30m, 2h, 1h30m")
        except Exception as e:
            logger.error(f"Erro inesperado ao criar lembrete: {e}", exc_info=True)
            await ctx.send("❌ Erro ao processar lembrete. Tente novamente.")


async def setup(bot):
    cog = ScheduleCog(bot)
    await bot.add_cog(cog)
    await cog.start_background_tasks()

    # Tarefa periódica para limpar cooldowns antigos (a cada hora)
    async def cleanup_cooldowns():
        await bot.wait_until_ready()
        while not bot.is_closed():
            try:
                await asyncio.sleep(COOLDOWN_CLEANUP_INTERVAL)
                removed = cog.cooldown_manager.cleanup_old_cooldowns(max_age_seconds=COOLDOWN_CLEANUP_INTERVAL)
                if removed > 0:
                    logger.debug(f"Limpeza de cooldowns: {removed} entradas antigas removidas")
            except (ValueError, TypeError, AttributeError) as e:
                logger.error(f"Erro de tipo na limpeza de cooldowns: {e}", exc_info=True)
            except Exception as e:
                logger.error(f"Erro inesperado na limpeza de cooldowns: {e}", exc_info=True)

    bot.loop.create_task(cleanup_cooldowns())
