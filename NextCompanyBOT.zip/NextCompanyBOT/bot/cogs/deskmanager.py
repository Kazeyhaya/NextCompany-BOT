# Standard library
import asyncio
import json
import logging
import re
import time
import urllib.parse
from typing import Optional, Dict, Tuple, Any

# Third-party
import aiohttp
import discord
from aiohttp import web
from discord.ext import commands

# Local
from ..config import Config
from ..utils.helpers import fix_text, get_protocolo

logger = logging.getLogger(__name__)

# =============================================================================
# CONSTANTES: Palavras-chave para preposições em português (gender-aware)
# =============================================================================
PREPOSICAO_MASCULINO_PALAVRAS = {
    'sistema', 'banco', 'arquivo', 'pasta', 'diretório', 'diretorio',
    'servidor', 'cliente', 'computador', 'máquina', 'maquina', 'equipamento',
    'dispositivo', 'aparelho', 'terminal', 'estação', 'estacao', 'posto',
    'local', 'lugar', 'ambiente', 'contexto', 'momento', 'instante',
    'caso', 'situação', 'situacao', 'ocasião', 'ocasiao', 'vez',
    'dia', 'mês', 'mes', 'ano', 'semana', 'período', 'periodo',
    'início', 'inicio', 'fim', 'final', 'começo', 'comeco',
    'registro', 'cadastro', 'campo', 'tabela', 'aplicativo', 'programa',
    'software', 'windows', 'linux', 'rede', 'internet', 'conexão', 'conexao',
    'documento', 'caminho', 'menu', 'tela', 'interface', 'janela', 'painel',
    'dashboard', 'relatório', 'relatorio', 'ticket', 'chamado', 'usuário',
    'usuario', 'operador', 'atendente', 'analista', 'empresa', 'organização',
    'organizacao', 'instituição', 'instituicao', 'departamento', 'setor',
    'área', 'area', 'seção', 'secao', 'grupo', 'equipe', 'time', 'pessoa',
    'pessoas', 'indivíduo', 'individuo', 'hardware', 'versão', 'versao',
    'edição', 'edicao', 'configuração', 'configuracao', 'opção', 'opcao',
    'alternativa', 'método', 'metodo', 'forma', 'maneira', 'jeito', 'modo',
    'processo', 'procedimento', 'função', 'funcao', 'ação', 'acao',
    'atividade', 'tarefa', 'trabalho', 'projeto', 'iniciativa', 'reunião',
    'reuniao', 'encontro', 'evento', 'ocorrência', 'ocorrencia', 'problema',
    'erro', 'falha', 'solução', 'solucao', 'resposta', 'resultado', 'efeito',
    'consequência', 'consequencia', 'impacto', 'influência', 'influencia',
    'schema', 'xml', 'json', 'formato', 'estrutura', 'modelo',
    'binário', 'binario', 'código', 'codigo', 'arquivo', 'dados', 'registro',
}

PREPOSICAO_FEMININA_PALAVRAS = {
    'tabela', 'máquina', 'maquina', 'tela', 'janela', 'interface',
    'aplicação', 'aplicacao', 'versão', 'versao', 'edição', 'edicao',
    'configuração', 'configuracao', 'opção', 'opcao', 'função', 'funcao',
    'ação', 'acao', 'atividade', 'tarefa', 'reunião', 'reuniao',
    'ocorrência', 'ocorrencia', 'solução', 'solucao', 'resposta',
    'situação', 'situacao', 'ocasião', 'ocasiao', 'semana', 'área', 'area',
    'seção', 'secao', 'empresa', 'organização', 'organizacao',
    'instituição', 'instituicao', 'influência', 'influencia',
    'estrutura', 'base', 'linha', 'coluna', 'caixa', 'guia', 'aba',
    'mensagem', 'página', 'pagina', 'parte', 'lista', 'árvore', 'arvore',
    'barra', 'grade', 'célula', 'celula', 'nfe.ini', 'nfe', 'planilha',
    'imagem', 'foto', 'figura', 'telemetria', 'documentação', 'documentacao',
    'descrição', 'descricao', 'nota', 'observação', 'observacao',
    'advertência', 'advertencia', 'entrada', 'saída', 'saida',
    'instalação', 'instalacao', 'desinstalação', 'desinstalacao',
    'inicialização', 'inicializacao', 'finalização', 'finalizacao',
    'autenticação', 'autenticacao', 'autorização', 'autorizacao',
    'validação', 'validacao', 'verificação', 'verificacao',
    'sincronização', 'sincronizacao', 'replicação', 'replicacao',
    'indexação', 'indexacao', 'otimização', 'otimizacao', 'rotina', 'rotinas',
    'query', 'consulta', 'busca', 'pesquisa', 'exportação', 'exportacao',
    'importação', 'importacao', 'integração', 'integracao', 'conexão', 'conexao',
    'sessão', 'sessao', 'camada', 'hierarquia', 'chave', 'cifra',
    'criptografia', 'assinatura', 'certificação', 'certificacao',
}

# Constants
CACHE_TTL_SECONDS = 3600  # 1 hora em segundos
CACHE_CLEANUP_INTERVAL = 300  # Limpar cache a cada 5 minutos
CACHE_MAX_SIZE = 1000  # Tamanho máximo do cache de webhooks
CACHE_REDUCE_TO = 500  # Reduzir para 50% quando atingir o máximo
LOG_PAYLOAD_MAX_LENGTH = 1000  # Tamanho máximo de payload para log
LOG_CAMPOS_EXTRAS_MAX_LENGTH = 500  # Tamanho máximo de campos extras para log


class DeskManagerCog(commands.Cog):
    """Cog para gerenciar webhooks do Desk.ms"""

    OPERATOR_FALLBACK = {
        "42": "José Arimáteia",
        "48": "João Victor",
        "49": "Ícaro Matheus",
    }

    def __init__(self, bot: commands.Bot) -> None:
        self.bot: commands.Bot = bot
        self.web_server: Optional[web.Application] = None
        # Cache para evitar processar o mesmo webhook múltiplas vezes
        # Formato: {(chamado_cod, interacao_cod, timestamp): timestamp_insercao}
        # Usa limpeza baseada em tempo (TTL) e tamanho máximo
        self.processed_webhooks: Dict[Tuple[str, str, str], float] = {}
        self.max_cache_size = CACHE_MAX_SIZE
        self.cache_ttl = CACHE_TTL_SECONDS
        self._last_cache_cleanup = time.time()
        self._cache_cleanup_interval = CACHE_CLEANUP_INTERVAL

    async def resolve_operator_name(self, operator_id: str) -> Optional[str]:
        """Resolve ID operador para nome via DeskCog ou fallback fixo"""
        op_id = str(operator_id).strip()

        # Normalizar ID: remover zeros à esquerda (ex: "000042" -> "42")
        # mas manter o original para API
        op_id_normalized = op_id.lstrip('0') if op_id.isdigit() else op_id
        if not op_id_normalized:  # Se era só zeros, manter "0"
            op_id_normalized = "0"

        # Tentar primeiro com ID normalizado (sem zeros à esquerda)
        if op_id_normalized in self.OPERATOR_FALLBACK:
            logger.info(
                f"✅ Operador resolvido via fallback: {op_id} → {self.OPERATOR_FALLBACK[op_id_normalized]}"
            )
            return self.OPERATOR_FALLBACK[op_id_normalized]

        # Tentar também com ID original (caso tenha zeros à esquerda no fallback)
        if op_id in self.OPERATOR_FALLBACK:
            logger.info(
                f"✅ Operador resolvido via fallback (ID original): {op_id} → {self.OPERATOR_FALLBACK[op_id]}"
            )
            return self.OPERATOR_FALLBACK[op_id]

        name = None
        try:
            desk_cog = self.bot.get_cog('DeskCog')
            if desk_cog and hasattr(desk_cog, 'resolve_operator_name'):
                # CORREÇÃO: Adicionar timeout de 5 segundos para evitar travamento
                # Usar getattr para acessar o método dinamicamente
                resolve_method = getattr(desk_cog, 'resolve_operator_name', None)
                if resolve_method:
                    name = await asyncio.wait_for(
                        resolve_method(operator_id),  # type: ignore
                        timeout=5.0,
                    )
                if name:
                    return name
        except asyncio.TimeoutError:
            logger.warning(f"⏱️ Timeout ao resolver operador {operator_id} (5s)")
        except Exception as e:
            logger.debug(f"⚠️ Erro ao resolver operador: {e}")
        return None

    def _corrigir_estao_para_estacao(self, texto: str) -> str:
        """Corrige 'Estão' para 'Estação' ou 'estações' apenas quando faz sentido no contexto.

        Não corrige quando 'estão' é o verbo estar (ex: 'eles estão aqui').
        Corrige apenas em contextos como 'de Estão', 'Estão de', 'Configuração de Estão', etc.
        Corrige "demais estão" -> "demais estações" (plural).
        Preserva minúscula no meio da frase (após preposições) e maiúscula no início de frase.
        """
        if not texto:
            return texto

        # CORREÇÃO PRIORITÁRIA: "demais estão" -> "demais estações" (plural)
        texto = re.sub(r'\bdemais\s+est[ãa]o\b', 'demais estações', texto, flags=re.IGNORECASE)
        texto = re.sub(r'\bdemais\s+Est[ãa]o\b', 'demais estações', texto, flags=re.IGNORECASE)
        texto = re.sub(r'\bdemais\s+EST[ÃA]O\b', 'demais estações', texto, flags=re.IGNORECASE)

        # CORREÇÃO: "outras estão" -> "outras estações" (plural)
        texto = re.sub(r'\boutras\s+est[ãa]o\b', 'outras estações', texto, flags=re.IGNORECASE)
        texto = re.sub(r'\boutras\s+Est[ãa]o\b', 'outras estações', texto, flags=re.IGNORECASE)

        # CORREÇÃO: "todas estão" -> "todas estações" (plural)
        texto = re.sub(r'\btodas\s+est[ãa]o\b', 'todas estações', texto, flags=re.IGNORECASE)
        texto = re.sub(r'\btodas\s+Est[ãa]o\b', 'todas estações', texto, flags=re.IGNORECASE)

        # CORREÇÃO: "as estão" -> "as estações" (plural)
        texto = re.sub(r'\bas\s+est[ãa]o\b', 'as estações', texto, flags=re.IGNORECASE)
        texto = re.sub(r'\bas\s+Est[ãa]o\b', 'as estações', texto, flags=re.IGNORECASE)

        # CORREÇÃO: "os estão" -> "os estações" (plural) - menos comum, mas possível
        texto = re.sub(r'\bos\s+est[ãa]o\b', 'os estações', texto, flags=re.IGNORECASE)
        texto = re.sub(r'\bos\s+Est[ãa]o\b', 'os estações', texto, flags=re.IGNORECASE)

        # REGRA PRINCIPAL: Após preposições (de, da, do, na, no, em), SEMPRE usar minúscula
        # "na Estação", "da Estação", "de Estação" -> "na estação", "da estação", "de estação"
        texto = re.sub(r'\b(de|da|do|na|no|em)\s+Est[ãa]o\b', 
                      r'\1 estação', 
                      texto, flags=re.IGNORECASE)

        # "Configuração de Estão" -> "Configuração de estação" (minúscula após "de")
        texto = re.sub(r'\b([Cc]onfigura[çc][ãa]o|[Cc]onfig)\s+de\s+Est[ãa]o\b', 
                      r'\1 de estação', 
                      texto, flags=re.IGNORECASE)

        # Para outros casos, verificar se está no início da frase
        # Função auxiliar para determinar capitalização
        def verificar_inicio_frase(posicao):
            """Verifica se a posição está no início de uma frase"""
            if posicao == 0:
                return True
            antes = texto[:posicao]
            # Verifica se há ponto, exclamação ou interrogação antes (fim de frase anterior)
            return bool(re.search(r'[.!?]\s*$', antes))

        # "Estão" seguido de parênteses ou hífen (ex: "Estão (Icompany)")
        def corrigir_estao_parenteses(match):
            pos = match.start()
            if verificar_inicio_frase(pos):
                return f"Estação{match.group(1)}"
            else:
                return f"estação{match.group(1)}"

        texto = re.sub(r'\bEst[ãa]o\s*([\(-])', corrigir_estao_parenteses, texto, flags=re.IGNORECASE)

        # "Estão" no final da frase
        def corrigir_estao_final(match):
            pos = match.start()
            pontuacao = match.group(1) if match.groups() else ''
            if verificar_inicio_frase(pos):
                return f"Estação{pontuacao}"
            else:
                return f"estação{pontuacao}"

        texto = re.sub(r'\bEst[ãa]o\s*([.,;:!?]|$)', corrigir_estao_final, texto, flags=re.IGNORECASE)

        # "Estão" seguido de substantivo (palavra com inicial maiúscula)
        def corrigir_estao_substantivo(match):
            pos = match.start()
            substantivo = match.group(1)
            if verificar_inicio_frase(pos):
                return f"Estação {substantivo}"
            else:
                return f"estação {substantivo}"

        texto = re.sub(r'\bEst[ãa]o\s+([A-Z][a-z]{2,})', corrigir_estao_substantivo, texto)

        # CORREÇÃO FINAL: Se "Estação" (já corrigida) aparecer após preposição, converter para minúscula
        # Isso garante que mesmo se o texto já vier com "Estação" maiúscula, será corrigido
        texto = re.sub(r'\b(de|da|do|na|no|em)\s+Estação\b', 
                      r'\1 estação', 
                      texto, flags=re.IGNORECASE)

        # Também corrigir "Configuração de Estação" -> "Configuração de estação"
        texto = re.sub(r'\b([Cc]onfigura[çc][ãa]o|[Cc]onfig)\s+de\s+Estação\b', 
                      r'\1 de estação', 
                      texto, flags=re.IGNORECASE)

        return texto

    def _buscar_detalhamento_recursivo(
        self, 
        obj: Any, 
        profundidade_max: int = 3, 
        profundidade_atual: int = 0
    ) -> Optional[str]:
        """Busca recursiva por campos que contenham 'detalhamento' em estruturas aninhadas"""
        if profundidade_atual >= profundidade_max:
            return None

        if isinstance(obj, dict):
            for key, value in obj.items():
                if isinstance(key, str):
                    key_lower = key.lower()
                    # Se a chave contém "detalhamento" e o valor é uma string significativa
                    if 'detalhamento' in key_lower and isinstance(value, str):
                        if len(value.strip()) > 10 and value.strip() != 'None':
                            return value
                    # Se a chave contém "detalhamento" e "causa", priorizar
                    if 'detalhamento' in key_lower and 'causa' in key_lower and isinstance(value, str):
                        if len(value.strip()) > 10 and value.strip() != 'None':
                            return value

                # Buscar recursivamente em valores que são dict ou list
                if isinstance(value, (dict, list)):
                    resultado = self._buscar_detalhamento_recursivo(value, profundidade_max, profundidade_atual + 1)
                    if resultado:
                        return resultado
        elif isinstance(obj, list):
            for item in obj:
                if isinstance(item, (dict, list)):
                    resultado = self._buscar_detalhamento_recursivo(item, profundidade_max, profundidade_atual + 1)
                    if resultado:
                        return resultado

        return None

    def _normalize_operator_name(self, name: str) -> str:
        """Normaliza nomes de operadores conhecidos (corrige acentos, etc)"""
        if not name:
            return name

        # Primeiro aplicar fix_text para corrigir encoding
        name = fix_text(name)
        original_name = name

        # CORREÇÃO PRIORITÁRIA 1: "Joséé" -> "José" (duplicação do "é")
        # Deve vir ANTES de outras correções para garantir que seja corrigido
        if 'Joséé' in name or 'JOSÉÉ' in name or 'joséé' in name:
            name = name.replace('Joséé', 'José').replace('JOSÉÉ', 'JOSÉ').replace('joséé', 'josé')
            name = re.sub(r'Joséé', 'José', name, flags=re.IGNORECASE)

        # CORREÇÃO PRIORITÁRIA 2: "caro" no início (sem o "I") -> "Ícaro"
        # Caso: "caro Matheus" -> "Ícaro Matheus"
        # IMPORTANTE: Esta correção deve vir PRIMEIRO para pegar casos onde o "I" foi cortado
        name_lower = name.lower().strip()
        if name_lower.startswith('caro'):
            # Se começa com "caro" (com ou sem espaço depois)
            if len(name) >= 4:
                # Verificar se tem espaço depois de "caro"
                if len(name) > 4 and name[4] == ' ':
                    # Tem espaço: "caro Matheus" -> "Ícaro Matheus"
                    name = 'Ícaro' + name[4:]
                elif len(name) > 4 and name[4].isupper():
                    # Sem espaço mas próxima letra é maiúscula: "caroMatheus" -> "ÍcaroMatheus"
                    name = 'Ícaro' + name[4:]
                elif len(name) > 4:
                    # Sem espaço e próxima letra é minúscula: adicionar espaço
                    name = 'Ícaro ' + name[4:]
                else:
                    # Apenas "caro" -> "Ícaro"
                    name = 'Ícaro'

        # CORREÇÃO 1: "Joo" -> "João" (em qualquer posição)
        # Caso: "Joo Victor" -> "João Victor"
        if 'Joo' in name or 'JOO' in name or 'joo' in name:
            # Substituir "Joo" seguido de espaço ou fim da string
            name = re.sub(r'\bJoo\b', 'João', name, flags=re.IGNORECASE)
            # Se começar com "Joo" (sem espaço antes), corrigir também
            if re.match(r'^Joo', name, re.IGNORECASE):
                name = re.sub(r'^Joo', 'João', name, flags=re.IGNORECASE)

        # CORREÇÃO 1.5: "Joséé" -> "José" (duplicação do "é")
        if 'Joséé' in name or 'JOSÉÉ' in name or 'joséé' in name:
            name = name.replace('Joséé', 'José').replace('JOSÉÉ', 'JOSÉ').replace('joséé', 'josé')
            name = re.sub(r'Joséé', 'José', name, flags=re.IGNORECASE)

        # CORREÇÃO 2: "Icaro" -> "Ícaro" (em qualquer posição)
        if 'Icaro' in name or 'ICARO' in name or 'icaro' in name:
            name = re.sub(r'\bIcaro\b', 'Ícaro', name, flags=re.IGNORECASE)

        # Se não houve mudança, tentar uma última vez com padrões mais específicos
        if name == original_name:
            # Tentar padrões mais específicos
            if 'Joo' in name:
                name = name.replace('Joo ', 'João ').replace('JOO ', 'JOÃO ')
                if name.startswith('Joo'):
                    name = 'João' + name[3:]

        # VERIFICAÇÃO FINAL OBRIGATÓRIA: correções finais (sempre verificar, mesmo se já foi processado)
        # "Joo" -> "João" (verificação final obrigatória - caso tenha passado despercebido)
        if 'Joo' in name or 'JOO' in name or 'joo' in name:
            name = re.sub(r'\bJoo\b', 'João', name, flags=re.IGNORECASE)
            name = name.replace('Joo ', 'João ').replace('JOO ', 'JOÃO ').replace('joo ', 'joão ')
            if name.startswith('Joo') or name.startswith('JOO') or name.startswith('joo'):
                name = re.sub(r'^Joo', 'João', name, flags=re.IGNORECASE)
        # "Joséé" -> "José" (corrigir duplicação de acento - único lugar)
        if 'Joséé' in name or 'JOSÉÉ' in name or 'joséé' in name:
            name = re.sub(r'Joséé', 'José', name, flags=re.IGNORECASE)
            name = re.sub(r'JOSÉÉ', 'JOSÉ', name, flags=re.IGNORECASE)
            name = re.sub(r'joséé', 'josé', name, flags=re.IGNORECASE)

        # "caro" -> "Ícaro"
        name_lower = name.lower().strip()
        if name_lower.startswith('caro') and 'ícaro' not in name_lower and 'icaro' not in name_lower:
            if len(name) >= 4:
                if len(name) > 4 and name[4] == ' ':
                    name = 'Ícaro' + name[4:]  # "caro Matheus" -> "Ícaro Matheus"
                elif len(name) > 4 and name[4].isupper():
                    name = 'Ícaro' + name[4:]  # "caroMatheus" -> "ÍcaroMatheus"
                elif len(name) > 4:
                    name = 'Ícaro ' + name[4:]  # Adicionar espaço se próxima letra é minúscula
                else:
                    name = 'Ícaro'  # Apenas "caro" -> "Ícaro"

        # "José Arimáteia" - correção consolidada em uma única busca (removeu duplicação)
        if 'Jos' in name and 'Arim' in name:
            name = re.sub(r'\bJos\b', 'José', name, flags=re.IGNORECASE)
            name = re.sub(r'\bArimteia\b', 'Arimáteia', name, flags=re.IGNORECASE)
            name = re.sub(r'\bArimatia\b', 'Arimáteia', name, flags=re.IGNORECASE)

        return name

    def _corrigir_nao(self, texto: str) -> str:
        """
        Corrige 'n', 'no' ou 'nõ' para 'não' usando análise de contexto.
        Evita corrigir o 'no' quando é preposição (ex: 'no sistema', 'no banco').
        Também corrige "Não" -> "No"/"Na" quando for preposição (caso reverso).
        Usa constantes globais PREPOSICAO_MASCULINO_PALAVRAS e PREPOSICAO_FEMININA_PALAVRAS.
        """
        if not texto:
            return texto

        # Auxiliar para remover acentos
        def normalizar_acentos(palavra: str) -> str:
            resultado = palavra
            for char, sem_acento in [('á', 'a'), ('é', 'e'), ('í', 'i'), ('ó', 'o'), ('ú', 'u'),
                                   ('â', 'a'), ('ê', 'e'), ('ô', 'o'), ('ã', 'a'), ('õ', 'o'),
                                   ('ç', 'c'), ('à', 'a')]:
                resultado = resultado.replace(char, sem_acento)
            return resultado

        # Converter "Não" -> "No"/"Na" quando for preposição
        palavras = texto.split()
        resultado = []

        for i, palavra in enumerate(palavras):
            palavra_lower = palavra.lower().rstrip('.,;!?:')

            if palavra_lower in ['não', 'nao']:
                # Verificar próxima palavra para determinar gênero
                if i + 1 < len(palavras):
                    proxima = palavras[i + 1].lower().rstrip('.,;!?:')
                    proxima_normalized = normalizar_acentos(proxima)

                    # Verificar se é preposição feminina
                    if proxima_normalized in PREPOSICAO_FEMININA_PALAVRAS or any(
                        proxima_normalized.startswith(p) for p in PREPOSICAO_FEMININA_PALAVRAS
                    ):
                        resultado.append('Na' if palavra[0].isupper() else 'na')
                    # Verificar se é preposição masculina
                    elif proxima_normalized in PREPOSICAO_MASCULINO_PALAVRAS or any(
                        proxima_normalized.startswith(p) for p in PREPOSICAO_MASCULINO_PALAVRAS
                    ):
                        resultado.append('No' if palavra[0].isupper() else 'no')
                    else:
                        resultado.append(palavra)
                else:
                    resultado.append(palavra)
            else:
                resultado.append(palavra)

        texto = ' '.join(resultado)

        # Corrigir "n" isolado (sempre deve ser "não")
        texto = re.sub(r'\bn\b(?!\w)', 'não', texto, flags=re.IGNORECASE)

        # Corrigir "nõ" (sempre deve ser "não")
        texto = re.sub(r'\bnõ\b', 'não', texto, flags=re.IGNORECASE)

        # Corrigir "no" no final de frase ou seguido de pontuação
        texto = re.sub(r'\bno([.,;!?]|$)', r'não\1', texto, flags=re.IGNORECASE)

        # Corrigir "no" seguido de verbos que indicam negação
        verbos_negacao = ['é', 'foi', 'está', 'esta', 'tem', 'pode', 'deve', 'funciona', 'existe']
        for verbo in verbos_negacao:
            padrao = rf'\bno\s+({verbo})\b'
            texto = re.sub(padrao, r'não \1', texto, flags=re.IGNORECASE)

        # Último passe: "no"/"na" seguidos de palavras que claramente indicam preposição devem estar certos
        palavras = texto.split()
        resultado = []
        for i, palavra in enumerate(palavras):
            palavra_lower = palavra.lower()
            if palavra_lower in ['no', 'na']:
                if i + 1 < len(palavras):
                    proxima = palavras[i + 1].lower().rstrip('.,;!?:')
                    proxima_normalized = normalizar_acentos(proxima)

                    if palavra_lower == 'no' and proxima_normalized not in PREPOSICAO_MASCULINO_PALAVRAS:
                        resultado.append('não')
                    elif palavra_lower == 'na' and proxima_normalized not in PREPOSICAO_FEMININA_PALAVRAS:
                        resultado.append('não')
                    else:
                        resultado.append(palavra)
                else:
                    resultado.append('não')  # Última palavra
            else:
                resultado.append(palavra)

        texto = ' '.join(resultado)

        return texto

    async def _parse_webhook_data(
        self, 
        request: web.Request, 
        post_data: Any  # MultiDict do aiohttp
    ) -> Dict[str, Any]:
        """Extrai e parseia os dados do webhook."""
        data = {}

        # request.post() retorna um MultiDict, não bytes
        # Tentar obter 'content' do MultiDict
        if post_data and hasattr(post_data, 'get'):
            content = post_data.get('content', '')

            if content:
                # Se content é string, tentar decodificar
                if isinstance(content, str):
                    try:
                        decoded_content = urllib.parse.unquote_plus(content)
                        data = json.loads(decoded_content, strict=False)
                    except (json.JSONDecodeError, ValueError):
                        try:
                            data = json.loads(content, strict=False)
                        except (json.JSONDecodeError, ValueError):
                            data = {}
                elif isinstance(content, bytes):
                    # Se content é bytes, tentar decodificar
                    encodings = ['utf-8', 'iso-8859-1', 'cp1252', 'latin-1', 'windows-1252']
                    for encoding in encodings:
                        try:
                            decoded_content = content.decode(encoding)
                            decoded_content = urllib.parse.unquote_plus(decoded_content)
                            data = json.loads(decoded_content, strict=False)
                            break
                        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
                            continue

            # Se não encontrou 'content' ou não conseguiu parsear, tentar converter todo o post_data
            if not data:
                try:
                    # MultiDict pode ser convertido para dict (pegar primeiro valor de cada chave)
                    if hasattr(post_data, 'items'):
                        data = {k: v for k, v in post_data.items()}
                    else:
                        data = dict(post_data) if post_data else {}
                except (TypeError, ValueError, AttributeError):
                    data = {}

        # Se ainda não tem dados, tentar ler o body diretamente
        if not data:
            try:
                raw_body = await request.read()
                encodings = ['utf-8', 'iso-8859-1', 'cp1252', 'latin-1']

                for encoding in encodings:
                    try:
                        decoded_body = raw_body.decode(encoding)
                        data = json.loads(decoded_body, strict=False)
                        break
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        continue
                else:
                    try:
                        data = await request.json()
                    except (json.JSONDecodeError, ValueError, Exception):
                        data = {}
            except (ValueError, AttributeError, Exception):
                try:
                    data = await request.json()
                except (json.JSONDecodeError, ValueError, Exception):
                    data = dict(post_data) if post_data else {}

        return data

    def _should_ignore_webhook(self, data: Dict[str, Any]) -> bool:
        """Verifica se o webhook deve ser ignorado."""
        if data.get('action') == 'save.point':
            return True

        data_inner = data.get('data', {})
        if isinstance(data_inner, dict) and 'TPonto' in data_inner:
            return True

        return False

    async def start_webserver(self) -> None:
        self.web_server = web.Application()
        self.web_server.router.add_get('/', self.handle_health)
        self.web_server.router.add_get('/deskwebhook', self.handle_health)
        self.web_server.router.add_post('/deskwebhook',
                                        self.handle_deskmanager)
        runner = web.AppRunner(self.web_server)
        await runner.setup()

        site = web.TCPSite(runner, '0.0.0.0', Config.PORT)
        await site.start()
        logger.info(f"Servidor Web iniciado na porta {Config.PORT}")

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.Response(
            text="Bot NextCompany Online! Webhook: POST /deskwebhook",
            status=200)

    async def handle_deskmanager(self, request: web.Request) -> web.Response:
        # CORREÇÃO: Adicionar timeout de 30 segundos no handler completo
        try:
            return await asyncio.wait_for(
                self._process_webhook(request),
                timeout=30.0
            )
        except asyncio.TimeoutError:
            logger.error("⏱️ Timeout no processamento do webhook (30s)")
            return web.Response(text="Timeout", status=200)
        except Exception as e:
            logger.error(f"Erro no handler do webhook: {e}", exc_info=True)
            return web.Response(text="Erro", status=200)

    async def _process_webhook(self, request: web.Request) -> web.Response:  # pyright: ignore[reportComplexity]
        """Processa o webhook internamente (extraído para permitir timeout)"""
        try:
            post_data = await request.post()
            data = await self._parse_webhook_data(request, post_data)

            # Verificar se deve ignorar o webhook
            if self._should_ignore_webhook(data):
                return web.Response(text="Ignorado", status=200)

            # Verificar duplicatas: criar chave única baseada em chamado + interação + timestamp
            chamado_cod = str(data.get('chamado_cod', data.get('chamado', '')))
            interacao_cod = str(data.get('interacao_cod', ''))
            timestamp = str(data.get('datacri', '')) + '_' + str(
                data.get('horacri', ''))
            webhook_key = (chamado_cod, interacao_cod, timestamp)

            # Limpar cache expirado periodicamente (a cada 5 minutos) ou se estiver muito grande
            current_time = time.time()
            should_cleanup = (
                current_time - self._last_cache_cleanup > self._cache_cleanup_interval
                or len(self.processed_webhooks) > self.max_cache_size
            )

            if should_cleanup:
                expired_keys = []
                for k, v in self.processed_webhooks.items():
                    # Limpar entradas expiradas (com timestamp) e entradas antigas (com True)
                    if isinstance(v, (int, float)):
                        if current_time - v > self.cache_ttl:
                            expired_keys.append(k)
                    elif v is True:
                        # Entrada antiga com formato antigo (True), remover
                        expired_keys.append(k)

                for key in expired_keys:
                    del self.processed_webhooks[key]

                # Se ainda estiver muito grande após limpeza de expirados, remover os mais antigos
                if len(self.processed_webhooks) > self.max_cache_size:
                    # Ordenar por timestamp e manter apenas os mais recentes
                    sorted_items = sorted(
                        self.processed_webhooks.items(),
                        key=lambda x: x[1] if isinstance(x[1], (int, float)) else 0,
                        reverse=True
                    )
                    keys_to_keep = [k for k, v in sorted_items[:CACHE_REDUCE_TO]]
                    self.processed_webhooks = {k: self.processed_webhooks[k] for k in keys_to_keep}

                self._last_cache_cleanup = current_time

            if webhook_key in self.processed_webhooks:
                logger.info(
                    f"⚠️ Webhook duplicado ignorado: chamado={chamado_cod}, interacao={interacao_cod}"
                )
                return web.Response(text="Duplicado", status=200)

            # Adicionar ao cache com timestamp
            self.processed_webhooks[webhook_key] = current_time

            logger.info(
                f"🔍 Payload completo: {json.dumps(data, ensure_ascii=False, indent=2)[:LOG_PAYLOAD_MAX_LENGTH]}"
            )

            # Log de todos os campos disponíveis para debug
            logger.info(f"🔑 Chaves disponíveis no webhook: {list(data.keys())}")

            # Log detalhado de campos que podem conter detalhamento
            campos_potenciais = ['descricao', 'Descricao', 'detalhes', 'Detalhes', 'detalhamento', 'Detalhamento', 
                                'observacao', 'Observacao', 'texto', 'Texto', 'comentario', 'Comentario',
                                'Detalhamento da Causa', 'detalhamento_da_causa', 'DetalhamentoDaCausa']
            for campo in campos_potenciais:
                valor = data.get(campo)
                if valor:
                    logger.info(f"🔍 Campo '{campo}' encontrado: {repr(str(valor)[:100])}")

            # Log específico para campos que contêm "detalhamento" ou "causa" no nome
            for key, value in data.items():
                if isinstance(key, str) and isinstance(value, str):
                    key_lower = key.lower()
                    if ('detalhamento' in key_lower or 'causa' in key_lower) and len(str(value).strip()) > 5:
                        logger.info(f"🔍 Campo relacionado encontrado: '{key}' = {repr(str(value)[:100])}")

            # Log específico para campos que contêm "cliente", "empresa" ou "solicitante" no nome
            for key, value in data.items():
                if isinstance(key, str) and isinstance(value, str):
                    key_lower = key.lower()
                    if ('cliente' in key_lower or 'empresa' in key_lower or 'solicitante' in key_lower or 'contato' in key_lower) and 'cod' not in key_lower and 'id' not in key_lower:
                        if len(str(value).strip()) > 2 and not str(value).strip().isdigit():
                            logger.info(f"🔍 Campo de cliente/solicitante encontrado: '{key}' = {repr(str(value)[:100])}")

            # Log específico para campos numéricos (possíveis IDs de campos customizados do Desk.ms)
            campos_numericos = {k: v for k, v in data.items() if isinstance(k, str) and k.isdigit()}
            if campos_numericos:
                logger.info(f"🔢 Campos customizados (numéricos) encontrados: {list(campos_numericos.keys())}")
                for key, value in campos_numericos.items():
                    if isinstance(value, str) and len(str(value).strip()) > 10:
                        logger.info(f"   Campo '{key}': {repr(str(value)[:100])}")

            # Verificar se há campos extras
            campos_extras = (
                data.get('campos_extras')
                or data.get('extra_fields')
                or data.get('custom_fields')
                or data.get('CamposExtras')
                or data.get('ExtraFields')
                or data.get('CustomFields')
            )
            if campos_extras:
                logger.info(f"📦 Campos extras encontrados: {type(campos_extras)} - {str(campos_extras)[:LOG_CAMPOS_EXTRAS_MAX_LENGTH]}")

            channel = self.bot.get_channel(Config.DESK_CHANNEL_ID)
            if channel:
                # Pegar assunto bruto e aplicar múltiplas correções
                raw_assunto = data.get('assunto') or data.get(
                    'Subject') or data.get('assunto_texto') or 'Atualizacao'

                # IMPORTANTE: Decodificar URL encoding se presente (ex: %E7 = ç, %E3 = ã)
                if raw_assunto and isinstance(raw_assunto, str):
                    try:
                        # Tentar decodificar URL encoding
                        raw_assunto = urllib.parse.unquote_plus(raw_assunto)
                    except (ValueError, TypeError, AttributeError):
                        # Se falhar, manter o original
                        pass

                # Log do assunto antes da correção para debug
                logger.info(f"📝 Assunto ANTES fix_text: {repr(raw_assunto)}")

                # Aplicar fix_text uma vez (a função já é robusta o suficiente)
                raw_assunto = fix_text(raw_assunto)

                # CORREÇÃO PRIORITÁRIA: "Dvida" -> "Dúvida" ANTES de outras correções
                # CORREÇÃO: Otimizar loops de correção (reduzir de 3 para 1)
                # Aplicar correção uma vez (otimizado)
                raw_assunto = re.sub(r'\bD[vV]ida\b', 'Dúvida', raw_assunto, flags=re.IGNORECASE)
                raw_assunto = re.sub(r'\bD[uU]vida\b', 'Dúvida', raw_assunto, flags=re.IGNORECASE)
                # Correções simples
                raw_assunto = raw_assunto.replace('DVIDA', 'DÚVIDA').replace('DUVIDA', 'DÚVIDA')
                raw_assunto = raw_assunto.replace('Dvida', 'Dúvida').replace('Duvida', 'Dúvida')
                raw_assunto = raw_assunto.replace('dvida', 'dúvida').replace('duvida', 'dúvida')
                raw_assunto = raw_assunto.replace('Dvida/', 'Dúvida/').replace('Dvida ', 'Dúvida ')
                raw_assunto = raw_assunto.replace('Duvida/', 'Dúvida/').replace('Duvida ', 'Dúvida ')

                # Log do assunto depois da correção
                logger.info(f"✅ Assunto DEPOIS fix_text: {repr(raw_assunto)}")

                if not raw_assunto or raw_assunto == 'None':
                    return web.Response(text="Sem assunto", status=200)

                # PRIORIDADE 1: Buscar ID do operador primeiro (mais confiável)
                operator_id_fallback = None
                operator_id_raw = (
                    data.get('analista_cod')  # Campo usado pelo Desk.ms (ex: "000042")
                    or data.get('analista_id')
                    or data.get('operador_cod')  # Campo usado pelo Desk.ms
                    or data.get('operador_id')
                    or data.get('operator_id')
                    or data.get('OperatorId')
                    or data.get('responsavel_cod')  # Campo usado pelo Desk.ms
                    or data.get('responsavel_id')
                    or data.get('atendente_cod')  # Campo usado pelo Desk.ms
                    or data.get('atendente_id')
                )

                # Tentar também campos aninhados para ID
                if not operator_id_raw and isinstance(data.get('Operator'), dict):
                    operator_id_raw = (
                        data.get('Operator', {}).get('Id')
                        or data.get('Operator', {}).get('ID')
                        or data.get('Operator', {}).get('id')
                    )
                if not operator_id_raw and isinstance(data.get('analista'), dict):
                    operator_id_raw = (
                        data.get('analista', {}).get('cod')
                        or data.get('analista', {}).get('Cod')
                        or data.get('analista', {}).get('COD')
                        or data.get('analista', {}).get('Id')
                        or data.get('analista', {}).get('ID')
                        or data.get('analista', {}).get('id')
                        or data.get('analista', {}).get('IdAnalista')
                    )
                if not operator_id_raw and isinstance(data.get('operador'), dict):
                    operator_id_raw = (
                        data.get('operador', {}).get('cod')
                        or data.get('operador', {}).get('Cod')
                        or data.get('operador', {}).get('COD')
                        or data.get('operador', {}).get('Id')
                        or data.get('operador', {}).get('ID')
                        or data.get('operador', {}).get('id')
                    )

                if operator_id_raw:
                    operator_id_str = str(operator_id_raw).strip()
                    if operator_id_str.isdigit():
                        operator_id_fallback = operator_id_str
                        logger.info(
                            f"✅ ID do operador encontrado em campo de ID: {operator_id_fallback}"
                        )
                    elif operator_id_str and len(operator_id_str) <= 5 and operator_id_str.replace(' ', '').isdigit():
                        operator_id_fallback = operator_id_str.replace(' ', '')
                        logger.info(
                            f"✅ ID do operador encontrado (com espaços): {operator_id_fallback}"
                        )

                # PRIORIDADE 2: Buscar nome do operador em múltiplos campos possíveis
                raw_analista = (
                    data.get('analista_nome')
                    or data.get('operador_nome')
                    or data.get('responsavel_nome')
                    or data.get('atendente_nome')
                    or data.get('operator_name')
                    or data.get('OperatorName')
                    or data.get('Analista')
                    or data.get('analista')
                    or data.get('resolvido_por')
                    or data.get('ResolvedBy')
                    or data.get('fechado_por')
                    or data.get('NomeOperador')
                    or data.get('SobrenomeOperador')
                )

                # Tentar também campos aninhados para nome
                if not raw_analista and isinstance(data.get('Operator'), dict):
                    raw_analista = data.get('Operator', {}).get('Name') or data.get('Operator', {}).get('Nome')
                if not raw_analista and isinstance(data.get('Operator'), str):
                    raw_analista = data.get('Operator')

                # Se ainda não temos ID mas o nome parece ser um ID numérico, usar como fallback
                if not operator_id_fallback and raw_analista:
                    raw_analista_str = str(raw_analista).strip()
                    # Verificar se é apenas um número (ID)
                    if raw_analista_str.isdigit():
                        logger.info(
                            f"⚠️ Campo de nome contém ID numérico: {raw_analista_str}, usando como ID..."
                        )
                        operator_id_fallback = raw_analista_str
                        raw_analista = None
                    # Também verificar se começa com número seguido de espaço ou nada útil
                    elif raw_analista_str and len(raw_analista_str) <= 5 and raw_analista_str.replace(' ', '').isdigit():
                        logger.info(
                            f"⚠️ Campo de nome parece ser ID: {raw_analista_str}, usando como ID..."
                        )
                        operator_id_fallback = raw_analista_str.replace(' ', '')
                        raw_analista = None

                # Log para debug: mostrar todos os campos relacionados a operador
                if not raw_analista and not operator_id_fallback:
                    campos_operador = {k: v for k, v in data.items() if 'oper' in k.lower() or 'analist' in k.lower() or 'respons' in k.lower()}
                    if campos_operador:
                        logger.info(f"🔍 Campos relacionados a operador encontrados: {campos_operador}")

                # Buscar nome do cliente em múltiplos campos possíveis
                raw_empresa = (
                    data.get('cliente_nome')
                    or data.get('ClienteNome')
                    or data.get('clienteNome')
                    or data.get('customer_nome')
                    or data.get('CustomerNome')
                    or data.get('empresa_nome')
                    or data.get('EmpresaNome')
                    or data.get('empresa')
                    or data.get('Empresa')
                    or data.get('cliente')
                    or data.get('Cliente')
                    or data.get('nome_cliente')
                    or data.get('NomeCliente')
                    or data.get('razao_social')
                    or data.get('RazaoSocial')
                )

                # Buscar também em estruturas aninhadas
                if isinstance(data.get('Customer'), dict):
                    raw_empresa = raw_empresa or data.get('Customer', {}).get('Name') or data.get('Customer', {}).get('Nome') or data.get('Customer', {}).get('RazaoSocial')
                if isinstance(data.get('Cliente'), dict):
                    raw_empresa = raw_empresa or data.get('Cliente', {}).get('Name') or data.get('Cliente', {}).get('Nome') or data.get('Cliente', {}).get('RazaoSocial')
                if isinstance(data.get('Empresa'), dict):
                    raw_empresa = raw_empresa or data.get('Empresa', {}).get('Name') or data.get('Empresa', {}).get('Nome') or data.get('Empresa', {}).get('RazaoSocial')

                # Buscar em todos os campos que contenham "cliente", "empresa" ou "customer" no nome
                if not raw_empresa or raw_empresa == "None" or raw_empresa.strip() == "":
                    for key, value in data.items():
                        if isinstance(key, str) and isinstance(value, str):
                            key_lower = key.lower()
                            if ('cliente' in key_lower or 'empresa' in key_lower or 'customer' in key_lower) and 'cod' not in key_lower and 'id' not in key_lower:
                                if len(value.strip()) > 2 and value.strip() != "None" and not value.strip().isdigit():
                                    raw_empresa = value
                                    logger.info(f"✅ Cliente/Empresa encontrado no campo '{key}': {repr(raw_empresa[:100])}")
                                    break

                # Se não encontrou nome mas tem código do cliente, usar o código como fallback
                if not raw_empresa or raw_empresa == "None" or raw_empresa.strip() == "":
                    cliente_cod = (
                        data.get('cliente_cod')
                        or data.get('ClienteCod')
                        or data.get('clienteCod')
                        or data.get('customer_cod')
                        or data.get('CustomerCod')
                    )
                    if cliente_cod and str(cliente_cod).strip() and str(cliente_cod) != "None":
                        raw_empresa = f"Cliente #{cliente_cod}"

                # CORREÇÃO: Remover chamada redundante de fix_text
                raw_empresa = fix_text(raw_empresa) if raw_empresa else ''

                nome_pessoa = (
                    data.get('solicitante_nome')
                    or data.get('SolicitanteNome')
                    or data.get('contato_nome')
                    or data.get('ContatoNome')
                    or data.get('usuario_nome')
                    or data.get('UsuarioNome')
                    or data.get('nome_usuario')
                    or data.get('NomeUsuario')
                    or data.get('nome_solicitante')
                    or data.get('NomeSolicitante')
                )
                requester = data.get('Requester')
                if isinstance(requester, dict):
                    nome_pessoa = nome_pessoa or requester.get('Name') or requester.get('Nome') or requester.get('NomeCompleto')
                contact = data.get('Contact')
                if isinstance(contact, dict):
                    nome_pessoa = nome_pessoa or contact.get('Name') or contact.get('Nome') or contact.get('NomeCompleto')

                # Buscar em todos os campos que contenham "solicitante", "contato" ou "usuario" no nome
                if not nome_pessoa or nome_pessoa == "None" or nome_pessoa.strip() == "":
                    for key, value in data.items():
                        if isinstance(key, str) and isinstance(value, str):
                            key_lower = key.lower()
                            if ('solicitante' in key_lower or 'contato' in key_lower or 'usuario' in key_lower or 'user' in key_lower) and 'cod' not in key_lower and 'id' not in key_lower:
                                if len(value.strip()) > 2 and value.strip() != "None" and not value.strip().isdigit():
                                    nome_pessoa = value
                                    logger.info(f"✅ Solicitante/Contato encontrado no campo '{key}': {repr(nome_pessoa[:100])}")
                                    break

                # CORREÇÃO: Remover chamada redundante de fix_text
                nome_pessoa = fix_text(nome_pessoa) if nome_pessoa else ''

                # Log para debug
                logger.info(f"🔍 Cliente - nome_pessoa: {repr(nome_pessoa)}, raw_empresa: {repr(raw_empresa)}")

                cliente_final = None
                if nome_pessoa and raw_empresa:
                    if nome_pessoa.strip().lower() == raw_empresa.strip().lower():
                        cliente_final = raw_empresa
                        logger.info(f"✅ Cliente final (iguais): {cliente_final}")
                    else:
                        cliente_final = f"{nome_pessoa} ({raw_empresa})"
                        logger.info(f"✅ Cliente final (combinado): {cliente_final}")
                elif nome_pessoa:
                    cliente_final = nome_pessoa
                    logger.info(f"✅ Cliente final (apenas pessoa): {cliente_final}")
                elif raw_empresa:
                    cliente_final = raw_empresa
                    logger.info(f"✅ Cliente final (apenas empresa): {cliente_final}")

                # Se ainda não encontrou cliente, buscar em outros campos possíveis
                if not cliente_final or cliente_final == "None" or cliente_final.strip() == "":
                    # Buscar em campos genéricos que podem conter o nome do cliente
                    campos_possiveis = ['nome_cliente', 'NomeCliente', 'name', 'Name', 'razao_social', 'RazaoSocial']
                    for campo in campos_possiveis:
                        valor = data.get(campo)
                        if valor and str(valor).strip() and str(valor) != "None":
                            cliente_final = fix_text(str(valor))
                            logger.info(f"✅ Cliente encontrado no campo '{campo}': {cliente_final}")
                            break

                # Se ainda não encontrou, usar código do cliente como último recurso
                if not cliente_final or cliente_final == "None" or cliente_final.strip() == "":
                    cliente_cod = (
                        data.get('cliente_cod')
                        or data.get('ClienteCod')
                        or data.get('clienteCod')
                        or data.get('customer_cod')
                        or data.get('CustomerCod')
                    )
                    if cliente_cod and str(cliente_cod).strip() and str(cliente_cod) != "None":
                        cliente_final = f"Cliente #{cliente_cod}"
                        logger.info(f"✅ Usando código do cliente como fallback: {cliente_final}")

                # Aplicar fix_text no cliente final para garantir correção completa
                if cliente_final and cliente_final != "None" and cliente_final.strip() != "":
                    cliente_final = fix_text(cliente_final)

                    # CORREÇÃO: Remover "#" duplicado e normalizar formato
                    # Casos: "#cliente #379" -> "Cliente #379", "cliente #379" -> "Cliente #379"
                    cliente_final = re.sub(r'^#*\s*cliente\s*#*\s*(\d+)$', r'Cliente #\1', cliente_final, flags=re.IGNORECASE)
                    cliente_final = re.sub(r'^#*\s*cliente\s*#*\s*(\d+)\s*$', r'Cliente #\1', cliente_final, flags=re.IGNORECASE)
                    # Se ainda tiver "#" duplicado no meio, remover
                    cliente_final = re.sub(r'#+\s*#+', '#', cliente_final)
                    # Garantir que comece com "Cliente" (C maiúsculo) se tiver padrão de cliente
                    if re.match(r'^#*\s*cliente\s*#', cliente_final, re.IGNORECASE):
                        cliente_final = re.sub(r'^#*\s*cliente\s*#', 'Cliente #', cliente_final, flags=re.IGNORECASE)
                else:
                    # Último recurso: se realmente não encontrou nada, usar "Não informado"
                    cliente_final = "Não informado"
                    logger.warning(f"⚠️ Cliente não encontrado em nenhum campo. Campos disponíveis: {list(data.keys())}")

                operador_final = None

                # PRIORIDADE: Se temos um ID, tentar resolver primeiro (mais confiável)
                if operator_id_fallback:
                    resolved = await self.resolve_operator_name(
                        operator_id_fallback)
                    if resolved:
                        operador_final = self._normalize_operator_name(resolved)
                        logger.info(
                            f"✅ Operador resolvido via ID {operator_id_fallback}: {operador_final}"
                        )
                    else:
                        logger.warning(
                            f"⚠️ Não foi possível resolver operador ID {operator_id_fallback}"
                        )

                # Se não conseguimos resolver pelo ID, usar o nome do campo
                if not operador_final and raw_analista:
                    if isinstance(raw_analista, dict):
                        raw_name = raw_analista.get('Name', '')
                    else:
                        raw_name = str(raw_analista)

                    operador_final = self._normalize_operator_name(raw_name) or None

                    if operador_final:
                        logger.info(
                            f"✅ Operador obtido do campo de nome: {operador_final}"
                        )

                # Se ainda não temos operador, usar fallback padrão
                if not operador_final:
                    logger.warning(
                        f"⚠️ Operador não encontrado. ID fallback: {operator_id_fallback}, Nome raw: {raw_analista}"
                    )
                    operador_final = "Não informado"

                # Aplicar normalização final para garantir correção completa (incluindo "caro" -> "Ícaro")
                if operador_final and operador_final != "Não informado":
                    operador_final = self._normalize_operator_name(operador_final)

                status = fix_text(str(data.get('status_nome', 'Novo')))
                # CORREÇÃO: Remover chamada redundante de fix_text
                status_low = status.lower()
                # Nota: prioridade não é usada atualmente, mas mantida para possível uso futuro
                # prioridade = fix_text(data.get('prioridade_nome', '')) if data.get('prioridade_nome') else ''

                # Buscar campo "Causa" do chamado
                causa = (
                    data.get('causa')
                    or data.get('causa_nome')
                    or data.get('causa_chamado')
                    or data.get('Causa')
                    or data.get('CausaNome')
                    or data.get('CausaChamado')
                    or data.get('motivo')
                    or data.get('Motivo')
                    or data.get('nome_causa')
                    or data.get('NomeCausa')
                )
                # Tentar também campos aninhados
                if not causa and isinstance(data.get('Causa'), dict):
                    causa = data.get('Causa', {}).get('Nome') or data.get('Causa', {}).get('Name')
                if not causa:
                    # Buscar em todos os campos que contenham "causa" no nome
                    for key, value in data.items():
                        if isinstance(key, str) and isinstance(value, str):
                            key_lower = key.lower()
                            if 'causa' in key_lower and 'detalhamento' not in key_lower and len(value.strip()) > 3:
                                # Verificar se não é um código numérico
                                if not value.strip().isdigit():
                                    causa = value
                                    logger.info(f"✅ Causa encontrada no campo '{key}': {repr(causa[:100])}")
                                    break
                if causa:
                    causa = fix_text(str(causa))
                    # CORREÇÃO: Remover chamada redundante e otimizar loop
                    # Aplicar correção uma vez (otimizado)
                    causa = re.sub(r'\bD[vV]ida\b', 'Dúvida', causa, flags=re.IGNORECASE)
                    causa = re.sub(r'\bD[uU]vida\b', 'Dúvida', causa, flags=re.IGNORECASE)
                    # Correções simples
                    causa = causa.replace('DVIDA', 'DÚVIDA').replace('DUVIDA', 'DÚVIDA')
                    causa = causa.replace('Dvida', 'Dúvida').replace('Duvida', 'Dúvida')
                    causa = causa.replace('dvida', 'dúvida').replace('duvida', 'dúvida')
                    causa = causa.replace('Dvida/', 'Dúvida/').replace('Dvida ', 'Dúvida ')
                    causa = causa.replace('Duvida/', 'Dúvida/').replace('Duvida ', 'Dúvida ')

                    # CORREÇÃO: "Rejeies" -> "Rejeições" (todas as variações)
                    causa = re.sub(r'\bRejeies\b', 'Rejeições', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Rejeies', 'Rejeições')
                    causa = causa.replace('REJEIES', 'REJEIÇÕES')
                    causa = causa.replace('rejeies', 'rejeições')
                    causa = causa.replace('Rejeio', 'Rejeição')
                    causa = causa.replace('REJEIO', 'REJEIÇÃO')
                    causa = causa.replace('rejeio', 'rejeição')
                    # CORREÇÃO: "numero" -> "número"
                    causa = re.sub(r'\bnumero\b', 'número', causa, flags=re.IGNORECASE)
                    causa = causa.replace('numero', 'número')
                    causa = causa.replace('Numero', 'Número')
                    causa = causa.replace('NUMERO', 'NÚMERO')
                    # CORREÇÃO: "diferenaa" -> "diferença"
                    causa = re.sub(r'\bdiferenaa\b', 'diferença', causa, flags=re.IGNORECASE)
                    causa = causa.replace('diferenaa', 'diferença')
                    causa = causa.replace('Diferenaa', 'Diferença')
                    causa = causa.replace('DIFERENAA', 'DIFERENÇA')
                    # CORREÇÃO: "calculo" -> "cálculo"
                    causa = re.sub(r'\bcalculo\b', 'cálculo', causa, flags=re.IGNORECASE)
                    causa = causa.replace('calculo', 'cálculo')
                    causa = causa.replace('Calculo', 'Cálculo')
                    causa = causa.replace('CALCULO', 'CÁLCULO')
                    # CORREÇÃO: "permisses" -> "permissões"
                    causa = re.sub(r'\bpermisses\b', 'permissões', causa, flags=re.IGNORECASE)
                    causa = causa.replace('permisses', 'permissões')
                    causa = causa.replace('Permisses', 'Permissões')
                    causa = causa.replace('PERMISSES', 'PERMISSÕES')
                    # CORREÇÃO: "Destinatrio" -> "Destinatário"
                    causa = re.sub(r'\bdestinatrio\b', 'destinatário', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Destinatrio', 'Destinatário')
                    causa = causa.replace('destinatrio', 'destinatário')
                    causa = causa.replace('DESTINATRIO', 'DESTINATÁRIO')
                    # CORREÇÃO: "impressãora" -> "impressora"
                    causa = re.sub(r'\bimpressãora\b', 'impressora', causa, flags=re.IGNORECASE)
                    causa = causa.replace('impressãora', 'impressora')
                    causa = causa.replace('Impressãora', 'Impressora')
                    causa = causa.replace('IMPRESSÃORA', 'IMPRESSORA')
                    # CORREÇÃO: "executvel" -> "executável"
                    causa = re.sub(r'\bexecutvel\b', 'executável', causa, flags=re.IGNORECASE)
                    causa = causa.replace('executvel', 'executável')
                    causa = causa.replace('Executvel', 'Executável')
                    causa = causa.replace('EXECUTVEL', 'EXECUTÁVEL')
                    # CORREÇÃO: "verso" -> "versão"
                    causa = re.sub(r'\bverso\b', 'versão', causa, flags=re.IGNORECASE)
                    causa = causa.replace('verso', 'versão')
                    causa = causa.replace('Verso', 'Versão')
                    causa = causa.replace('VERSO', 'VERSÃO')
                    # CORREÇÃO: "Oscilão" -> "Oscilação"
                    causa = re.sub(r'\bOscilão\b', 'Oscilação', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Oscilão', 'Oscilação')
                    causa = causa.replace('oscilão', 'oscilação')
                    causa = causa.replace('OSCILÃO', 'OSCILAÇÃO')
                    # CORREÇÃO: "Orientaes" -> "Orientações"
                    causa = re.sub(r'\bOrientaes\b', 'Orientações', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Orientaes', 'Orientações')
                    causa = causa.replace('orientaes', 'orientações')
                    causa = causa.replace('ORIENTAES', 'ORIENTAÇÕES')
                    # CORREÇÃO: "Auxlio" -> "Auxílio"
                    causa = re.sub(r'\bAuxlio\b', 'Auxílio', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Auxlio', 'Auxílio')
                    causa = causa.replace('auxlio', 'auxílio')
                    causa = causa.replace('AUXLIO', 'AUXÍLIO')
                    # CORREÇÃO: "Auxilio" -> "Auxílio" (caso já tenha o "i")
                    causa = re.sub(r'\bAuxilio\b', 'Auxílio', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Auxilio', 'Auxílio')
                    causa = causa.replace('auxilio', 'auxílio')
                    causa = causa.replace('AUXILIO', 'AUXÍLIO')
                    # CORREÇÃO: "Licena" -> "Licença"
                    causa = re.sub(r'\bLicena\b', 'Licença', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Licena', 'Licença')
                    causa = causa.replace('licena', 'licença')
                    causa = causa.replace('LICENA', 'LICENÇA')
                    # CORREÇÃO: "Liena" -> "Licença"
                    causa = re.sub(r'\bLiena\b', 'Licença', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Liena', 'Licença')
                    causa = causa.replace('liena', 'licença')
                    causa = causa.replace('LIENA', 'LICENÇA')
                    # CORREÇÃO: "Liberão" -> "Liberação"
                    causa = re.sub(r'\bLiberão\b', 'Liberação', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Liberão', 'Liberação')
                    causa = causa.replace('liberão', 'liberação')
                    causa = causa.replace('LIBERÃO', 'LIBERAÇÃO')
                    # CORREÇÃO: "Tributão" -> "Tributação"
                    causa = re.sub(r'\bTributão\b', 'Tributação', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Tributão', 'Tributação')
                    causa = causa.replace('tributão', 'tributação')
                    causa = causa.replace('TRIBUTÃO', 'TRIBUTAÇÃO')
                    # CORREÇÃO: "Exportão" -> "Exportação"
                    causa = re.sub(r'\bExportão\b', 'Exportação', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Exportão', 'Exportação')
                    causa = causa.replace('exportão', 'exportação')
                    causa = causa.replace('EXPORTÃO', 'EXPORTAÇÃO')
                    # CORREÇÃO: "Exporto" -> "Exportação"
                    causa = re.sub(r'\bExporto\b', 'Exportação', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Exporto', 'Exportação')
                    causa = causa.replace('exporto', 'exportação')
                    causa = causa.replace('EXPORTO', 'EXPORTAÇÃO')
                    # CORREÇÃO: "ms" -> "mês" (quando isolado, não dentro de outras palavras)
                    causa = re.sub(r'\bms\b', 'mês', causa, flags=re.IGNORECASE)
                    causa = causa.replace(' ms ', ' mês ').replace(' ms.', ' mês.').replace(' ms,', ' mês,')
                    causa = causa.replace(' ms\n', ' mês\n').replace(' ms\r', ' mês\r')
                    # Corrigir no início/fim da string
                    if causa.startswith('ms '):
                        causa = 'mês ' + causa[3:]
                    if causa.endswith(' ms'):
                        causa = causa[:-3] + ' mês'
                    # CORREÇÃO: "prximo" -> "próximo"
                    causa = re.sub(r'\bprximo\b', 'próximo', causa, flags=re.IGNORECASE)
                    causa = causa.replace('prximo', 'próximo')
                    causa = causa.replace('Prximo', 'Próximo')
                    causa = causa.replace('PRXIMO', 'PRÓXIMO')
                    # CORREÇÃO: "Conferncia" -> "Conferência"
                    causa = re.sub(r'\bConferncia\b', 'Conferência', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Conferncia', 'Conferência')
                    causa = causa.replace('conferncia', 'conferência')
                    causa = causa.replace('CONFERNCA', 'CONFERÊNCIA')
                    # CORREÇÃO: "Pr-Venda" -> "Pré-Venda"
                    causa = re.sub(r'\bPr-Venda\b', 'Pré-Venda', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Pr-Venda', 'Pré-Venda')
                    causa = causa.replace('pr-venda', 'pré-venda')
                    causa = causa.replace('PR-VENDA', 'PRÉ-VENDA')
                    # CORREÇÃO: "Configuraes" -> "Configurações"
                    causa = re.sub(r'\bConfiguraes\b', 'Configurações', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Configuraes', 'Configurações')
                    causa = causa.replace('configuraes', 'configurações')
                    causa = causa.replace('CONFIGURAES', 'CONFIGURAÇÕES')
                    # CORREÇÃO: "Movimentaes" -> "Movimentações"
                    causa = re.sub(r'\bMovimentaes\b', 'Movimentações', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Movimentaes', 'Movimentações')
                    causa = causa.replace('movimentaes', 'movimentações')
                    causa = causa.replace('MOVIMENTAES', 'MOVIMENTAÇÕES')
                    # CORREÇÃO: "Parmetros" -> "Parâmetros"
                    causa = re.sub(r'\bParmetros\b', 'Parâmetros', causa, flags=re.IGNORECASE)
                    causa = causa.replace('Parmetros', 'Parâmetros')
                    causa = causa.replace('parmetros', 'parâmetros')
                    causa = causa.replace('PARMETROS', 'PARÂMETROS')

                    # CORREÇÃO CONTEXTUAL: "Estão" -> "Estação" apenas quando faz sentido
                    causa = self._corrigir_estao_para_estacao(causa)
                else:
                    causa = None

                if causa:
                    causa = fix_text(str(causa))
                    causa = self._corrigir_nao(causa)

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Orientaes" -> "Orientações" (caso tenha passado despercebido)
                    if 'Orientaes' in causa or 'ORIENTAES' in causa or 'orientaes' in causa:
                        causa = re.sub(r'\bOrientaes\b', 'Orientações', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Orientaes', 'Orientações').replace('ORIENTAES', 'ORIENTAÇÕES').replace('orientaes', 'orientações')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Auxlio" -> "Auxílio" (caso tenha passado despercebido)
                    if 'Auxlio' in causa or 'AUXLIO' in causa or 'auxlio' in causa:
                        causa = re.sub(r'\bAuxlio\b', 'Auxílio', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Auxlio', 'Auxílio').replace('AUXLIO', 'AUXÍLIO').replace('auxlio', 'auxílio')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Auxilio" -> "Auxílio" (caso já tenha o "i")
                    if 'Auxilio' in causa or 'AUXILIO' in causa or 'auxilio' in causa:
                        causa = re.sub(r'\bAuxilio\b', 'Auxílio', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Auxilio', 'Auxílio').replace('AUXILIO', 'AUXÍLIO').replace('auxilio', 'auxílio')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Licena" -> "Licença" (caso tenha passado despercebido)
                    if 'Licena' in causa or 'LICENA' in causa or 'licena' in causa:
                        causa = re.sub(r'\bLicena\b', 'Licença', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Licena', 'Licença').replace('LICENA', 'LICENÇA').replace('licena', 'licença')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Liena" -> "Licença" (caso tenha passado despercebido)
                    if 'Liena' in causa or 'LIENA' in causa or 'liena' in causa:
                        causa = re.sub(r'\bLiena\b', 'Licença', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Liena', 'Licença').replace('LIENA', 'LICENÇA').replace('liena', 'licença')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Liberão" -> "Liberação" (caso tenha passado despercebido)
                    if 'Liberão' in causa or 'LIBERÃO' in causa or 'liberão' in causa:
                        causa = re.sub(r'\bLiberão\b', 'Liberação', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Liberão', 'Liberação').replace('LIBERÃO', 'LIBERAÇÃO').replace('liberão', 'liberação')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Tributão" -> "Tributação" (caso tenha passado despercebido)
                    if 'Tributão' in causa or 'TRIBUTÃO' in causa or 'tributão' in causa:
                        causa = re.sub(r'\bTributão\b', 'Tributação', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Tributão', 'Tributação').replace('TRIBUTÃO', 'TRIBUTAÇÃO').replace('tributão', 'tributação')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Exportão" -> "Exportação" (caso tenha passado despercebido)
                    if 'Exportão' in causa or 'EXPORTÃO' in causa or 'exportão' in causa:
                        causa = re.sub(r'\bExportão\b', 'Exportação', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Exportão', 'Exportação').replace('EXPORTÃO', 'EXPORTAÇÃO').replace('exportão', 'exportação')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Exporto" -> "Exportação" (caso tenha passado despercebido)
                    if 'Exporto' in causa or 'EXPORTO' in causa or 'exporto' in causa:
                        causa = re.sub(r'\bExporto\b', 'Exportação', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Exporto', 'Exportação').replace('EXPORTO', 'EXPORTAÇÃO').replace('exporto', 'exportação')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "ms" -> "mês" (caso tenha passado despercebido)
                    if ' ms ' in causa or ' ms.' in causa or ' ms,' in causa or causa.startswith('ms ') or causa.endswith(' ms'):
                        causa = re.sub(r'\bms\b', 'mês', causa, flags=re.IGNORECASE)
                        causa = causa.replace(' ms ', ' mês ').replace(' ms.', ' mês.').replace(' ms,', ' mês,')
                        if causa.startswith('ms '):
                            causa = 'mês ' + causa[3:]
                        if causa.endswith(' ms'):
                            causa = causa[:-3] + ' mês'

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Rejeies" -> "Rejeições" (caso tenha passado despercebido)
                    if 'Rejeies' in causa or 'REJEIES' in causa or 'rejeies' in causa:
                        causa = re.sub(r'\bRejeies\b', 'Rejeições', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Rejeies', 'Rejeições').replace('REJEIES', 'REJEIÇÕES').replace('rejeies', 'rejeições')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "prximo" -> "próximo" (caso tenha passado despercebido)
                    if 'prximo' in causa or 'PRXIMO' in causa or 'Prximo' in causa:
                        causa = re.sub(r'\bprximo\b', 'próximo', causa, flags=re.IGNORECASE)
                        causa = causa.replace('prximo', 'próximo').replace('PRXIMO', 'PRÓXIMO').replace('Prximo', 'Próximo')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Conferncia" -> "Conferência" (caso tenha passado despercebido)
                    if 'Conferncia' in causa or 'CONFERNCA' in causa or 'conferncia' in causa:
                        causa = re.sub(r'\bConferncia\b', 'Conferência', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Conferncia', 'Conferência').replace('CONFERNCA', 'CONFERÊNCIA').replace('conferncia', 'conferência')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Pr-Venda" -> "Pré-Venda" (caso tenha passado despercebido)
                    if 'Pr-Venda' in causa or 'PR-VENDA' in causa or 'pr-venda' in causa:
                        causa = re.sub(r'\bPr-Venda\b', 'Pré-Venda', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Pr-Venda', 'Pré-Venda').replace('PR-VENDA', 'PRÉ-VENDA').replace('pr-venda', 'pré-venda')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Configuraes" -> "Configurações" (caso tenha passado despercebido)
                    if 'Configuraes' in causa or 'CONFIGURAES' in causa or 'configuraes' in causa:
                        causa = re.sub(r'\bConfiguraes\b', 'Configurações', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Configuraes', 'Configurações').replace('CONFIGURAES', 'CONFIGURAÇÕES').replace('configuraes', 'configurações')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Movimentaes" -> "Movimentações" (caso tenha passado despercebido)
                    if 'Movimentaes' in causa or 'MOVIMENTAES' in causa or 'movimentaes' in causa:
                        causa = re.sub(r'\bMovimentaes\b', 'Movimentações', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Movimentaes', 'Movimentações').replace('MOVIMENTAES', 'MOVIMENTAÇÕES').replace('movimentaes', 'movimentações')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Parmetros" -> "Parâmetros" (caso tenha passado despercebido)
                    if 'Parmetros' in causa or 'PARMETROS' in causa or 'parmetros' in causa:
                        causa = re.sub(r'\bParmetros\b', 'Parâmetros', causa, flags=re.IGNORECASE)
                        causa = causa.replace('Parmetros', 'Parâmetros').replace('PARMETROS', 'PARÂMETROS').replace('parmetros', 'parâmetros')

                # Buscar campo extra "Detalhamento da Causa" ou campo "descrinterna" (descrição interna)
                detalhamento_causa = None

                # PRIORIDADE 1: Buscar "descrinterna" (descrição interna) - contém o detalhamento da causa
                # Também buscar variações com diferentes capitalizações e em estruturas aninhadas
                detalhamento_causa = (
                    data.get('descrinterna') 
                    or data.get('Descrinterna') 
                    or data.get('DESCRINTERNA')
                    or data.get('descInterna')
                    or data.get('DescInterna')
                    or data.get('desc_interna')
                    or data.get('Desc_Interna')
                    or data.get('descricao_interna')
                    or data.get('DescricaoInterna')
                )


                # Buscar diretamente por "Detalhamento da Causa" primeiro (mais específico)
                if not detalhamento_causa:
                    detalhamento_causa = (
                        data.get('Detalhamento da Causa')
                        or data.get('detalhamento_da_causa')
                        or data.get('DetalhamentoDaCausa')
                        or data.get('detalhamento_causa')
                        or data.get('DetalhamentoCausa')
                        or data.get('detalhamentoCausa')
                    )

                # Buscar também em estruturas aninhadas
                if not detalhamento_causa:
                    if isinstance(data.get('descricao_interna'), dict):
                        detalhamento_causa = (
                            data.get('descricao_interna', {}).get('texto')
                            or data.get('descricao_interna', {}).get('Texto')
                            or data.get('descricao_interna', {}).get('value')
                            or data.get('descricao_interna', {}).get('Value')
                        )
                    if isinstance(data.get('DescricaoInterna'), dict):
                        detalhamento_causa = (
                            data.get('DescricaoInterna', {}).get('texto')
                            or data.get('DescricaoInterna', {}).get('Texto')
                            or data.get('DescricaoInterna', {}).get('value')
                            or data.get('DescricaoInterna', {}).get('Value')
                        )

                if detalhamento_causa and str(detalhamento_causa).strip() and str(detalhamento_causa).strip() != 'None':
                    logger.info(f"✅ Detalhamento da Causa encontrado em 'descrinterna' ou variação: {repr(str(detalhamento_causa)[:100])}")
                else:
                    # Log para debug: verificar o valor de descrinterna
                    descrinterna_val = data.get('descrinterna') or data.get('Descrinterna') or data.get('DESCRINTERNA')
                    if descrinterna_val:
                        logger.info(f"🔍 descrinterna encontrado mas vazio/inválido: {repr(str(descrinterna_val)[:100])}")
                    else:
                        logger.debug("🔍 descrinterna não encontrado no webhook")

                # Se descrinterna estiver vazio, tentar usar 'descr' como fallback
                # mas apenas se parecer ser um detalhamento específico (não apenas descrição genérica)
                if not detalhamento_causa:
                    descr = data.get('descr') or data.get('Descr') or data.get('DESCR') or data.get('descricao') or data.get('Descricao')
                    if descr and str(descr).strip() and str(descr).strip() != 'None':
                        descr_str = str(descr).strip()
                        # Usar descr como fallback se for plausível como detalhamento (reduzido para pegar textos curtos)
                        # Texto muito curto ou mensagens padronizadas são ignoradas
                        if len(descr_str) > 20:
                            # Verificar se não é apenas uma mensagem genérica de sistema
                            palavras_genericas = ['atendimento iniciado', 'ticket criado', 'chamado aberto', 
                                                 'suporte iniciado', 'iniciado via', 'criado em']
                            if not any(palavra in descr_str.lower() for palavra in palavras_genericas):
                                detalhamento_causa = descr_str
                                logger.info(f"✅ Detalhamento da Causa encontrado em 'descr' (fallback): {repr(descr_str[:100])}")

                # PRIORIDADE 2: Buscar campo específico "Detalhamento da Causa" nos campos extras
                if not detalhamento_causa:
                    possiveis_nomes_detalhamento = [
                        'Detalhamento da Causa',
                        'detalhamento_da_causa',
                        'DetalhamentoDaCausa',
                        'detalhamento_causa',
                        'detalhamento',
                        'Detalhamento',
                        'detalhamento_causa_texto',
                        'DetalhamentoCausaTexto',
                        'detalhamento_causa_text',
                        'DetalhamentoCausaText',
                        'detalhamento_causa_valor',
                        'DetalhamentoCausaValor',
                        'detalhamento_causa_value',
                        'DetalhamentoCausaValue',
                        'detalhamento_causa_descricao',
                        'DetalhamentoCausaDescricao',
                        'descricao_detalhamento_causa',
                        'DescricaoDetalhamentoCausa',
                        # Variações adicionais com espaços e caracteres especiais
                        'Detalhamento da causa',
                        'DETALHAMENTO DA CAUSA',
                        'detalhamentoDaCausa',
                        'DetalhamentoCausa',
                        'detalhamentoCausa',
                        # Variações com underscore
                        'detalhamento_da_causa_texto',
                        'detalhamento_da_causa_valor',
                        'detalhamento_da_causa_value',
                    ]

                    for nome in possiveis_nomes_detalhamento:
                        valor = data.get(nome)
                        if valor and str(valor).strip() and str(valor).strip() != 'None':
                            detalhamento_causa = valor
                            logger.info(f"✅ Detalhamento da Causa encontrado com nome '{nome}': {repr(str(valor)[:100])}")
                            break

                # Buscar em campos que contenham "Detalhamento da Causa:" no valor (formato comum do Desk.ms)
                if not detalhamento_causa:
                    for key, value in data.items():
                        if isinstance(value, str):
                            # Buscar por diferentes variações do texto
                            padroes = [
                                'Detalhamento da Causa:',
                                'Detalhamento da causa:',
                                'DETALHAMENTO DA CAUSA:',
                                'detalhamento da causa:',
                                'Detalhamento da Causa',
                                'detalhamento da causa',
                            ]
                            for padrao in padroes:
                                if padrao in value:
                                    # Extrair o valor após o padrão
                                    partes = value.split(padrao, 1)
                                    if len(partes) > 1:
                                        detalhamento_extraido = partes[1].strip()
                                        # Remover quebras de linha e espaços extras no início
                                        detalhamento_extraido = detalhamento_extraido.lstrip('\n\r\t ')
                                        # Pegar apenas a primeira linha se houver múltiplas linhas
                                        if '\n' in detalhamento_extraido:
                                            detalhamento_extraido = detalhamento_extraido.split('\n')[0].strip()
                                        if len(detalhamento_extraido) > 3:
                                            detalhamento_causa = detalhamento_extraido
                                            logger.info(f"✅ Detalhamento da Causa extraído do campo '{key}': {repr(detalhamento_causa[:100])}")
                                            break
                                if detalhamento_causa:
                                    break
                            if detalhamento_causa:
                                break

                # Tentar também campos aninhados
                if not detalhamento_causa and isinstance(data.get('Detalhamento'), dict):
                    detalhamento_causa = data.get('Detalhamento', {}).get('Texto') or data.get('Detalhamento', {}).get('texto') or data.get('Detalhamento', {}).get('Value') or data.get('Detalhamento', {}).get('value')
                    if detalhamento_causa:
                        logger.info("✅ Detalhamento da Causa encontrado em objeto aninhado 'Detalhamento'")

                # Busca genérica: procurar chaves que contenham "detalhamento" E "causa" juntos
                # Também buscar por "detalhamento" sozinho se o valor for significativo
                if not detalhamento_causa:
                    for key, value in data.items():
                        if value and str(value).strip() and str(value).strip() != 'None':
                            # Ignorar campos que são claramente códigos/IDs numéricos (muito curtos ou só números)
                            if isinstance(key, str) and key.isdigit() and len(str(value).strip()) < 50:
                                continue

                            if isinstance(key, str):
                                key_lower = key.lower()
                                # Buscar por "detalhamento" e "causa" juntos (campo específico)
                                if 'detalhamento' in key_lower and 'causa' in key_lower:
                                    if len(str(value).strip()) > 10:  # Verificar se não é muito curto
                                        detalhamento_causa = value
                                        logger.info(f"✅ Detalhamento da Causa encontrado por busca genérica na chave '{key}': {repr(str(value)[:100])}")
                                        break
                                # Buscar também apenas por "detalhamento" se o valor for longo (provavelmente é o detalhamento)
                                elif 'detalhamento' in key_lower and len(str(value).strip()) > 20:
                                    # Verificar se não é um campo genérico de descrição
                                    if 'descricao' not in key_lower or 'causa' in key_lower:
                                        detalhamento_causa = value
                                        logger.info(f"✅ Detalhamento da Causa encontrado por busca genérica (apenas 'detalhamento') na chave '{key}': {repr(str(value)[:100])}")
                                        break

                            # Buscar em valores que são strings longas e podem ser o detalhamento
                            # (campos customizados podem ter chaves numéricas)
                            if isinstance(value, str) and len(value.strip()) > 30:
                                value_lower = value.lower()
                                # Se o valor contém palavras-chave relacionadas a detalhamento/causa
                                palavras_chave = ['detalhamento', 'orientação', 'orientacao', 'observação', 'observacao', 
                                                 'descrição', 'descricao', 'informação', 'informacao', 'nota', 'configuração', 
                                                 'configuracao', 'emissão', 'emissao']
                                if any(palavra in value_lower for palavra in palavras_chave):
                                    # Verificar se não é o campo 'descr' que já foi processado
                                    if key != 'descr' and key != 'descricao':
                                        detalhamento_causa = value
                                        logger.info(f"✅ Detalhamento da Causa encontrado por conteúdo do valor na chave '{key}': {repr(str(value)[:100])}")
                                        break

                # Tentar buscar em diferentes estruturas de campos extras
                if not detalhamento_causa:
                    campos_extras = (
                        data.get('campos_extras')
                        or data.get('extra_fields')
                        or data.get('custom_fields')
                        or data.get('CamposExtras')
                        or data.get('ExtraFields')
                        or data.get('CustomFields')
                    )

                    # Se campos_extras é uma lista, procurar pelo campo "Detalhamento da Causa" ou campos de descrição
                    if isinstance(campos_extras, list):
                        for campo in campos_extras:
                            if isinstance(campo, dict):
                                nome_campo = campo.get('nome') or campo.get('Nome') or campo.get('name') or campo.get('Name') or campo.get('campo') or campo.get('Campo')
                                valor_campo = campo.get('valor') or campo.get('Valor') or campo.get('value') or campo.get('Value') or campo.get('texto') or campo.get('Texto')

                                # Buscar por diferentes variações do nome
                                if nome_campo and valor_campo and str(valor_campo).strip() and str(valor_campo).strip() != 'None':
                                    nome_campo_str = str(nome_campo).lower()
                                    # Prioridade: "Detalhamento da Causa"
                                    if 'detalhamento' in nome_campo_str and 'causa' in nome_campo_str:
                                        if len(str(valor_campo).strip()) > 10:
                                            detalhamento_causa = valor_campo
                                            logger.info(f"✅ Detalhamento da Causa encontrado em lista de campos extras: {nome_campo}")
                                            break
                                    # Buscar também apenas "detalhamento" se o valor for significativo
                                    elif 'detalhamento' in nome_campo_str and len(str(valor_campo).strip()) > 20:
                                        # Evitar campos genéricos de descrição
                                        if 'descricao' not in nome_campo_str or 'causa' in nome_campo_str:
                                            detalhamento_causa = valor_campo
                                            logger.info(f"✅ Detalhamento da Causa encontrado em lista de campos extras (apenas 'detalhamento'): {nome_campo}")
                                            break

                    # Se campos_extras é um dicionário, procurar diretamente
                    elif isinstance(campos_extras, dict):
                        detalhamento_causa = (
                            campos_extras.get('Detalhamento da Causa')
                            or campos_extras.get('detalhamento_da_causa')
                            or campos_extras.get('DetalhamentoDaCausa')
                            or campos_extras.get('detalhamento_causa')
                            or campos_extras.get('Detalhamento')
                            or campos_extras.get('detalhamento')
                        )
                        if detalhamento_causa:
                            logger.info("✅ Detalhamento da Causa encontrado em dicionário de campos extras")
                        # Buscar também por chaves que contenham "detalhamento"
                        if not detalhamento_causa:
                            for key, value in campos_extras.items():
                                if isinstance(key, str) and value and str(value).strip() and str(value).strip() != 'None':
                                    key_lower = key.lower()
                                    if 'detalhamento' in key_lower and len(str(value).strip()) > 20:
                                        detalhamento_causa = value
                                        logger.info(f"✅ Detalhamento da Causa encontrado em dicionário de campos extras (chave '{key}')")
                                        break

                # Busca em campos relacionados à causa (pode estar em estruturas relacionadas)
                if not detalhamento_causa and causa:
                    # Se há um campo causa_cod, pode haver um campo relacionado com o detalhamento
                    causa_cod = data.get('causa_cod') or data.get('CausaCod') or data.get('causaCod')
                    if causa_cod:
                        # Buscar campos que podem estar relacionados ao código da causa
                        for key, value in data.items():
                            if isinstance(value, str) and len(value.strip()) > 20:
                                # Verificar se é um campo relacionado à causa mas não é a causa em si
                                if key != 'causa' and key != 'Causa' and 'causa' in key.lower():
                                    if 'detalhamento' in value.lower() or 'orientação' in value.lower() or 'orientacao' in value.lower():
                                        detalhamento_causa = value
                                        logger.info(f"✅ Detalhamento da Causa encontrado em campo relacionado à causa '{key}': {repr(str(value)[:100])}")
                                        break

                # Busca específica em campos com chaves numéricas (IDs de campos customizados do Desk.ms)
                # Esses campos podem conter o detalhamento da causa mesmo quando descrinterna está vazio
                if not detalhamento_causa:
                    # Verificar campos com chaves numéricas que podem ser IDs de campos customizados
                    for key, value in data.items():
                        # Se a chave é numérica (string numérica) e o valor é uma string longa
                        if isinstance(key, str) and key.isdigit() and isinstance(value, str):
                            value_stripped = value.strip()
                            # Verificar se é uma string significativa (mais de 20 caracteres)
                            # e não é apenas um código/ID
                            if len(value_stripped) > 20 and not value_stripped.isdigit() and value_stripped != 'None':
                                # Verificar se contém conteúdo descritivo (tem letras)
                                if any(c.isalpha() for c in value_stripped):
                                    # Não deve ser email, URL ou código genérico
                                    if '@' not in value_stripped and 'http' not in value_stripped.lower():
                                        # Se parece ser um detalhamento (não é apenas descrição genérica)
                                        palavras_genericas = ['atendimento iniciado', 'ticket criado', 'chamado aberto', 
                                                             'suporte iniciado', 'iniciado via', 'criado em']
                                        if not any(palavra in value_stripped.lower() for palavra in palavras_genericas):
                                            detalhamento_causa = value
                                            logger.info(f"✅ Detalhamento da Causa encontrado em campo customizado '{key}': {repr(value_stripped[:100])}")
                                            break

                # Busca recursiva final: procurar em toda a estrutura do webhook
                if not detalhamento_causa:
                    detalhamento_recursivo = self._buscar_detalhamento_recursivo(data, profundidade_max=4)
                    if detalhamento_recursivo:
                        detalhamento_causa = detalhamento_recursivo
                        logger.info(f"✅ Detalhamento da Causa encontrado por busca recursiva: {repr(str(detalhamento_recursivo)[:100])}")

                # Busca final: verificar todos os valores string longos que podem ser o detalhamento
                # (útil para campos customizados com chaves numéricas ou não padronizadas)
                if not detalhamento_causa:
                    # Obter o assunto para comparar e evitar pegar o assunto como detalhamento
                    assunto_ticket = data.get('assunto') or data.get('Subject') or data.get('assunto_texto') or ''
                    assunto_ticket_normalized = assunto_ticket.strip().lower() if assunto_ticket else ''

                    campos_ignorados = {'descr', 'descricao', 'assunto', 'assunto_texto', 'Subject', 'subject', 
                                       'cliente_nome', 'usuario_nome', 'analista_nome', 'status_nome', 'causa', 
                                       'chamado', 'datacri', 'horacri', 'ticket', 'Ticket', 'title', 'Title'}
                    for key, value in data.items():
                        if isinstance(value, str) and key not in campos_ignorados:
                            value_stripped = value.strip()
                            # Se é uma string longa (mais de 30 caracteres) e não parece ser um código/ID
                            if len(value_stripped) > 30 and not value_stripped.isdigit() and value_stripped != 'None':
                                # Verificar se contém conteúdo descritivo (não apenas números e caracteres especiais)
                                if any(c.isalpha() for c in value_stripped):
                                    # Não deve ser email, URL ou código
                                    if '@' not in value_stripped and 'http' not in value_stripped.lower():
                                        # IMPORTANTE: Verificar se não é o assunto do ticket
                                        value_normalized = value_stripped.lower()
                                        if assunto_ticket_normalized and value_normalized == assunto_ticket_normalized:
                                            logger.debug(f"⚠️ Ignorando campo '{key}' - é igual ao assunto do ticket")
                                            continue

                                        # Verificar se não contém padrões típicos de assunto (ex: "Suporte -", "Ticket:")
                                        padroes_assunto = ['suporte -', 'ticket:', 'ticket -', 'chamado:', 'chamado -']
                                        if any(padrao in value_normalized for padrao in padroes_assunto):
                                            logger.debug(f"⚠️ Ignorando campo '{key}' - parece ser assunto do ticket")
                                            continue

                                        detalhamento_causa = value
                                        logger.info(f"✅ Detalhamento da Causa encontrado como valor longo na chave '{key}': {repr(str(value)[:100])}")
                                        break

                # Log para debug
                if detalhamento_causa:
                    logger.info(f"📝 Detalhamento da Causa encontrado: {repr(detalhamento_causa[:100])}")
                else:
                    logger.info("⚠️ Detalhamento da Causa não encontrado no webhook")

                # Processar o valor se encontrado
                if detalhamento_causa:
                    # Verificação final: garantir que não é o assunto do ticket
                    assunto_ticket_raw = data.get('assunto') or data.get('Subject') or data.get('assunto_texto') or ''

                    if assunto_ticket_raw:
                        assunto_normalized = assunto_ticket_raw.strip().lower()
                        detalhamento_normalized = str(detalhamento_causa).strip().lower()

                        # Verificar se são iguais (após normalização)
                        if assunto_normalized == detalhamento_normalized:
                            logger.warning(f"⚠️ Detalhamento igual ao assunto detectado, ignorando. Assunto: {assunto_ticket_raw[:50]}")
                            detalhamento_causa = None
                        # Verificar se o detalhamento contém o assunto e é muito similar (pode ser um campo que inclui o assunto)
                        elif assunto_normalized and assunto_normalized in detalhamento_normalized:
                            # Se a diferença for muito pequena (menos de 10 caracteres), provavelmente é o assunto
                            diferenca = len(detalhamento_normalized) - len(assunto_normalized)
                            if diferenca < 10:
                                logger.warning(f"⚠️ Detalhamento muito similar ao assunto, ignorando. Assunto: {assunto_ticket_raw[:50]}, Detalhamento: {str(detalhamento_causa)[:50]}")
                                detalhamento_causa = None

                    if detalhamento_causa:
                        # Decodificar URL encoding primeiro (ex: %C3%A7 -> ç, + -> espaço)
                        detalhamento_causa_str = str(detalhamento_causa)
                        try:
                            # Tentar decodificar URL encoding (ex: %C3%A7%C3%A3o -> ção, + -> espaço)
                            detalhamento_causa_str = urllib.parse.unquote_plus(detalhamento_causa_str)
                            logger.info(f"🔓 Detalhamento decodificado de URL encoding: {repr(detalhamento_causa_str[:100])}")
                        except (ValueError, TypeError, AttributeError):
                            # Se falhar, manter o original
                            logger.debug("⚠️ Não foi possível decodificar URL encoding do detalhamento")

                        # CORREÇÃO PRIORITÁRIA: Corrigir "correo" -> "correção" ANTES do fix_text
                        # para evitar que seja corrompido durante o processamento
                        detalhamento_causa_str = re.sub(r'\bcorreo\b', 'correção', detalhamento_causa_str, flags=re.IGNORECASE)
                        detalhamento_causa_str = detalhamento_causa_str.replace('Correo', 'Correção')
                        detalhamento_causa_str = detalhamento_causa_str.replace('CORREO', 'CORREÇÃO')
                        detalhamento_causa_str = detalhamento_causa_str.replace('correo', 'correção')

                        detalhamento_causa = fix_text(detalhamento_causa_str)
                        detalhamento_causa = self._corrigir_nao(detalhamento_causa)

                        # Log após fix_text para debug
                        logger.info(f"🔍 Detalhamento após fix_text: {repr(detalhamento_causa[:100])}")

                        # PROTEÇÃO: Garantir que "Correção" não seja corrompido para "Correo"
                        # Se após fix_text ainda aparecer "correo", corrigir novamente
                        detalhamento_causa = re.sub(r'\bcorreo\b', 'correção', detalhamento_causa, flags=re.IGNORECASE)

                        # PROTEÇÃO: Garantir que "impressão" não seja corrompido para "impresso"
                        detalhamento_causa = re.sub(r'\bimpresso\b', 'impressão', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('impresso', 'impressão')
                        detalhamento_causa = detalhamento_causa.replace('Impresso', 'Impressão')
                        detalhamento_causa = detalhamento_causa.replace('IMPRESSO', 'IMPRESSÃO')
                    # CORREÇÃO: Remover chamada redundante de fix_text
                    # Aplicar correções específicas para "Dvida" -> "Dúvida" e outras
                    correcoes_detalhamento = [
                        # CORREÇÃO PRIORITÁRIA: Caracteres corrompidos (D�vida / D�vidas)
                        ('D�vidas', 'Dúvidas'),
                        ('D�vida', 'Dúvida'),
                        ('d�vidas', 'dúvidas'),
                        ('d�vida', 'dúvida'),
                        ('D�VIDAS', 'DÚVIDAS'),
                        ('D�VIDA', 'DÚVIDA'),
                        # Variações com espaços e pontuação
                        ('D�vida ', 'Dúvida '),
                        ('D�vidas ', 'Dúvidas '),
                        ('D�vida.', 'Dúvida.'),
                        ('D�vidas.', 'Dúvidas.'),
                        ('D�vida,', 'Dúvida,'),
                        ('D�vidas,', 'Dúvidas,'),
                        ('D�vida/', 'Dúvida/'),
                        ('D�vidas/', 'Dúvidas/'),
                        # Variações com -
                        ('d�vida', 'dúvida'),
                        ('d�vidas', 'dúvidas'),
                        # Correções sem caracteres corrompidos
                        ('Dvida', 'Dúvida'),
                        ('Duvida', 'Dúvida'),
                        ('DVIDA', 'DÚVIDA'),
                        ('DUVIDA', 'DÚVIDA'),
                        # Correções comuns de encoding
                        ('lanou', 'lançou'),
                        ('reteno', 'retenção'),
                        ('retencao', 'retenção'),
                        ('automtico', 'automático'),
                        ('automtico.', 'automático.'),
                        ('automtico ', 'automático '),
                        ('AUTOMTICO', 'AUTOMÁTICO'),
                        ('Automtico', 'Automático'),
                        # Correção: "vrias" -> "várias"
                        ('vrias', 'várias'),
                        ('Vrias', 'Várias'),
                        ('VRIAS', 'VÁRIAS'),
                        ('vrias ', 'várias '),
                        ('vrias.', 'várias.'),
                        ('vrias,', 'várias,'),
                        ('vrias;', 'várias;'),
                        ('vrias:', 'várias:'),
                        ('vrias\n', 'várias\n'),
                        ('vrias\r', 'várias\r'),
                        # Correção: "notas" -> "notas" (garantir que não seja corrompido)
                        # Correção: "cancelar" -> "cancelar" (garantir que não seja corrompido)
                        # Outras correções comuns de encoding
                        ('configurao', 'configuração'),
                        ('Configurao', 'Configuração'),
                        ('CONFIGURAO', 'CONFIGURAÇÃO'),
                        ('atualizao', 'atualização'),
                        ('Atualizao', 'Atualização'),
                        ('ATUALIZAO', 'ATUALIZAÇÃO'),
                        ('informao', 'informação'),
                        ('Informao', 'Informação'),
                        ('INFORMAO', 'INFORMAÇÃO'),
                        ('orientao', 'orientação'),
                        ('Orientao', 'Orientação'),
                        ('ORIENTAO', 'ORIENTAÇÃO'),
                        ('instalao', 'instalação'),
                        ('Instalao', 'Instalação'),
                        ('INSTALAO', 'INSTALAÇÃO'),
                        # Correção: "conexo" -> "conexão"
                        ('conexo', 'conexão'),
                        ('Conexo', 'Conexão'),
                        ('CONEXO', 'CONEXÃO'),
                        ('conexo ', 'conexão '),
                        ('conexo.', 'conexão.'),
                        ('conexo,', 'conexão,'),
                        ('conexo;', 'conexão;'),
                        ('conexo:', 'conexão:'),
                        ('conexo\n', 'conexão\n'),
                        ('conexo\r', 'conexão\r'),
                        # Correção: "aps" -> "após"
                        (' aps ', ' após '),
                        (' aps.', ' após.'),
                        (' aps,', ' após,'),
                        (' aps;', ' após;'),
                        (' aps:', ' após:'),
                        (' aps\n', ' após\n'),
                        (' aps\r', ' após\r'),
                        ('^aps ', 'após '),  # No início da frase
                        (' aps$', ' após'),  # No final da frase
                        ('Aps ', 'Após '),
                        ('APS ', 'APÓS '),
                        # Correção: "relatrio" -> "relatório"
                        ('relatrio', 'relatório'),
                        ('Relatrio', 'Relatório'),
                        ('RELATRIO', 'RELATÓRIO'),
                        ('relatrio.', 'relatório.'),
                        ('relatrio ', 'relatório '),
                        # Correção: "movimentão" -> "movimentação"
                        ('movimentão', 'movimentação'),
                        ('Movimentão', 'Movimentação'),
                        ('MOVIMENTÃO', 'MOVIMENTAÇÃO'),
                        ('movimentão.', 'movimentação.'),
                        ('movimentão ', 'movimentação '),
                        # Correção: "usurio" -> "usuário"
                        ('usurio', 'usuário'),
                        ('Usurio', 'Usuário'),
                        ('USURIO', 'USUÁRIO'),
                        ('usurio.', 'usuário.'),
                        ('usurio ', 'usuário '),
                        ('usurios', 'usuários'),
                        ('Usurios', 'Usuários'),
                        ('USURIOS', 'USUÁRIOS'),
                        # Correção: "atribuio" -> "atribuição"
                        ('atribuio', 'atribuição'),
                        ('Atribuio', 'Atribuição'),
                        ('ATRIBUIO', 'ATRIBUIÇÃO'),
                        ('atribuio.', 'atribuição.'),
                        ('atribuio ', 'atribuição '),
                        # Correção: "endereamento" -> "endereçamento"
                        ('endereamento', 'endereçamento'),
                        ('Endereamento', 'Endereçamento'),
                        ('ENDEREAMENTO', 'ENDEREÇAMENTO'),
                        ('endereamento.', 'endereçamento.'),
                        ('endereamento ', 'endereçamento '),
                        # Correção: "correo" -> "correção" (PRIORITÁRIA - aplicar primeiro)
                        # Todas as variações possíveis para garantir correção completa
                        ('correo de', 'correção de'),
                        ('Correo de', 'Correção de'),
                        ('CORREO DE', 'CORREÇÃO DE'),
                        ('correo de erro', 'correção de erro'),
                        ('Correo de Erro', 'Correção de Erro'),
                        ('CORREO DE ERRO', 'CORREÇÃO DE ERRO'),
                        ('correo.', 'correção.'),
                        ('Correo.', 'Correção.'),
                        ('CORREO.', 'CORREÇÃO.'),
                        ('correo ', 'correção '),
                        ('Correo ', 'Correção '),
                        ('CORREO ', 'CORREÇÃO '),
                        ('correo', 'correção'),
                        ('Correo', 'Correção'),
                        ('CORREO', 'CORREÇÃO'),
                        # Correção: "mquina" -> "máquina"
                        ('mquina', 'máquina'),
                        ('Mquina', 'Máquina'),
                        ('MQINA', 'MÁQUINA'),
                        ('mquina.', 'máquina.'),
                        ('mquina ', 'máquina '),
                        ('mquina do', 'máquina do'),
                        ('mquina da', 'máquina da'),
                        ('mquina de', 'máquina de'),
                        ('Mquina do', 'Máquina do'),
                        ('Mquina da', 'Máquina da'),
                        ('Mquina de', 'Máquina de'),
                        ('saa','são'),
                        ('tambm','também'),
                        # CORREÇÃO: "rejeies" -> "rejeições" (todas as variações)
                        ('rejeies', 'rejeições'),
                        ('Rejeies', 'Rejeições'),
                        ('REJEIES', 'REJEIÇÕES'),
                        ('rejeio', 'rejeição'),
                        ('Rejeio', 'Rejeição'),
                        ('REJEIO', 'REJEIÇÃO'),
                        # CORREÇÃO: "numero" -> "número"
                        ('numero', 'número'),
                        ('Numero', 'Número'),
                        ('NUMERO', 'NÚMERO'),
                        ('numero ', 'número '),
                        ('numero.', 'número.'),
                        ('numero,', 'número,'),
                        ('numero:', 'número:'),
                        ('numero;', 'número;'),
                        # CORREÇÃO: "diferenaa" -> "diferença" (falta ç e acento)
                        ('diferenaa', 'diferença'),
                        ('Diferenaa', 'Diferença'),
                        ('DIFERENAA', 'DIFERENÇA'),
                        ('diferenaa ', 'diferença '),
                        ('diferenaa.', 'diferença.'),
                        ('diferenaa,', 'diferença,'),
                        # CORREÇÃO: "calculo" -> "cálculo" (falta acento)
                        ('calculo', 'cálculo'),
                        ('Calculo', 'Cálculo'),
                        ('CALCULO', 'CÁLCULO'),
                        ('calculo ', 'cálculo '),
                        ('calculo.', 'cálculo.'),
                        ('calculo,', 'cálculo,'),
                        ('calculo do', 'cálculo do'),
                        ('calculo da', 'cálculo da'),
                        ('calculo de', 'cálculo de'),
                        # CORREÇÃO: "permisses" -> "permissões" (falta til no o)
                        ('permisses', 'permissões'),
                        ('Permisses', 'Permissões'),
                        ('PERMISSES', 'PERMISSÕES'),
                        ('permisses ', 'permissões '),
                        ('permisses.', 'permissões.'),
                        ('permisses,', 'permissões,'),
                        # CORREÇÃO: "Destinatrio" -> "Destinatário" (falta acento no a)
                        ('Destinatrio', 'Destinatário'),
                        ('destinatrio', 'destinatário'),
                        ('DESTINATRIO', 'DESTINATÁRIO'),
                        ('Destinatrio ', 'Destinatário '),
                        ('Destinatrio.', 'Destinatário.'),
                        ('Destinatrio,', 'Destinatário,'),
                        # CORREÇÃO: "impressãora" -> "impressora" (tem ã onde deveria ser o)
                        ('impressãora', 'impressora'),
                        ('Impressãora', 'Impressora'),
                        ('IMPRESSÃORA', 'IMPRESSORA'),
                        ('impressãora ', 'impressora '),
                        ('impressãora.', 'impressora.'),
                        ('impressãora,', 'impressora,'),
                        # CORREÇÃO: "executvel" -> "executável" (falta acento)
                        ('executvel', 'executável'),
                        ('Executvel', 'Executável'),
                        ('EXECUTVEL', 'EXECUTÁVEL'),
                        ('executvel ', 'executável '),
                        ('executvel.', 'executável.'),
                        ('executvel,', 'executável,'),
                        # CORREÇÃO: "verso" -> "versão" (falta til)
                        ('verso', 'versão'),
                        ('Verso', 'Versão'),
                        ('VERSO', 'VERSÃO'),
                        ('verso ', 'versão '),
                        ('verso.', 'versão.'),
                        ('verso,', 'versão,'),
                        ('verso do', 'versão do'),
                        ('verso da', 'versão da'),
                        ('verso de', 'versão de'),
                        ('nova verso', 'nova versão'),
                        ('Nova Verso', 'Nova Versão'),
                        # CORREÇÃO: "manuteno" -> "manutenção" (falta til)
                        ('manuteno', 'manutenção'),
                        ('Manuteno', 'Manutenção'),
                        ('MANUTENO', 'MANUTENÇÃO'),
                        ('manuteno ', 'manutenção '),
                        ('manuteno.', 'manutenção.'),
                        ('manuteno,', 'manutenção,'),
                        # CORREÇÃO: "servio" -> "serviço" (falta ç)
                        ('servio', 'serviço'),
                        ('Servio', 'Serviço'),
                        ('SERVIO', 'SERVIÇO'),
                        ('servio ', 'serviço '),
                        ('servio.', 'serviço.'),
                        ('servio,', 'serviço,'),
                        ('servio de', 'serviço de'),
                        ('servio do', 'serviço do'),
                        ('servio da', 'serviço da'),
                        # CORREÇÃO: "somatrio" -> "somatório" (falta til)
                        ('somatrio', 'somatório'),
                        ('Somatrio', 'Somatório'),
                        ('SOMATRIO', 'SOMATÓRIO'),
                        ('somatrio ', 'somatório '),
                        ('somatrio.', 'somatório.'),
                        ('somatrio,', 'somatório,'),
                        # CORREÇÃO: "Oscilão" -> "Oscilação" (falta ç)
                        ('Oscilão', 'Oscilação'),
                        ('oscilão', 'oscilação'),
                        ('OSCILÃO', 'OSCILAÇÃO'),
                        ('Oscilão ', 'Oscilação '),
                        ('Oscilão.', 'Oscilação.'),
                        ('Oscilão,', 'Oscilação,'),
                        # CORREÇÃO: "seleo" -> "seleção" (falta ç e ã)
                        ('seleo', 'seleção'),
                        ('Seleo', 'Seleção'),
                        ('SELEO', 'SELEÇÃO'),
                        ('seleo ', 'seleção '),
                        ('seleo.', 'seleção.'),
                        ('seleo,', 'seleção,'),
                        ('seleo de', 'seleção de'),
                        ('seleo de IPs', 'seleção de IPs'),
                        ('durante a seleo', 'durante a seleção'),
                        ('durante a seleo de', 'durante a seleção de'),
                        # CORREÇÃO: "s mprimia" -> "imprimia" (falta "i" no início)
                        ('s mprimia', 'imprimia'),
                        ('s mprimia ', 'imprimia '),
                        ('s mprimia.', 'imprimia.'),
                        ('s mprimia,', 'imprimia,'),
                        ('s mprimia quando', 'imprimia quando'),
                        ('s mprimia sem', 'imprimia sem'),
                        # CORREÇÃO: "Orientaes" -> "Orientações"
                        ('Orientaes', 'Orientações'),
                        ('orientaes', 'orientações'),
                        ('ORIENTAES', 'ORIENTAÇÕES'),
                        ('Orientaes ', 'Orientações '),
                        ('Orientaes.', 'Orientações.'),
                        ('Orientaes,', 'Orientações,'),
                        # CORREÇÃO: "Auxlio" -> "Auxílio"
                        ('Auxlio', 'Auxílio'),
                        ('auxlio', 'auxílio'),
                        ('AUXLIO', 'AUXÍLIO'),
                        ('Auxlio ', 'Auxílio '),
                        ('Auxlio.', 'Auxílio.'),
                        ('Auxlio,', 'Auxílio,'),
                        # CORREÇÃO: "Auxilio" -> "Auxílio" (caso já tenha o "i")
                        ('Auxilio', 'Auxílio'),
                        ('auxilio', 'auxílio'),
                        ('AUXILIO', 'AUXÍLIO'),
                        ('Auxilio ', 'Auxílio '),
                        ('Auxilio.', 'Auxílio.'),
                        ('Auxilio,', 'Auxílio,'),
                        # CORREÇÃO: "Licena" -> "Licença"
                        ('Licena', 'Licença'),
                        ('licena', 'licença'),
                        ('LICENA', 'LICENÇA'),
                        ('Licena ', 'Licença '),
                        ('Licena.', 'Licença.'),
                        ('Licena,', 'Licença,'),
                        # CORREÇÃO: "Liena" -> "Licença"
                        ('Liena', 'Licença'),
                        ('liena', 'licença'),
                        ('LIENA', 'LICENÇA'),
                        ('Liena ', 'Licença '),
                        ('Liena.', 'Licença.'),
                        ('Liena,', 'Licença,'),
                        # CORREÇÃO: "Liberão" -> "Liberação"
                        ('Liberão', 'Liberação'),
                        ('liberão', 'liberação'),
                        ('LIBERÃO', 'LIBERAÇÃO'),
                        ('Liberão ', 'Liberação '),
                        ('Liberão.', 'Liberação.'),
                        ('Liberão,', 'Liberação,'),
                        # CORREÇÃO: "Tributão" -> "Tributação"
                        ('Tributão', 'Tributação'),
                        ('tributão', 'tributação'),
                        ('TRIBUTÃO', 'TRIBUTAÇÃO'),
                        ('Tributão ', 'Tributação '),
                        ('Tributão.', 'Tributação.'),
                        ('Tributão,', 'Tributação,'),
                        # CORREÇÃO: "Exportão" -> "Exportação"
                        ('Exportão', 'Exportação'),
                        ('exportão', 'exportação'),
                        ('EXPORTÃO', 'EXPORTAÇÃO'),
                        ('Exportão ', 'Exportação '),
                        ('Exportão.', 'Exportação.'),
                        ('Exportão,', 'Exportação,'),
                        # CORREÇÃO: "Exporto" -> "Exportação"
                        ('Exporto', 'Exportação'),
                        ('exporto', 'exportação'),
                        ('EXPORTO', 'EXPORTAÇÃO'),
                        ('Exporto ', 'Exportação '),
                        ('Exporto.', 'Exportação.'),
                        ('Exporto,', 'Exportação,'),
                        # CORREÇÃO: "ms" -> "mês"
                        (' ms ', ' mês '),
                        (' ms.', ' mês.'),
                        (' ms,', ' mês,'),
                        (' ms\n', ' mês\n'),
                        (' ms\r', ' mês\r'),
                        # CORREÇÃO: "prximo" -> "próximo"
                        ('prximo', 'próximo'),
                        ('Prximo', 'Próximo'),
                        ('PRXIMO', 'PRÓXIMO'),
                        ('prximo ', 'próximo '),
                        ('prximo.', 'próximo.'),
                        ('prximo,', 'próximo,'),
                        # CORREÇÃO: "Conferncia" -> "Conferência"
                        ('Conferncia', 'Conferência'),
                        ('conferncia', 'conferência'),
                        ('CONFERNCA', 'CONFERÊNCIA'),
                        ('Conferncia ', 'Conferência '),
                        ('Conferncia.', 'Conferência.'),
                        ('Conferncia,', 'Conferência,'),
                        # CORREÇÃO: "Pr-Venda" -> "Pré-Venda"
                        ('Pr-Venda', 'Pré-Venda'),
                        ('pr-venda', 'pré-venda'),
                        ('PR-VENDA', 'PRÉ-VENDA'),
                        ('Pr-Venda ', 'Pré-Venda '),
                        ('Pr-Venda.', 'Pré-Venda.'),
                        ('Pr-Venda,', 'Pré-Venda,'),
                        # CORREÇÃO: "Configuraes" -> "Configurações"
                        ('Configuraes', 'Configurações'),
                        ('configuraes', 'configurações'),
                        ('CONFIGURAES', 'CONFIGURAÇÕES'),
                        ('Configuraes ', 'Configurações '),
                        ('Configuraes.', 'Configurações.'),
                        ('Configuraes,', 'Configurações,'),
                        # CORREÇÃO: "Movimentaes" -> "Movimentações"
                        ('Movimentaes', 'Movimentações'),
                        ('movimentaes', 'movimentações'),
                        ('MOVIMENTAES', 'MOVIMENTAÇÕES'),
                        ('Movimentaes ', 'Movimentações '),
                        ('Movimentaes.', 'Movimentações.'),
                        ('Movimentaes,', 'Movimentações,'),
                        # CORREÇÃO: "Parmetros" -> "Parâmetros"
                        ('Parmetros', 'Parâmetros'),
                        ('parmetros', 'parâmetros'),
                        ('PARMETROS', 'PARÂMETROS'),
                        ('Parmetros ', 'Parâmetros '),
                        ('Parmetros.', 'Parâmetros.'),
                        ('Parmetros,', 'Parâmetros,'),
                    ]
                    for errado, correto in correcoes_detalhamento:
                        detalhamento_causa = detalhamento_causa.replace(errado, correto)

                    # Correção adicional: capturar variações corrompidas de "tributação"
                    try:
                        # Preservar capitalização ao corrigir
                        def corrigir_tributacao_match(match):
                            palavra = match.group(0)
                            if palavra.isupper():
                                return 'TRIBUTAÇÃO'
                            elif palavra[0].isupper():
                                return 'Tributação'
                            return 'tributação'

                        detalhamento_causa = re.sub(r'\btributa[ãa]o\b', corrigir_tributacao_match, detalhamento_causa, flags=re.IGNORECASE)
                    except Exception:
                        # Não bloquear processamento se a substituição falhar
                        logger.debug('Falha ao aplicar correção adicional para "tributação"', exc_info=True)

                    # CORREÇÃO PRIORITÁRIA: "Dvida" -> "Dúvida" ANTES de outras correções
                    detalhamento_causa = detalhamento_causa.replace('DVIDA', 'DÚVIDA').replace('DUVIDA', 'DÚVIDA')
                    detalhamento_causa = detalhamento_causa.replace('Dvida', 'Dúvida').replace('Duvida', 'Dúvida')
                    detalhamento_causa = detalhamento_causa.replace('dvida', 'dúvida').replace('duvida', 'dúvida')
                    detalhamento_causa = detalhamento_causa.replace('Dvida/', 'Dúvida/').replace('Dvida ', 'Dúvida ')
                    detalhamento_causa = detalhamento_causa.replace('Duvida/', 'Dúvida/').replace('Duvida ', 'Dúvida ')
                    # CORREÇÃO: "Parmetros" -> "Parâmetros"
                    detalhamento_causa = re.sub(r'\bParmetros\b', 'Parâmetros', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Parmetros', 'Parâmetros')
                    detalhamento_causa = detalhamento_causa.replace('parmetros', 'parâmetros')
                    detalhamento_causa = detalhamento_causa.replace('PARMETROS', 'PARÂMETROS')

                    # Correções adicionais com regex para garantir captura completa
                    detalhamento_causa = re.sub(r'\brejeies\b', 'rejeições', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\brejeio\b', 'rejeição', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bnumero\b', 'número', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bdiferenaa\b', 'diferença', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bcalculo\b', 'cálculo', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bpermisses\b', 'permissões', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bdestinatrio\b', 'destinatário', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bimpressãora\b', 'impressora', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bexecutvel\b', 'executável', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bverso\b', 'versão', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bOscilão\b', 'Oscilação', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bseleo\b', 'seleção', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bs\s+mprimia\b', 'imprimia', detalhamento_causa, flags=re.IGNORECASE)
                    # NOVAS CORREÇÕES
                    detalhamento_causa = re.sub(r'\bmanuteno\b', 'manutenção', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bservio\b', 'serviço', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bsomatrio\b', 'somatório', detalhamento_causa, flags=re.IGNORECASE)
                    # CORREÇÃO: "Orientaes" -> "Orientações"
                    detalhamento_causa = re.sub(r'\bOrientaes\b', 'Orientações', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Orientaes', 'Orientações')
                    detalhamento_causa = detalhamento_causa.replace('orientaes', 'orientações')
                    detalhamento_causa = detalhamento_causa.replace('ORIENTAES', 'ORIENTAÇÕES')
                    # CORREÇÃO: "Auxlio" -> "Auxílio"
                    detalhamento_causa = re.sub(r'\bAuxlio\b', 'Auxílio', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Auxlio', 'Auxílio')
                    detalhamento_causa = detalhamento_causa.replace('auxlio', 'auxílio')
                    detalhamento_causa = detalhamento_causa.replace('AUXLIO', 'AUXÍLIO')
                    # CORREÇÃO: "Auxilio" -> "Auxílio" (caso já tenha o "i")
                    detalhamento_causa = re.sub(r'\bAuxilio\b', 'Auxílio', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Auxilio', 'Auxílio')
                    detalhamento_causa = detalhamento_causa.replace('auxilio', 'auxílio')
                    detalhamento_causa = detalhamento_causa.replace('AUXILIO', 'AUXÍLIO')
                    # CORREÇÃO: "Licena" -> "Licença"
                    detalhamento_causa = re.sub(r'\bLicena\b', 'Licença', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Licena', 'Licença')
                    detalhamento_causa = detalhamento_causa.replace('licena', 'licença')
                    detalhamento_causa = detalhamento_causa.replace('LICENA', 'LICENÇA')
                    # CORREÇÃO: "Liena" -> "Licença"
                    detalhamento_causa = re.sub(r'\bLiena\b', 'Licença', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Liena', 'Licença')
                    detalhamento_causa = detalhamento_causa.replace('liena', 'licença')
                    detalhamento_causa = detalhamento_causa.replace('LIENA', 'LICENÇA')
                    # CORREÇÃO: "Liberão" -> "Liberação"
                    detalhamento_causa = re.sub(r'\bLiberão\b', 'Liberação', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Liberão', 'Liberação')
                    detalhamento_causa = detalhamento_causa.replace('liberão', 'liberação')
                    detalhamento_causa = detalhamento_causa.replace('LIBERÃO', 'LIBERAÇÃO')
                    # CORREÇÃO: "Tributão" -> "Tributação"
                    detalhamento_causa = re.sub(r'\bTributão\b', 'Tributação', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Tributão', 'Tributação')
                    detalhamento_causa = detalhamento_causa.replace('tributão', 'tributação')
                    detalhamento_causa = detalhamento_causa.replace('TRIBUTÃO', 'TRIBUTAÇÃO')
                    # CORREÇÃO: "Exportão" -> "Exportação"
                    detalhamento_causa = re.sub(r'\bExportão\b', 'Exportação', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Exportão', 'Exportação')
                    detalhamento_causa = detalhamento_causa.replace('exportão', 'exportação')
                    detalhamento_causa = detalhamento_causa.replace('EXPORTÃO', 'EXPORTAÇÃO')
                    # CORREÇÃO: "Exporto" -> "Exportação"
                    detalhamento_causa = re.sub(r'\bExporto\b', 'Exportação', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Exporto', 'Exportação')
                    detalhamento_causa = detalhamento_causa.replace('exporto', 'exportação')
                    detalhamento_causa = detalhamento_causa.replace('EXPORTO', 'EXPORTAÇÃO')
                    # CORREÇÃO: "ms" -> "mês" (quando isolado, não dentro de outras palavras)
                    detalhamento_causa = re.sub(r'\bms\b', 'mês', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace(' ms ', ' mês ').replace(' ms.', ' mês.').replace(' ms,', ' mês,')
                    detalhamento_causa = detalhamento_causa.replace(' ms\n', ' mês\n').replace(' ms\r', ' mês\r')
                    # Corrigir no início/fim da string
                    if detalhamento_causa.startswith('ms '):
                        detalhamento_causa = 'mês ' + detalhamento_causa[3:]
                    if detalhamento_causa.endswith(' ms'):
                        detalhamento_causa = detalhamento_causa[:-3] + ' mês'
                    # CORREÇÃO: "prximo" -> "próximo"
                    detalhamento_causa = re.sub(r'\bprximo\b', 'próximo', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('prximo', 'próximo')
                    detalhamento_causa = detalhamento_causa.replace('Prximo', 'Próximo')
                    detalhamento_causa = detalhamento_causa.replace('PRXIMO', 'PRÓXIMO')
                    # CORREÇÃO: "Conferncia" -> "Conferência"
                    detalhamento_causa = re.sub(r'\bConferncia\b', 'Conferência', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Conferncia', 'Conferência')
                    detalhamento_causa = detalhamento_causa.replace('conferncia', 'conferência')
                    detalhamento_causa = detalhamento_causa.replace('CONFERNCA', 'CONFERÊNCIA')
                    # CORREÇÃO: "Pr-Venda" -> "Pré-Venda"
                    detalhamento_causa = re.sub(r'\bPr-Venda\b', 'Pré-Venda', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Pr-Venda', 'Pré-Venda')
                    detalhamento_causa = detalhamento_causa.replace('pr-venda', 'pré-venda')
                    detalhamento_causa = detalhamento_causa.replace('PR-VENDA', 'PRÉ-VENDA')
                    # CORREÇÃO: "Configuraes" -> "Configurações"
                    detalhamento_causa = re.sub(r'\bConfiguraes\b', 'Configurações', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Configuraes', 'Configurações')
                    detalhamento_causa = detalhamento_causa.replace('configuraes', 'configurações')
                    detalhamento_causa = detalhamento_causa.replace('CONFIGURAES', 'CONFIGURAÇÕES')
                    # CORREÇÃO: "Movimentaes" -> "Movimentações"
                    detalhamento_causa = re.sub(r'\bMovimentaes\b', 'Movimentações', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = detalhamento_causa.replace('Movimentaes', 'Movimentações')
                    detalhamento_causa = detalhamento_causa.replace('movimentaes', 'movimentações')
                    detalhamento_causa = detalhamento_causa.replace('MOVIMENTAES', 'MOVIMENTAÇÕES')

                    # Correções genéricas adicionais para padrões comuns
                    # Padrão: palavras terminadas em "ao" que deveriam ser "ação" (mas não todas)
                    detalhamento_causa = re.sub(r'\b(operac)ao\b', r'\1ão', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\b(instalac)ao\b', r'\1ão', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\b(configurac)ao\b', r'\1ão', detalhamento_causa, flags=re.IGNORECASE)

                    # Padrão: palavras com "ã" onde deveria ser "a" (casos específicos)
                    detalhamento_causa = re.sub(r'\bimpressãora\b', 'impressora', detalhamento_causa, flags=re.IGNORECASE)

                    # Padrão: palavras terminadas em "vel" que deveriam ser "ável"
                    detalhamento_causa = re.sub(r'\b(execut)vel\b', r'\1ável', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\b(poss)vel\b', r'\1ível', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\b(imposs)vel\b', r'\1ível', detalhamento_causa, flags=re.IGNORECASE)

                    # Padrão: palavras terminadas em "rio" que deveriam ser "ário"
                    detalhamento_causa = re.sub(r'\b(destinat)rio\b', r'\1ário', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\b(necess)rio\b', r'\1ário', detalhamento_causa, flags=re.IGNORECASE)

                    # Padrão: palavras terminadas em "es" que deveriam ser "ões" (mas não todas)
                    detalhamento_causa = re.sub(r'\b(permiss)es\b', r'\1ões', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\b(fun)es\b', r'\1ções', detalhamento_causa, flags=re.IGNORECASE)

                    # Padrão: palavras terminadas em "ao" que deveriam ser "ão" (mas não todas)
                    detalhamento_causa = re.sub(r'\b(vers)ao\b', r'\1ão', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\b(oscila)ao\b', r'\1ção', detalhamento_causa, flags=re.IGNORECASE)

                    # CORREÇÃO CONTEXTUAL: "s" -> "só" apenas em contextos específicos
                    # Substituir "uma s vez" -> "uma só vez", mas não substituir "s" em outros contextos
                    detalhamento_causa = re.sub(r'\buma\s+s\s+vez\b', 'uma só vez', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\buma\s+s\s+nota\b', 'uma só nota', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\buma\s+s\s+coisa\b', 'uma só coisa', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\buma\s+s\s+op[çc][ãa]o\b', 'uma só opção', detalhamento_causa, flags=re.IGNORECASE)
                    # Padrão mais genérico: "uma s [palavra]" -> "uma só [palavra]"
                    detalhamento_causa = re.sub(r'\buma\s+s\s+([a-záéíóúàêô]+)\b', r'uma só \1', detalhamento_causa, flags=re.IGNORECASE)

                    # CORREÇÃO: "s" isolado entre palavras -> "só" (contextos específicos)
                    # Exemplos: "mas s quando" -> "mas só quando", "mas s no" -> "mas só no"
                    detalhamento_causa = re.sub(r'\bmas\s+s\s+(quando|no|na|se|que|por|para|com|sem|isso|exemplo)\b', r'mas só \1', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\bpor\s+s\s+(isso|exemplo|conta)\b', r'por só \1', detalhamento_causa, flags=re.IGNORECASE)

                    # CORREÇÃO: "s" seguido de palavra específica -> "só"
                    palavras_apos_s = ['quando', 'se', 'que', 'por', 'para', 'com', 'sem', 'isso', 'exemplo', 'no', 'na']
                    for palavra_apos in palavras_apos_s:
                        detalhamento_causa = re.sub(rf'\bs\s+{palavra_apos}\b', f'só {palavra_apos}', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "vrias" -> "várias" (mais abrangente)
                    detalhamento_causa = re.sub(r'\bvrias\b', 'várias', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "conexo" -> "conexão" (mais abrangente)
                    detalhamento_causa = re.sub(r'\bconexo\b', 'conexão', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "mquina" -> "máquina" (mais abrangente)
                    detalhamento_causa = re.sub(r'\bmquina\b', 'máquina', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "aps" -> "após" (mais abrangente)
                    detalhamento_causa = re.sub(r'\baps\b', 'após', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "relatrio" -> "relatório" (mais abrangente)
                    detalhamento_causa = re.sub(r'\brelatrio\b', 'relatório', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "movimentão" -> "movimentação" (mais abrangente)
                    detalhamento_causa = re.sub(r'\bmovimentão\b', 'movimentação', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "usurio" -> "usuário" (mais abrangente)
                    detalhamento_causa = re.sub(r'\busurio\b', 'usuário', detalhamento_causa, flags=re.IGNORECASE)
                    detalhamento_causa = re.sub(r'\busurios\b', 'usuários', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "atribuio" -> "atribuição" (mais abrangente)
                    detalhamento_causa = re.sub(r'\batribuio\b', 'atribuição', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "endereamento" -> "endereçamento" (mais abrangente)
                    detalhamento_causa = re.sub(r'\bendereamento\b', 'endereçamento', detalhamento_causa, flags=re.IGNORECASE)

                    # Correção adicional com regex para "correo" -> "correção" (mais abrangente)
                    # Preservar capitalização: "Correo" -> "Correção", "CORREO" -> "CORREÇÃO", "correo" -> "correção"
                    def corrigir_correo(match):
                        palavra = match.group(0)
                        if palavra.isupper():
                            return 'CORREÇÃO'
                        elif palavra[0].isupper():
                            return 'Correção'
                        else:
                            return 'correção'

                    detalhamento_causa = re.sub(r'\bcorreo\b', corrigir_correo, detalhamento_causa, flags=re.IGNORECASE)

                    # CORREÇÃO CONTEXTUAL: "Estão" -> "Estação" apenas quando faz sentido
                    detalhamento_causa = self._corrigir_estao_para_estacao(detalhamento_causa)

                    # Correção genérica: palavras que terminam com "tico" -> "ático"
                    # Exemplos: automtico -> automático, sistemtico -> sistemático
                    detalhamento_causa = re.sub(r'\b([a-záéíóúàêô]+)tico\b', r'\1ático', detalhamento_causa, flags=re.IGNORECASE)
                    # Também corrigir com pontuação no final
                    detalhamento_causa = re.sub(r'\b([a-záéíóúàêô]+)tico([.,;:!?])', r'\1ático\2', detalhamento_causa, flags=re.IGNORECASE)

                    # PROTEÇÃO FINAL: Garantir que palavras com "ão" não sejam corrompidas
                    # Lista de palavras que devem terminar em "ão" e não "o"
                    palavras_com_ao = {
                        'impresso': 'impressão',
                        'Impresso': 'Impressão',
                        'IMPRESSO': 'IMPRESSÃO',
                        'configurao': 'configuração',
                        'Configurao': 'Configuração',
                        'CONFIGURAO': 'CONFIGURAÇÃO',
                        'atualizao': 'atualização',
                        'Atualizao': 'Atualização',
                        'ATUALIZAO': 'ATUALIZAÇÃO',
                        'saa': 'são',
                        'alterão': 'alteração',
                    }
                    for errado, correto in palavras_com_ao.items():
                        detalhamento_causa = detalhamento_causa.replace(errado, correto)

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Licena" -> "Licença" (caso tenha passado despercebido)
                    if 'Licena' in detalhamento_causa or 'LICENA' in detalhamento_causa or 'licena' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bLicena\b', 'Licença', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Licena', 'Licença').replace('LICENA', 'LICENÇA').replace('licena', 'licença')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Liena" -> "Licença" (caso tenha passado despercebido)
                    if 'Liena' in detalhamento_causa or 'LIENA' in detalhamento_causa or 'liena' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bLiena\b', 'Licença', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Liena', 'Licença').replace('LIENA', 'LICENÇA').replace('liena', 'licença')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Liberão" -> "Liberação" (caso tenha passado despercebido)
                    if 'Liberão' in detalhamento_causa or 'LIBERÃO' in detalhamento_causa or 'liberão' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bLiberão\b', 'Liberação', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Liberão', 'Liberação').replace('LIBERÃO', 'LIBERAÇÃO').replace('liberão', 'liberação')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Tributão" -> "Tributação" (caso tenha passado despercebido)
                    if 'Tributão' in detalhamento_causa or 'TRIBUTÃO' in detalhamento_causa or 'tributão' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bTributão\b', 'Tributação', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Tributão', 'Tributação').replace('TRIBUTÃO', 'TRIBUTAÇÃO').replace('tributão', 'tributação')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Exportão" -> "Exportação" (caso tenha passado despercebido)
                    if 'Exportão' in detalhamento_causa or 'EXPORTÃO' in detalhamento_causa or 'exportão' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bExportão\b', 'Exportação', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Exportão', 'Exportação').replace('EXPORTÃO', 'EXPORTAÇÃO').replace('exportão', 'exportação')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Exporto" -> "Exportação" (caso tenha passado despercebido)
                    if 'Exporto' in detalhamento_causa or 'EXPORTO' in detalhamento_causa or 'exporto' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bExporto\b', 'Exportação', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Exporto', 'Exportação').replace('EXPORTO', 'EXPORTAÇÃO').replace('exporto', 'exportação')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "ms" -> "mês" (caso tenha passado despercebido)
                    if ' ms ' in detalhamento_causa or ' ms.' in detalhamento_causa or ' ms,' in detalhamento_causa or detalhamento_causa.startswith('ms ') or detalhamento_causa.endswith(' ms'):
                        detalhamento_causa = re.sub(r'\bms\b', 'mês', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace(' ms ', ' mês ').replace(' ms.', ' mês.').replace(' ms,', ' mês,')
                        if detalhamento_causa.startswith('ms '):
                            detalhamento_causa = 'mês ' + detalhamento_causa[3:]
                        if detalhamento_causa.endswith(' ms'):
                            detalhamento_causa = detalhamento_causa[:-3] + ' mês'

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Rejeies" -> "Rejeições" (caso tenha passado despercebido)
                    if 'Rejeies' in detalhamento_causa or 'REJEIES' in detalhamento_causa or 'rejeies' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bRejeies\b', 'Rejeições', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Rejeies', 'Rejeições').replace('REJEIES', 'REJEIÇÕES').replace('rejeies', 'rejeições')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "prximo" -> "próximo" (caso tenha passado despercebido)
                    if 'prximo' in detalhamento_causa or 'PRXIMO' in detalhamento_causa or 'Prximo' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bprximo\b', 'próximo', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('prximo', 'próximo').replace('PRXIMO', 'PRÓXIMO').replace('Prximo', 'Próximo')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Conferncia" -> "Conferência" (caso tenha passado despercebido)
                    if 'Conferncia' in detalhamento_causa or 'CONFERNCA' in detalhamento_causa or 'conferncia' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bConferncia\b', 'Conferência', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Conferncia', 'Conferência').replace('CONFERNCA', 'CONFERÊNCIA').replace('conferncia', 'conferência')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Pr-Venda" -> "Pré-Venda" (caso tenha passado despercebido)
                    if 'Pr-Venda' in detalhamento_causa or 'PR-VENDA' in detalhamento_causa or 'pr-venda' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bPr-Venda\b', 'Pré-Venda', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Pr-Venda', 'Pré-Venda').replace('PR-VENDA', 'PRÉ-VENDA').replace('pr-venda', 'pré-venda')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Configuraes" -> "Configurações" (caso tenha passado despercebido)
                    if 'Configuraes' in detalhamento_causa or 'CONFIGURAES' in detalhamento_causa or 'configuraes' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bConfiguraes\b', 'Configurações', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Configuraes', 'Configurações').replace('CONFIGURAES', 'CONFIGURAÇÕES').replace('configuraes', 'configurações')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Movimentaes" -> "Movimentações" (caso tenha passado despercebido)
                    if 'Movimentaes' in detalhamento_causa or 'MOVIMENTAES' in detalhamento_causa or 'movimentaes' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bMovimentaes\b', 'Movimentações', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Movimentaes', 'Movimentações').replace('MOVIMENTAES', 'MOVIMENTAÇÕES').replace('movimentaes', 'movimentações')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Dvida" -> "Dúvida" (caso tenha passado despercebido)
                    if 'Dvida' in detalhamento_causa or 'DVIDA' in detalhamento_causa or 'dvida' in detalhamento_causa or 'Duvida' in detalhamento_causa or 'DUVIDA' in detalhamento_causa or 'duvida' in detalhamento_causa:
                        detalhamento_causa = detalhamento_causa.replace('DVIDA', 'DÚVIDA').replace('DUVIDA', 'DÚVIDA')
                        detalhamento_causa = detalhamento_causa.replace('Dvida', 'Dúvida').replace('Duvida', 'Dúvida')
                        detalhamento_causa = detalhamento_causa.replace('dvida', 'dúvida').replace('duvida', 'dúvida')
                        detalhamento_causa = detalhamento_causa.replace('Dvida/', 'Dúvida/').replace('Dvida ', 'Dúvida ')
                        detalhamento_causa = detalhamento_causa.replace('Duvida/', 'Dúvida/').replace('Duvida ', 'Dúvida ')

                    # VERIFICAÇÃO FINAL OBRIGATÓRIA: "Parmetros" -> "Parâmetros" (caso tenha passado despercebido)
                    if 'Parmetros' in detalhamento_causa or 'PARMETROS' in detalhamento_causa or 'parmetros' in detalhamento_causa:
                        detalhamento_causa = re.sub(r'\bParmetros\b', 'Parâmetros', detalhamento_causa, flags=re.IGNORECASE)
                        detalhamento_causa = detalhamento_causa.replace('Parmetros', 'Parâmetros').replace('PARMETROS', 'PARÂMETROS').replace('parmetros', 'parâmetros')

                    # Log final para debug
                    logger.info(f"🔍 Detalhamento final antes de adicionar ao embed: {repr(detalhamento_causa[:100])}")

                    # Remover espaços em branco extras
                    detalhamento_causa = detalhamento_causa.strip()
                    if not detalhamento_causa or detalhamento_causa == 'None':
                        detalhamento_causa = None

                # Enviar notificação APENAS para cancelados e resolvidos
                is_resolvido = any(x in status_low for x in
                                   ['resolvido', 'finalizado', 'encerrado', 'conclu'])
                is_cancelado = any(x in status_low
                                   for x in ['cancelado', 'rejeitado', 'fechado'])

                # Se NÃO for resolvido nem cancelado, ignorar
                if not (is_resolvido or is_cancelado):
                    logger.info(
                        f"⏭️ Webhook ignorado - Status: {status} (apenas cancelados/resolvidos são notificados)"
                    )
                    return web.Response(text="Ignorado (apenas cancelados/resolvidos)", status=200)

                ticket_visual = get_protocolo(data)

                logger.info(f"Webhook data keys: {list(data.keys())}")
                logger.info(
                    f"✅ Processado - Operador: {operador_final}, Status: {status}"
                )

                emoji, cor = "✅", discord.Color.green()
                if is_resolvido:
                    emoji, cor = "✅", discord.Color.green()
                elif is_cancelado:
                    emoji, cor = "❌", discord.Color.red()

                # Garantir que o assunto está completamente corrigido
                assunto_final = raw_assunto

                # Aplicar correções específicas adicionais (ordem importa!)
                # Nota: fix_text já trata a maioria desses casos, mas mantemos para casos específicos
                correcoes_especificas = [
                    # Padrões duplos primeiro (mais específicos)
                    ('InteraÃ§Ã£o', 'Interação'),
                    ('InteraÃ§ao', 'Interação'),
                    ('ConfiguraÃ§Ã£o', 'Configuração'),
                    ('ConfiguraÃ§ao', 'Configuração'),
                    ('AtualizaÃ§Ã£o', 'Atualização'),
                    ('AtualizaÃ§ao', 'Atualização'),
                    ('InformaÃ§Ã£o', 'Informação'),
                    ('InformaÃ§ao', 'Informação'),
                    ('OrientaÃ§Ã£o', 'Orientação'),
                    ('OrientaÃ§ao', 'Orientação'),
                    ('InstalaÃ§Ã£o', 'Instalação'),
                    ('InstalaÃ§ao', 'Instalação'),
                    ('EmissaÃ§Ã£o', 'Emissão'),
                    ('EmissaÃ§ao', 'Emissão'),
                    ('ConexÃ£o', 'Conexão'),
                    ('DÃºvida', 'Dúvida'),
                    # Depois padrões simples
                    ('Interacao', 'Interação'),  # IMPORTANTE: antes de "Interao" e "Intero"
                    ('Interao', 'Interação'),
                    ('Intero', 'Interação'),  # Caso específico: "Sem Intero" → "Sem Interação"
                    ('Configurao', 'Configuração'),
                    ('Atualizacao', 'Atualização'),
                    ('Atualizaco', 'Atualização'),  # Se já foi corrompido
                    ('Emissao', 'Emissão'),  # IMPORTANTE: antes de "Emisso"
                    ('Emisso', 'Emissão'),  # Corrigir se já foi corrompido
                    ('Orientao', 'Orientação'),
                    ('Informao', 'Informação'),
                    ('Instalao', 'Instalação'),
                    ('Conexo', 'Conexão'),  # Corrigir "Conexo" → "Conexão"
                    ('Conexao', 'Conexão'),  # Corrigir "Conexao" → "Conexão"
                    ('Dvida', 'Dúvida'),  # Corrigir "Dvida" → "Dúvida"
                    ('Duvida', 'Dúvida'),  # Corrigir "Duvida" → "Dúvida"
                    ('Relatorios', 'Relatórios'),
                    ('Relatorio', 'Relatório'),
                    ('Relatrios', 'Relatórios'),
                    ('Rotatrios', 'Relatórios'),
                    # Corrigir casos onde "e Relatorios" foi corrompido
                    (' e Relatrios', ' e Relatórios'),
                    (' e Relatorios', ' e Relatórios'),
                    # CORREÇÃO: "Orientaes" -> "Orientações"
                    ('Orientaes', 'Orientações'),
                    ('orientaes', 'orientações'),
                    ('ORIENTAES', 'ORIENTAÇÕES'),
                    # CORREÇÃO: "Auxlio" -> "Auxílio"
                    ('Auxlio', 'Auxílio'),
                    ('auxlio', 'auxílio'),
                    ('AUXLIO', 'AUXÍLIO'),
                    # CORREÇÃO: "Auxilio" -> "Auxílio" (caso já tenha o "i")
                    ('Auxilio', 'Auxílio'),
                    ('auxilio', 'auxílio'),
                    ('AUXILIO', 'AUXÍLIO'),
                    # CORREÇÃO: "Licena" -> "Licença"
                    ('Licena', 'Licença'),
                    ('licena', 'licença'),
                    ('LICENA', 'LICENÇA'),
                    # CORREÇÃO: "Liena" -> "Licença"
                    ('Liena', 'Licença'),
                    ('liena', 'licença'),
                    ('LIENA', 'LICENÇA'),
                    # CORREÇÃO: "Liberão" -> "Liberação"
                    ('Liberão', 'Liberação'),
                    ('liberão', 'liberação'),
                    ('LIBERÃO', 'LIBERAÇÃO'),
                    # CORREÇÃO: "Tributão" -> "Tributação"
                    ('Tributão', 'Tributação'),
                    ('tributão', 'tributação'),
                    ('TRIBUTÃO', 'TRIBUTAÇÃO'),
                    # CORREÇÃO: "Exportão" -> "Exportação"
                    ('Exportão', 'Exportação'),
                    ('exportão', 'exportação'),
                    ('EXPORTÃO', 'EXPORTAÇÃO'),
                    # CORREÇÃO: "Exporto" -> "Exportação"
                    ('Exporto', 'Exportação'),
                    ('exporto', 'exportação'),
                    ('EXPORTO', 'EXPORTAÇÃO'),
                    # CORREÇÃO: "ms" -> "mês"
                    (' ms ', ' mês '),
                    (' ms.', ' mês.'),
                    (' ms,', ' mês,'),
                    # CORREÇÃO: "prximo" -> "próximo"
                    ('prximo', 'próximo'),
                    ('Prximo', 'Próximo'),
                    ('PRXIMO', 'PRÓXIMO'),
                    # CORREÇÃO: "Conferncia" -> "Conferência"
                    ('Conferncia', 'Conferência'),
                    ('conferncia', 'conferência'),
                    ('CONFERNCA', 'CONFERÊNCIA'),
                    # CORREÇÃO: "Pr-Venda" -> "Pré-Venda"
                    ('Pr-Venda', 'Pré-Venda'),
                    ('pr-venda', 'pré-venda'),
                    ('PR-VENDA', 'PRÉ-VENDA'),
                    # CORREÇÃO: "Configuraes" -> "Configurações"
                    ('Configuraes', 'Configurações'),
                    ('configuraes', 'configurações'),
                    ('CONFIGURAES', 'CONFIGURAÇÕES'),
                    # CORREÇÃO: "Movimentaes" -> "Movimentações"
                    ('Movimentaes', 'Movimentações'),
                    ('movimentaes', 'movimentações'),
                    ('MOVIMENTAES', 'MOVIMENTAÇÕES'),
                    # CORREÇÃO: "Parmetros" -> "Parâmetros"
                    ('Parmetros', 'Parâmetros'),
                    ('parmetros', 'parâmetros'),
                    ('PARMETROS', 'PARÂMETROS'),
                ]

                for errado, correto in correcoes_especificas:
                    assunto_final = assunto_final.replace(errado, correto)

                # Correção adicional para "ms" no início/fim do assunto
                assunto_final = re.sub(r'\bms\b', 'mês', assunto_final, flags=re.IGNORECASE)

                # Correção GENÉRICA: detecta automaticamente palavras terminadas em "ão" que deveriam ser "ção"
                # Esta regra cobre TODOS os casos possíveis sem precisar listar cada palavra
                # IMPORTANTE: Lista de palavras que terminam CORRETAMENTE em "ão" e NÃO devem ser alteradas
                palavras_corretas_com_ao = [
                    'emissão', 'missão', 'sessão', 'pressão', 'expressão', 'impressão',
                    'profissão', 'discussão', 'permissão', 'admissão', 'transmissão',
                    'opressão', 'repressão', 'depressão', 'agressão', 'progressão',
                    'regressão', 'digressão', 'obsessão', 'possessão', 'cessão',
                    'concessão', 'recessão', 'processão', 'sucessão', 'ascensão',
                    'descensão', 'extensão', 'tensão', 'intenção',
                    'atenção', 'retenção', 'detenção', 'manutenção', 'sustentação',
                ]

                # Lista de prefixos que SEMPRE devem terminar em 'ção' (não 'ão')
                # NOTA: 'emiss' foi REMOVIDO porque "Emissão" é a forma correta (termina em "ão", não "ação")
                prefixos_que_terminam_em_cao = [
                    'configur', 'atualiz', 'inform', 'orient', 'instal', 
                    'aplic', 'implement', 'execu', 'intera',
                    'comunic', 'organiz', 'especializ', 'generaliz',
                    'personaliz', 'visualiz', 'finaliz', 'inicializ',
                    'normaliz', 'otimiz', 'prioriz', 'realiz', 'utiliz',
                    'criac', 'publicac', 'verificac', 'modificac', 'identificac',
                    'classificac', 'qualificac', 'quantificac', 'notificac',
                    'certificac', 'justificac', 'especificac', 'simplificac',
                    'valid', 'autentic', 'autoriz', 'capacit', 'complet',
                    'confirm', 'consult', 'contempl', 'demonstr', 'document',
                    'estabelec', 'formul', 'habilit', 'indic', 'justific',
                    'localiz', 'mencion', 'negoci', 'operacion', 'posicion',
                    'prepar', 'present', 'process', 'program', 'projet',
                    'proporcion', 'protej', 'public', 'qualific', 'quantific',
                    'ratific', 'reconhec', 'registr', 'regulament', 'relacion',
                    'represent', 'requisit', 'selecion', 'situ', 'solicit',
                    'substitu', 'supervis', 'transmit', 'transport', 'trat',
                    'conex'  # Para corrigir "Conexo" → "Conexão"
                ]

                def corrigir_ao_para_cao_gen(match):
                    palavra_completa = match.group(0)
                    palavra_lower = palavra_completa.lower()

                    # PRIMEIRO: Verificar se a palavra já está correta (não deve ser alterada)
                    if palavra_lower in palavras_corretas_com_ao:
                        return palavra_completa  # Retornar original sem alterar

                    palavra_sem_ao = palavra_lower[:-2]  # Remove 'ão'

                    for prefixo in prefixos_que_terminam_em_cao:
                        if palavra_sem_ao.endswith(prefixo):
                            if palavra_completa[0].isupper():
                                return palavra_completa[:-2].capitalize() + 'ação'
                            return palavra_completa[:-2] + 'ação'
                    return palavra_completa

                def corrigir_ato_para_cao_gen(match):
                    """Corrige palavras que terminam em 'ato' mas deveriam terminar em 'ação'"""
                    palavra_completa = match.group(0)
                    palavra_lower = palavra_completa.lower()

                    # Verificar se seria uma palavra que termina corretamente em "ão" (não "ação")
                    # Exemplo: "Emissato" não existe, mas se existisse, não deveria virar "Emissação"
                    # porque "Emissão" é a forma correta
                    palavra_como_ao = palavra_lower[:-1] + 'ão'  # Transforma "ato" em "ão"
                    if palavra_como_ao in palavras_corretas_com_ao:
                        # Se a palavra com "ão" está na lista de corretas, não corrigir
                        return palavra_completa

                    palavra_sem_ato = palavra_lower[:-3]  # Remove 'ato'

                    for prefixo in prefixos_que_terminam_em_cao:
                        if palavra_sem_ato.endswith(prefixo):
                            if palavra_completa[0].isupper():
                                return palavra_completa[:-3].capitalize() + 'ação'
                            return palavra_completa[:-3] + 'ação'
                    return palavra_completa

                # Corrigir palavras terminadas em "ão"
                assunto_final = re.sub(
                    r'\b([A-Za-záéíóúàêô]{4,})ão\b',
                    corrigir_ao_para_cao_gen,
                    assunto_final,
                    flags=re.IGNORECASE
                )

                # Corrigir palavras terminadas em "ato" (ex: Validato -> Validação)
                assunto_final = re.sub(
                    r'\b([A-Za-záéíóúàêô]{4,})ato\b',
                    corrigir_ato_para_cao_gen,
                    assunto_final,
                    flags=re.IGNORECASE
                )

                # Correção genérica para palavras que perderam o acento "ú"
                # Exemplos: "Dvida" → "Dúvida", "Duvida" → "Dúvida"
                palavras_com_u_acentuado = {
                    'dvida': 'dúvida',
                    'duvida': 'dúvida',
                    'Dvida': 'Dúvida',
                    'Duvida': 'Dúvida',
                    'DVIDA': 'DÚVIDA',
                    'DUVIDA': 'DÚVIDA',
                }

                def corrigir_u_acentuado(match):
                    palavra = match.group(0)
                    palavra_lower = palavra.lower()
                    if palavra_lower in palavras_com_u_acentuado:
                        # Preservar capitalização
                        if palavra.isupper():
                            return palavras_com_u_acentuado[palavra_lower].upper()
                        elif palavra[0].isupper():
                            return palavras_com_u_acentuado[palavra_lower].capitalize()
                        return palavras_com_u_acentuado[palavra_lower]
                    return palavra

                # Corrigir palavras conhecidas que perderam o "ú"
                assunto_final = re.sub(
                    r'\b(D[vV]ida|D[uU]vida)\b',
                    corrigir_u_acentuado,
                    assunto_final,
                    flags=re.IGNORECASE
                )

                # Correções específicas adicionais para casos comuns
                correcoes_especificas_finais = [
                    ('Validato', 'Validação'),
                    ('Validão', 'Validação'),
                    ('Validac', 'Validação'),
                    # Garantir correção de "Dvida" -> "Dúvida" (mesmo em combinações como "Dvida/Orientar")
                    ('Dvida/', 'Dúvida/'),
                    ('Dvida ', 'Dúvida '),
                    ('Dvida', 'Dúvida'),  # Deve vir depois das versões com caracteres especiais
                    ('Duvida/', 'Dúvida/'),
                    ('Duvida ', 'Dúvida '),
                    ('Duvida', 'Dúvida'),  # Deve vir depois das versões com caracteres especiais
                    # CORREÇÃO: "Orientaes" -> "Orientações"
                    ('Orientaes', 'Orientações'),
                    ('orientaes', 'orientações'),
                    ('ORIENTAES', 'ORIENTAÇÕES'),
                    # CORREÇÃO: "Auxlio" -> "Auxílio"
                    ('Auxlio', 'Auxílio'),
                    ('auxlio', 'auxílio'),
                    ('AUXLIO', 'AUXÍLIO'),
                    # CORREÇÃO: "Auxilio" -> "Auxílio" (caso já tenha o "i")
                    ('Auxilio', 'Auxílio'),
                    ('auxilio', 'auxílio'),
                    ('AUXILIO', 'AUXÍLIO'),
                    # CORREÇÃO: "Licena" -> "Licença"
                    ('Licena', 'Licença'),
                    ('licena', 'licença'),
                    ('LICENA', 'LICENÇA'),
                    # CORREÇÃO: "Liena" -> "Licença"
                    ('Liena', 'Licença'),
                    ('liena', 'licença'),
                    ('LIENA', 'LICENÇA'),
                    # CORREÇÃO: "Liberão" -> "Liberação"
                    ('Liberão', 'Liberação'),
                    ('liberão', 'liberação'),
                    ('LIBERÃO', 'LIBERAÇÃO'),
                    # CORREÇÃO: "Tributão" -> "Tributação"
                    ('Tributão', 'Tributação'),
                    ('tributão', 'tributação'),
                    ('TRIBUTÃO', 'TRIBUTAÇÃO'),
                    # CORREÇÃO: "Exportão" -> "Exportação"
                    ('Exportão', 'Exportação'),
                    ('exportão', 'exportação'),
                    ('EXPORTÃO', 'EXPORTAÇÃO'),
                    # CORREÇÃO: "Exporto" -> "Exportação"
                    ('Exporto', 'Exportação'),
                    ('exporto', 'exportação'),
                    ('EXPORTO', 'EXPORTAÇÃO'),
                    # CORREÇÃO: "ms" -> "mês"
                    (' ms ', ' mês '),
                    (' ms.', ' mês.'),
                    (' ms,', ' mês,'),
                    # CORREÇÃO: "prximo" -> "próximo"
                    ('prximo', 'próximo'),
                    ('Prximo', 'Próximo'),
                    ('PRXIMO', 'PRÓXIMO'),
                    # CORREÇÃO: "Conferncia" -> "Conferência"
                    ('Conferncia', 'Conferência'),
                    ('conferncia', 'conferência'),
                    ('CONFERNCA', 'CONFERÊNCIA'),
                    # CORREÇÃO: "Pr-Venda" -> "Pré-Venda"
                    ('Pr-Venda', 'Pré-Venda'),
                    ('pr-venda', 'pré-venda'),
                    ('PR-VENDA', 'PRÉ-VENDA'),
                    # CORREÇÃO: "Configuraes" -> "Configurações"
                    ('Configuraes', 'Configurações'),
                    ('configuraes', 'configurações'),
                    ('CONFIGURAES', 'CONFIGURAÇÕES'),
                    # CORREÇÃO: "Movimentaes" -> "Movimentações"
                    ('Movimentaes', 'Movimentações'),
                    ('movimentaes', 'movimentações'),
                    ('MOVIMENTAES', 'MOVIMENTAÇÕES'),
                    # CORREÇÃO: "Parmetros" -> "Parâmetros"
                    ('Parmetros', 'Parâmetros'),
                    ('parmetros', 'parâmetros'),
                    ('PARMETROS', 'PARÂMETROS'),
                ]

                for errado, correto in correcoes_especificas_finais:
                    assunto_final = assunto_final.replace(errado, correto)

                # Correção adicional para "ms" no início/fim do assunto
                assunto_final = re.sub(r'\bms\b', 'mês', assunto_final, flags=re.IGNORECASE)

                # Aplicar fix_text novamente no final para garantir que todas as correções de encoding foram aplicadas
                assunto_final = fix_text(assunto_final)

                # Verificação final obrigatória para "Dvida" -> "Dúvida" (caso tenha passado despercebido)
                # CORREÇÃO: Otimizar loop (reduzir de 3 para 1)
                assunto_final = assunto_final.replace('DVIDA', 'DÚVIDA').replace('DUVIDA', 'DÚVIDA')
                assunto_final = assunto_final.replace('Dvida', 'Dúvida').replace('Duvida', 'Dúvida')
                assunto_final = assunto_final.replace('dvida', 'dúvida').replace('duvida', 'dúvida')
                # Regex final para garantir
                assunto_final = re.sub(r'\bD[vV]ida\b', 'Dúvida', assunto_final, flags=re.IGNORECASE)
                assunto_final = re.sub(r'\bD[uU]vida\b', 'Dúvida', assunto_final, flags=re.IGNORECASE)

                # CORREÇÃO: "Rejeies" -> "Rejeições" (também no assunto)
                assunto_final = re.sub(r'\bRejeies\b', 'Rejeições', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('Rejeies', 'Rejeições')
                assunto_final = assunto_final.replace('REJEIES', 'REJEIÇÕES')
                assunto_final = assunto_final.replace('rejeies', 'rejeições')
                assunto_final = assunto_final.replace('Rejeio', 'Rejeição')
                assunto_final = assunto_final.replace('REJEIO', 'REJEIÇÃO')
                assunto_final = assunto_final.replace('rejeio', 'rejeição')
                # CORREÇÃO: "numero" -> "número"
                assunto_final = re.sub(r'\bnumero\b', 'número', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('numero', 'número')
                assunto_final = assunto_final.replace('Numero', 'Número')
                assunto_final = assunto_final.replace('NUMERO', 'NÚMERO')
                # CORREÇÃO: "diferenaa" -> "diferença"
                assunto_final = re.sub(r'\bdiferenaa\b', 'diferença', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('diferenaa', 'diferença')
                assunto_final = assunto_final.replace('Diferenaa', 'Diferença')
                assunto_final = assunto_final.replace('DIFERENAA', 'DIFERENÇA')
                # CORREÇÃO: "calculo" -> "cálculo"
                assunto_final = re.sub(r'\bcalculo\b', 'cálculo', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('calculo', 'cálculo')
                assunto_final = assunto_final.replace('Calculo', 'Cálculo')
                assunto_final = assunto_final.replace('CALCULO', 'CÁLCULO')
                # CORREÇÃO: "permisses" -> "permissões"
                assunto_final = re.sub(r'\bpermisses\b', 'permissões', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('permisses', 'permissões')
                assunto_final = assunto_final.replace('Permisses', 'Permissões')
                assunto_final = assunto_final.replace('PERMISSES', 'PERMISSÕES')
                # CORREÇÃO: "Destinatrio" -> "Destinatário"
                assunto_final = re.sub(r'\bdestinatrio\b', 'destinatário', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('Destinatrio', 'Destinatário')
                assunto_final = assunto_final.replace('destinatrio', 'destinatário')
                assunto_final = assunto_final.replace('DESTINATRIO', 'DESTINATÁRIO')
                # CORREÇÃO: "impressãora" -> "impressora"
                assunto_final = re.sub(r'\bimpressãora\b', 'impressora', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('impressãora', 'impressora')
                assunto_final = assunto_final.replace('Impressãora', 'Impressora')
                assunto_final = assunto_final.replace('IMPRESSÃORA', 'IMPRESSORA')
                # CORREÇÃO: "executvel" -> "executável"
                assunto_final = re.sub(r'\bexecutvel\b', 'executável', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('executvel', 'executável')
                assunto_final = assunto_final.replace('Executvel', 'Executável')
                assunto_final = assunto_final.replace('EXECUTVEL', 'EXECUTÁVEL')
                # CORREÇÃO: "verso" -> "versão"
                assunto_final = re.sub(r'\bverso\b', 'versão', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('verso', 'versão')
                assunto_final = assunto_final.replace('Verso', 'Versão')
                assunto_final = assunto_final.replace('VERSO', 'VERSÃO')
                # CORREÇÃO: "Oscilão" -> "Oscilação"
                assunto_final = re.sub(r'\bOscilão\b', 'Oscilação', assunto_final, flags=re.IGNORECASE)
                assunto_final = assunto_final.replace('Oscilão', 'Oscilação')
                assunto_final = assunto_final.replace('oscilão', 'oscilação')
                assunto_final = assunto_final.replace('OSCILÃO', 'OSCILAÇÃO')

                embed = discord.Embed(
                    title=f"Ticket: {assunto_final}",
                    description=f"**Status:** {emoji} {status}",
                    color=cor)
                if ticket_visual != 'N/A':
                    embed.add_field(name="ID Ticket",
                                    value=f"#{ticket_visual}",
                                    inline=True)
                embed.add_field(name="Cliente",
                                value=cliente_final,
                                inline=True)
                if operador_final:
                    embed.add_field(name="Operador",
                                    value=operador_final,
                                    inline=True)
                else:
                    embed.add_field(name="Operador",
                                    value="Não atribuído",
                                    inline=True)

                # Adicionar campo "Causa" se disponível
                if causa and causa.strip() and causa != 'None':
                    # Limitar tamanho da causa para não quebrar o embed (máximo 1024 caracteres)
                    causa_display = causa[:1024] if len(causa) > 1024 else causa
                    embed.add_field(name="Causa",
                                    value=causa_display,
                                    inline=False)

                # Adicionar campo extra "Detalhamento da Causa" se disponível
                if detalhamento_causa:
                    detalhamento_causa_str = str(detalhamento_causa).strip()
                    if detalhamento_causa_str and detalhamento_causa_str != 'None' and detalhamento_causa_str.lower() != 'none':
                        # Limitar tamanho para não quebrar o embed (máximo 1024 caracteres)
                        detalhamento_display = detalhamento_causa_str[:1024] if len(detalhamento_causa_str) > 1024 else detalhamento_causa_str
                        embed.add_field(name="Detalhamento da Causa",
                                        value=detalhamento_display,
                                        inline=False)
                        logger.info(f"✅ Campo 'Detalhamento da Causa' adicionado ao embed: {detalhamento_display[:50]}...")
                    else:
                        logger.info(f"⚠️ Detalhamento da Causa está vazio ou inválido: {repr(detalhamento_causa_str)}")
                else:
                    logger.info("⚠️ Detalhamento da Causa não foi encontrado ou é None")

                embed.set_footer(text="DeskManager Integration")
                try:
                    await channel.send(embed=embed)
                except Exception as e:
                    logger.error(f"Erro ao enviar embed do ticket {ticket_visual}: {e}", exc_info=True)
                else:
                    # Enviar o detalhamento completo em chunks após o embed (Option B)
                    try:
                        if 'detalhamento_causa_str' in locals() and detalhamento_causa_str:
                            full = str(detalhamento_causa_str)
                            # Só enviar se for significativamente maior que o preview do embed
                            if len(full) > 1024:
                                max_chunk = 1900
                                chunks = [full[i:i+max_chunk] for i in range(0, len(full), max_chunk)]
                                total = len(chunks)
                                for idx, chunk in enumerate(chunks, start=1):
                                    prefix = f"Detalhamento completo ({idx}/{total}):\n"
                                    try:
                                        await channel.send(prefix + chunk)
                                    except Exception as ex:
                                        logger.error(f"Erro ao enviar chunk {idx}/{total} para ticket {ticket_visual}: {ex}", exc_info=True)
                    except Exception as e:
                        logger.error(f"Erro ao enviar detalhamento completo do ticket {ticket_visual}: {e}", exc_info=True)

            return web.Response(text="OK", status=200)
        except (json.JSONDecodeError, ValueError) as e:
            logger.error(f"Erro ao processar JSON do webhook: {e}",
                         exc_info=True)
            return web.Response(text="Erro no formato", status=200)
        except aiohttp.ClientError as e:
            logger.error(f"Erro de conexão no webhook: {e}")
            return web.Response(text="Erro de conexão", status=200)
        except Exception as e:
            logger.error(f"Erro inesperado no webhook: {e}", exc_info=True)
            return web.Response(text="Erro", status=200)


async def setup(bot: commands.Bot) -> None:
    # Verificar se o cog já está carregado para evitar duplicação
    existing_cog = bot.get_cog('DeskManagerCog')
    if existing_cog is not None:
        logger.warning("DeskManagerCog já está carregado, pulando registro duplicado")
        return

    # Garantir que estamos criando DeskManagerCog, não ScheduleCog
    cog = DeskManagerCog(bot)

    # Verificar se o nome do cog está correto antes de adicionar
    if cog.__class__.__name__ != 'DeskManagerCog':
        logger.error(f"Erro: Tentando registrar cog com nome incorreto: {cog.__class__.__name__}")
        raise ValueError(f"Cog deve ser DeskManagerCog, mas é {cog.__class__.__name__}")

    await bot.add_cog(cog)
    await cog.start_webserver()

