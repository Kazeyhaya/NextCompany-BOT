import discord
import os
from discord.ext import commands
from discord import app_commands
from aiohttp import ClientTimeout
from datetime import datetime
from duckduckgo_search import DDGS
import google.generativeai as genai
from groq import Groq
import random
import logging
import re
import asyncio
from collections import defaultdict
from typing import Dict, List, Optional
from urllib.parse import quote

from ..config import Config
from ..constants import SUPPORT_MESSAGES
from ..data.pokemon import POKEMON_DB
from ..utils.database import JsonDatabase
from google.api_core.exceptions import ResourceExhausted

logger = logging.getLogger(__name__)

WEATHER_KEYWORDS = [
    'clima', 'tempo', 'previsao', 'previsão', 'temperatura', 'chuva',
    'weather', 'sol', 'nublado', 'chover', 'frio', 'calor', 'quente',
    'umidade', 'vento', 'meteorologia', 'graus', 'celsius'
]

CONDITION_EMOJI = {
    'sunny': '☀️',
    'clear': '☀️',
    'partly cloudy': '⛅',
    'cloudy': '☁️',
    'overcast': '☁️',
    'mist': '🌫️',
    'fog': '🌫️',
    'rain': '🌧️',
    'light rain': '🌦️',
    'heavy rain': '🌧️',
    'drizzle': '🌦️',
    'thunderstorm': '⛈️',
    'thunder': '⛈️',
    'snow': '❄️',
    'sleet': '🌨️',
    'hail': '🌨️',
    'blizzard': '❄️',
    'wind': '💨',
    'windy': '💨',
}


class ToolsCog(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.cooldowns: Dict[str, datetime] = {}
        self.chat_history: Dict[str, List[Dict]] = {}
        self.channel_history: Dict[str, List[Dict]] = {}
        self.sorteo_history: List[Dict] = []
        self.groq_client = None
        self.load_chat_history()
        self.load_channel_history()
        self.load_sorteo_history()

        if Config.GROQ_API_KEY:
            try:
                self.groq_client = Groq(api_key=Config.GROQ_API_KEY)
                logger.info("Groq AI configurada com sucesso (IA principal).")
            except Exception as e:
                logger.error(f"Erro ao configurar Groq AI: {e}")

        if Config.GEMINI_KEY:
            try:
                genai.configure(api_key=Config.GEMINI_KEY)
                logger.info("Gemini AI configurada como fallback.")
            except Exception as e:
                logger.error(f"Erro ao configurar Gemini AI: {e}")

    def load_chat_history(self) -> None:
        """Carregar histórico de conversa salvo"""
        try:
            self.chat_history = JsonDatabase.load('chat_history.json', {})
            logger.info(
                f"Histórico de conversa carregado: {len(self.chat_history)} usuários"
            )
        except Exception as e:
            logger.error(f"Erro ao carregar histórico: {e}")
            self.chat_history = {}

    def load_channel_history(self) -> None:
        """Carregar histórico global dos canais"""
        try:
            self.channel_history = JsonDatabase.load('channel_history.json',
                                                     {})
            logger.info(
                f"Histórico de canais carregado: {len(self.channel_history)} canais"
            )
        except Exception as e:
            logger.error(f"Erro ao carregar histórico de canais: {e}")
            self.channel_history = {}

    def save_chat_history(self) -> None:
        """Salvar histórico de conversa"""
        try:
            for user_id in self.chat_history:
                self.chat_history[user_id] = self.chat_history[user_id][-30:]
            JsonDatabase.save('chat_history.json', self.chat_history)
        except Exception as e:
            logger.error(f"Erro ao salvar histórico: {e}")

    def save_channel_history(self) -> None:
        """Salvar histórico global dos canais"""
        try:
            for channel_id in self.channel_history:
                self.channel_history[channel_id] = self.channel_history[
                    channel_id][-50:]
            JsonDatabase.save('channel_history.json', self.channel_history)
        except Exception as e:
            logger.error(f"Erro ao salvar histórico de canais: {e}")

    def load_sorteo_history(self) -> None:
        """Carregar histórico de sorteios"""
        try:
            self.sorteo_history = JsonDatabase.load('sorteo_history.json', {})
            if not isinstance(self.sorteo_history, list):
                self.sorteo_history = []
            logger.info(
                f"Histórico de sorteios carregado: {len(self.sorteo_history)} registros"
            )
        except Exception as e:
            logger.error(f"Erro ao carregar histórico de sorteios: {e}")
            self.sorteo_history = []

    def save_sorteo_history(self) -> None:
        """Salvar histórico de sorteios"""
        try:
            history = self.sorteo_history[-100:] if len(
                self.sorteo_history) > 100 else self.sorteo_history
            JsonDatabase.save('sorteo_history.json', history)
        except Exception as e:
            logger.error(f"Erro ao salvar histórico de sorteios: {e}")

    async def call_ai(self, context: str) -> Optional[str]:
        """Chamar IA usando Groq (principal) ou Gemini (fallback)"""
        if self.groq_client:
            try:
                response = self.groq_client.chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=[
                        {"role": "system", "content": Config.BOT_PERSONALITY},
                        {"role": "user", "content": context}
                    ],
                    max_tokens=1024,
                    temperature=0.7
                )
                txt = response.choices[0].message.content
                if txt:
                    logger.info("Resposta gerada via Groq (Llama 3.1)")
                    return txt
            except Exception as e:
                logger.warning(f"Erro no Groq, tentando Gemini: {e}")

        if Config.GEMINI_KEY:
            try:
                model = genai.GenerativeModel('gemini-2.0-flash')
                response = await model.generate_content_async(context)
                logger.info("Resposta gerada via Gemini (fallback)")
                return response.text
            except Exception as e:
                logger.error(f"Erro no Gemini fallback: {e}")

        return None

    def check_cooldown(self, user_id: int, command: str, seconds: int) -> bool:
        """Verificar cooldown do usuário"""
        now = datetime.now()
        key = f"{user_id}_{command}"
        if key in self.cooldowns:
            last_use = self.cooldowns[key]
            if (now - last_use).total_seconds() < seconds:
                return False
        self.cooldowns[key] = now
        return True

    def get_cooldown_remaining(self, user_id: int, command: str,
                               seconds: int) -> int:
        """Obter tempo restante do cooldown"""
        now = datetime.now()
        key = f"{user_id}_{command}"
        if key in self.cooldowns:
            last_use = self.cooldowns[key]
            remaining = seconds - (now - last_use).total_seconds()
            if remaining > 0:
                return int(remaining)
        return 0

    async def get_weather(self, cidade: str) -> Optional[Dict]:
        """Buscar previsão do tempo via wttr.in"""
        try:
            timeout = ClientTimeout(total=10)
            cidade_encoded = quote(cidade, safe='')
            url = f"https://wttr.in/{cidade_encoded}?format=j1&lang=pt"

            if hasattr(self.bot, 'session') and self.bot.session:
                async with self.bot.session.get(url, timeout=timeout) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data
            return None
        except Exception as e:
            logger.error(f"Erro ao buscar clima: {e}")
            return None

    def get_condition_emoji(self, condition: str) -> str:
        """Retorna emoji baseado na condição do tempo"""
        condition_lower = condition.lower()
        for key, emoji in CONDITION_EMOJI.items():
            if key in condition_lower:
                return emoji
        return '🌡️'

    def format_weather_embed(self, data: Dict, cidade: str) -> discord.Embed:
        """Formata os dados do clima em um embed"""
        current = data.get('current_condition', [{}])[0]
        location = data.get('nearest_area', [{}])[0]

        temp = current.get('temp_C', 'N/A')
        feels_like = current.get('FeelsLikeC', 'N/A')
        humidity = current.get('humidity', 'N/A')
        wind_speed = current.get('windspeedKmph', 'N/A')
        wind_dir = current.get('winddir16Point', '')

        desc_list = current.get('lang_pt', current.get('weatherDesc', [{}]))
        if isinstance(desc_list, list) and desc_list:
            condition = desc_list[0].get('value', 'Desconhecido')
        else:
            condition = 'Desconhecido'

        city_name = location.get('areaName', [{}])[0].get(
            'value', cidade) if location.get('areaName') else cidade
        region = location.get('region', [{}])[0].get(
            'value', '') if location.get('region') else ''
        country = location.get('country', [{}])[0].get(
            'value', '') if location.get('country') else ''

        location_str = city_name
        if region:
            location_str += f", {region}"
        if country:
            location_str += f" - {country}"

        emoji = self.get_condition_emoji(condition)

        embed = discord.Embed(title=f"{emoji} Clima em {location_str}",
                              color=discord.Color.blue())

        embed.add_field(name="🌡️ Temperatura",
                        value=f"**{temp}°C**",
                        inline=True)
        embed.add_field(name="🤒 Sensação",
                        value=f"{feels_like}°C",
                        inline=True)
        embed.add_field(name="💧 Umidade", value=f"{humidity}%", inline=True)
        embed.add_field(name="💨 Vento",
                        value=f"{wind_speed} km/h {wind_dir}",
                        inline=True)
        embed.add_field(name="📋 Condição", value=condition, inline=True)

        weather = data.get('weather', [])
        if len(weather) >= 3:
            forecast_text = ""
            for i, day in enumerate(weather[:3]):
                date = day.get('date', '')
                max_temp = day.get('maxtempC', 'N/A')
                min_temp = day.get('mintempC', 'N/A')

                day_desc = day.get('hourly', [{}])[4].get(
                    'lang_pt',
                    day.get('hourly', [{}])[4].get(
                        'weatherDesc', [{}])) if day.get('hourly') and len(
                            day.get('hourly', [])) > 4 else [{}]
                if isinstance(day_desc, list) and day_desc:
                    day_condition = day_desc[0].get('value', '')
                else:
                    day_condition = ''

                day_emoji = self.get_condition_emoji(day_condition)

                if i == 0:
                    day_name = "Hoje"
                elif i == 1:
                    day_name = "Amanhã"
                else:
                    day_name = date

                forecast_text += f"{day_emoji} **{day_name}**: {min_temp}°C - {max_temp}°C\n"

            embed.add_field(name="📅 Próximos Dias",
                            value=forecast_text,
                            inline=False)

        embed.set_footer(text="Dados: wttr.in")
        return embed

    def extract_city_from_question(self, question: str) -> Optional[str]:
        """Extrai nome da cidade de uma pergunta sobre clima"""
        patterns = [
            r'(?:clima|tempo|previs[aã]o|temperatura)\s+(?:em|de|do|da|no|na|para)\s+([a-zA-ZÀ-ÿ\s]+?)(?:\?|$|,|\.|!)',
            r'(?:em|de|do|da|no|na)\s+([a-zA-ZÀ-ÿ\s]+?)\s+(?:como|qual|está|ta|tá)',
            r'([a-zA-ZÀ-ÿ\s]+?)\s+(?:clima|tempo|previs[aã]o|temperatura)',
        ]

        for pattern in patterns:
            match = re.search(pattern, question, re.IGNORECASE)
            if match:
                city = match.group(1).strip()
                if len(city) >= 2 and len(city) <= 50:
                    return city
        return None

    def is_weather_question(self, question: str) -> bool:
        """Verifica se a pergunta é sobre clima/tempo meteorológico"""
        question_lower = question.lower()

        time_words = [
            'horas', 'hora', 'minuto', 'segundo', 'relogio', 'relógio',
            'agora', 'tarde', 'manhã', 'noite'
        ]
        if any(word in question_lower
               for word in time_words) and 'tempo' in question_lower:
            if not any(word in question_lower for word in [
                    'clima', 'chuva', 'sol', 'temperatura', 'graus',
                    'previsão', 'previsao'
            ]):
                return False

        weather_count = sum(1 for keyword in WEATHER_KEYWORDS
                            if keyword in question_lower)
        return weather_count >= 1

    @commands.command(name='clima')
    async def check_weather(self,
                            ctx: commands.Context,
                            *,
                            cidade: Optional[str] = None) -> None:
        """Verificar previsão do tempo"""
        if not cidade:
            await ctx.send(
                "Use: `!clima [cidade]`\nExemplo: `!clima São Paulo`")
            return

        if not self.check_cooldown(ctx.author.id, 'clima', 5):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'clima', 5)
            await ctx.send(
                f"⏳ Aguarde {remaining}s para consultar o clima novamente.")
            return

        msg = await ctx.send(f"🔍 Buscando clima em **{cidade}**...")

        data = await self.get_weather(cidade)

        if not data:
            await msg.edit(
                content=
                f"❌ Não consegui encontrar informações do clima para **{cidade}**."
            )
            return

        embed = self.format_weather_embed(data, cidade)
        await msg.delete()
        await ctx.send(embed=embed)

    @app_commands.command(name="clima",
                          description="Ver previsão do tempo de uma cidade")
    @app_commands.describe(cidade="Nome da cidade para consultar o clima")
    async def slash_clima(self, interaction: discord.Interaction, cidade: str):
        if not self.check_cooldown(interaction.user.id, 'clima', 5):
            remaining = self.get_cooldown_remaining(interaction.user.id,
                                                    'clima', 5)
            return await interaction.response.send_message(
                f"⏳ Aguarde {remaining}s para consultar o clima novamente.",
                ephemeral=True)

        await interaction.response.defer()

        data = await self.get_weather(cidade)

        if not data:
            return await interaction.followup.send(
                f"❌ Não consegui encontrar informações do clima para **{cidade}**."
            )

        embed = self.format_weather_embed(data, cidade)
        await interaction.followup.send(embed=embed)

    @commands.command(name='calma')
    async def send_comfort(self, ctx: commands.Context) -> None:
        """Enviar mensagem de suporte/conforto"""
        embed = discord.Embed(
            title="Realidade",
            description=f"*{random.choice(SUPPORT_MESSAGES)}*",
            color=discord.Color.dark_red())
        await ctx.send(embed=embed)

    @commands.command(name='status')
    async def check_status(self, ctx: commands.Context) -> None:
        """Verificar status do sistema"""
        msg = await ctx.send("Verificando conexoes... aguarde.")
        s_net, p_net = "Offline", "---"
        try:
            start = datetime.now()
            timeout = ClientTimeout(total=3)
            if hasattr(self.bot, 'session') and self.bot.session:
                async with self.bot.session.get("https://www.google.com",
                                                timeout=timeout) as resp:
                    if resp.status == 200:
                        p_net = f"{int((datetime.now() - start).total_seconds() * 1000)}ms"
                        s_net = "Online"
        except Exception as e:
            logger.warning(f"Erro ao verificar internet: {e}")

        config = JsonDatabase.load(Config.FILES['config'],
                                   Config.DEFAULT_CONFIG)

        embed = discord.Embed(title="Status do Sistema",
                              color=discord.Color.blue())
        embed.add_field(name="Internet",
                        value=f"{s_net} ({p_net})",
                        inline=True)
        embed.add_field(name="Modo Nuvem", value="Ativado", inline=True)
        saida = config.get("saida_hoje", "18:00")
        embed.add_field(name="Saida Prevista", value=saida, inline=True)
        embed.add_field(name="Pokemon Disponiveis",
                        value=str(len(POKEMON_DB)),
                        inline=True)

        holidays = JsonDatabase.load(Config.FILES['feriados'],
                                     Config.DEFAULT_HOLIDAYS)
        embed.add_field(name="Feriados Cadastrados",
                        value=str(len(holidays)),
                        inline=True)

        await msg.delete()
        await ctx.send(embed=embed)

    @commands.command(name='sorteio')
    async def sortear(self, ctx: commands.Context) -> None:
        """Sortear uma pessoa do canal"""
        mencoes = ctx.message.mentions
        if not mencoes:
            if hasattr(ctx.channel, 'members'):
                members = [
                    m for m in ctx.channel.members
                    if not isinstance(m, discord.ThreadMember) and not m.bot
                    and m != ctx.author
                ]
            else:
                members = []
            if not members:
                await ctx.send("Ninguem disponivel para o sorteio!")
                return
            sorteado = random.choice(members)
        else:
            sorteado = random.choice(mencoes)

        embed = discord.Embed(
            title="Sorteio!",
            description=f"O escolhido foi: **{sorteado.display_name}**!",
            color=discord.Color.gold())
        embed.set_thumbnail(url=sorteado.display_avatar.url)
        await ctx.send(embed=embed)

        self.sorteo_history.append({
            'timestamp': datetime.now().isoformat(),
            'ganhador': sorteado.display_name,
            'usuario_id': sorteado.id,
            'solicitante': ctx.author.display_name
        })
        self.save_sorteo_history()

    @commands.command(name='pesquisar')
    async def search_web(self,
                         ctx: commands.Context,
                         *,
                         termo: Optional[str] = None) -> None:
        """Buscar na web"""
        if not termo:
            await ctx.send("Use: `!pesquisar [termo]`")
            return

        if not self.check_cooldown(ctx.author.id, 'pesquisar', 10):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'pesquisar',
                                                    10)
            await ctx.send(f"Aguarde {remaining}s para pesquisar novamente.")
            return

        msg = await ctx.send(f"Buscando: `{termo}`...")
        try:
            results = DDGS().text(termo, max_results=3)
            if not results:
                await msg.edit(content="Nada encontrado.")
                return

            embed = discord.Embed(title=f"Resultados: {termo}",
                                  color=discord.Color.blue())
            for res in results:
                body = res.get('body', '')[:150]
                embed.add_field(
                    name=res.get('title', 'Sem titulo')[:100],
                    value=f"{body}...\n[Link]({res.get('href', '#')})",
                    inline=False)
            await msg.delete()
            await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f"Erro na pesquisa: {e}")
            await msg.edit(content="Erro na busca. Tente novamente.")

    @commands.command(name='ia')
    async def ask_gemini(self,
                         ctx: commands.Context,
                         *,
                         pergunta: Optional[str] = None) -> None:
        """Perguntar para IA Gemini com memória compartilhada"""
        if not Config.GEMINI_KEY:
            await ctx.send("IA nao configurada (falta GEMINI_KEY).")
            return
        if not pergunta:
            await ctx.send("Use: `!ia [sua pergunta]`")
            return

        if not self.check_cooldown(ctx.author.id, 'ia', 5):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'ia', 5)
            await ctx.send(f"Aguarde {remaining}s para perguntar novamente.")
            return

        async with ctx.typing():
            try:
                user_id = str(ctx.author.id)
                channel_id = str(ctx.channel.id)

                weather_info = ""
                if self.is_weather_question(pergunta):
                    cidade = self.extract_city_from_question(pergunta)
                    if cidade:
                        weather_data = await self.get_weather(cidade)
                        if weather_data:
                            current = weather_data.get('current_condition',
                                                       [{}])[0]
                            temp = current.get('temp_C', 'N/A')
                            humidity = current.get('humidity', 'N/A')
                            desc_list = current.get(
                                'lang_pt', current.get('weatherDesc', [{}]))
                            if isinstance(desc_list, list) and desc_list:
                                condition = desc_list[0].get(
                                    'value', 'Desconhecido')
                            else:
                                condition = 'Desconhecido'

                            weather_info = f"\n\n=== DADOS DO CLIMA EM TEMPO REAL ({cidade}) ===\n"
                            weather_info += f"Temperatura: {temp}°C\n"
                            weather_info += f"Umidade: {humidity}%\n"
                            weather_info += f"Condição: {condition}\n"

                            weather = weather_data.get('weather', [])
                            if weather:
                                weather_info += "Previsão:\n"
                                for i, day in enumerate(weather[:3]):
                                    max_temp = day.get('maxtempC', 'N/A')
                                    min_temp = day.get('mintempC', 'N/A')
                                    if i == 0:
                                        day_name = "Hoje"
                                    elif i == 1:
                                        day_name = "Amanhã"
                                    else:
                                        day_name = day.get('date', '')
                                    weather_info += f"- {day_name}: {min_temp}°C a {max_temp}°C\n"
                            weather_info += "Use esses dados reais para responder sobre o clima.\n"

                user_history = self.chat_history.get(user_id, [])[-10:]
                channel_history = self.channel_history.get(channel_id,
                                                           [])[-25:]

                context = Config.BOT_PERSONALITY + weather_info + "\n\n"

                if channel_history:
                    context += "=== HISTORICO RECENTE DO CANAL ===\n"
                    for idx, h in enumerate(channel_history, 1):
                        context += f"{idx}. {h['usuario']}: \"{h['pergunta']}\"\n"
                    context += "\n"

                if user_history:
                    context += "=== SEU HISTORICO PESSOAL ===\n"
                    for h in user_history:
                        context += f"Voce perguntou: \"{h['pergunta']}\"\nEu respondi: \"{h['resposta']}\"\n---\n"
                    context += "\n"

                context += f"=== PERGUNTA ATUAL ===\n{ctx.author.display_name}: {pergunta}"

                txt = await self.call_ai(context)
                if not txt:
                    await ctx.send("❌ Não consegui conectar com a IA. Tenta de novo!")
                    return

                if user_id not in self.chat_history:
                    self.chat_history[user_id] = []
                self.chat_history[user_id].append({
                    'pergunta': pergunta,
                    'resposta': txt[:200]
                })
                if len(self.chat_history[user_id]) > 30:
                    self.chat_history[user_id] = self.chat_history[user_id][
                        -30:]

                if channel_id not in self.channel_history:
                    self.channel_history[channel_id] = []
                self.channel_history[channel_id].append({
                    'usuario':
                    ctx.author.display_name,
                    'pergunta':
                    pergunta[:200],
                    'timestamp':
                    datetime.now().isoformat(),
                    'user_id':
                    ctx.author.id
                })

                self.save_chat_history()
                self.save_channel_history()

                if len(txt) > 2000:
                    for i in range(0, len(txt), 1900):
                        await ctx.send(txt[i:i + 1900])
                else:
                    await ctx.send(txt)
            except Exception as e:
                logger.error(f"Erro na IA: {e}")
                await ctx.send("Ops, deu um erro na IA. Tenta de novo!")

    @commands.command(name='help')
    async def show_help(self, ctx: commands.Context) -> None:
        """Mostrar lista de comandos"""
        embed = discord.Embed(title="Comandos do Bot NextCompany",
                              description="Lista de comandos disponiveis",
                              color=discord.Color.blue())

        embed.add_field(
            name="Pokemon",
            value=
            "`!pokemon` - Encontrar Pokemon\n`!pokebola` - Capturar\n`!pokedex` - Ver colecao\n`!evoluir [nome]` - Evoluir\n`!ranking` - Ver ranking",
            inline=False)

        embed.add_field(
            name="Horarios",
            value=
            "`!tempo` - Tempo restante\n`!horaextra HH:MM` - Ajustar saida\n`!normal` - Resetar horario\n`!lembrete [tempo] [msg]` - Criar lembrete",
            inline=False)

        embed.add_field(
            name="Feriados",
            value=
            "`!feriados` - Listar\n`!addferiado DD/MM Nome` - Adicionar\n`!rmferiado DD/MM` - Remover",
            inline=False)

        embed.add_field(
            name="Utilidades",
            value=
            "`!status` - Status do sistema\n`!pesquisar [termo]` - Buscar na web\n`!ia [pergunta]` - Perguntar para IA\n`!clima [cidade]` - Previsão do tempo\n`!sorteio` - Sortear pessoa\n`!calma` - Mensagem de suporte",
            inline=False)

        embed.add_field(
            name="Desk.ms - Tickets",
            value=
            "`!tickets` - Listar tickets abertos\n`!tickets [status]` - Filtrar por status\n`!tickets-fechados` - Tickets fechados\n`!ticket [ID]` - Detalhes de um ticket\n`!desk-status` - Status da API Desk\n`!abrir-ticket [titulo]` - Criar novo ticket",
            inline=False)

        embed.add_field(
            name="Desk.ms - Base de Conhecimento",
            value=
            "`!kb-search [termo]` - Buscar artigos\n`!kb-artigo [ID]` - Ver artigo completo",
            inline=False)

        embed.add_field(
            name="Desk.ms - Relatórios",
            value=
            "`!relatorio-resumo` - Resumo de tickets por status\n`!relatorio-operadores` - Quantos chamados cada operador atendeu",
            inline=False)

        embed.set_footer(text="NextCompany Bot - Feito com carinho pelo time!")
        await ctx.send(embed=embed)

    @app_commands.command(name="status",
                          description="Verificar status do sistema")
    async def slash_status(self, interaction: discord.Interaction):
        await interaction.response.defer()

        s_net, p_net = "Offline", "---"
        try:
            start = datetime.now()
            timeout = ClientTimeout(total=3)
            if hasattr(self.bot, 'session') and self.bot.session:
                async with self.bot.session.get("https://www.google.com",
                                                timeout=timeout) as resp:
                    if resp.status == 200:
                        p_net = f"{int((datetime.now() - start).total_seconds() * 1000)}ms"
                        s_net = "Online"
        except Exception as e:
            logger.warning(f"Erro ao verificar internet: {e}")

        config = JsonDatabase.load(Config.FILES['config'],
                                   Config.DEFAULT_CONFIG)

        embed = discord.Embed(title="📊 Status do Sistema",
                              color=discord.Color.blue())
        embed.add_field(name="🌐 Internet",
                        value=f"{s_net} ({p_net})",
                        inline=True)
        embed.add_field(name="☁️ Modo Nuvem", value="Ativado", inline=True)
        saida = config.get("saida_hoje", "18:00")
        embed.add_field(name="🕐 Saida Prevista", value=saida, inline=True)
        embed.add_field(name="🐾 Pokemon Disponiveis",
                        value=str(len(POKEMON_DB)),
                        inline=True)

        holidays = JsonDatabase.load(Config.FILES['feriados'],
                                     Config.DEFAULT_HOLIDAYS)
        embed.add_field(name="🎉 Feriados Cadastrados",
                        value=str(len(holidays)),
                        inline=True)

        await interaction.followup.send(embed=embed)

    @app_commands.command(name="sorteio",
                          description="Sortear uma pessoa do canal")
    async def slash_sorteio(self, interaction: discord.Interaction):
        if hasattr(interaction.channel, 'members'):
            members = [
                m for m in interaction.channel.members
                if not isinstance(m, discord.ThreadMember) and not m.bot
                and m != interaction.user
            ]
        else:
            members = []

        if not members:
            return await interaction.response.send_message(
                "❌ Ninguem disponivel para o sorteio!", ephemeral=True)

        sorteado = random.choice(members)

        embed = discord.Embed(
            title="🎲 Sorteio!",
            description=f"O escolhido foi: **{sorteado.display_name}**!",
            color=discord.Color.gold())
        embed.set_thumbnail(url=sorteado.display_avatar.url)
        await interaction.response.send_message(embed=embed)

        self.sorteo_history.append({
            'timestamp': datetime.now().isoformat(),
            'ganhador': sorteado.display_name,
            'usuario_id': sorteado.id,
            'solicitante': interaction.user.display_name
        })
        self.save_sorteo_history()

    @app_commands.command(name="pesquisar", description="Buscar na web")
    @app_commands.describe(termo="O que voce quer pesquisar")
    async def slash_pesquisar(self, interaction: discord.Interaction,
                              termo: str):
        if not self.check_cooldown(interaction.user.id, 'pesquisar', 10):
            remaining = self.get_cooldown_remaining(interaction.user.id,
                                                    'pesquisar', 10)
            return await interaction.response.send_message(
                f"⏳ Aguarde {remaining}s para pesquisar novamente.",
                ephemeral=True)

        await interaction.response.defer()

        try:
            results = DDGS().text(termo, max_results=3)
            if not results:
                return await interaction.followup.send("❌ Nada encontrado.")

            embed = discord.Embed(title=f"🔍 Resultados: {termo}",
                                  color=discord.Color.blue())
            for res in results:
                body = res.get('body', '')[:150]
                embed.add_field(
                    name=res.get('title', 'Sem titulo')[:100],
                    value=f"{body}...\n[Link]({res.get('href', '#')})",
                    inline=False)
            await interaction.followup.send(embed=embed)
        except Exception as e:
            logger.error(f"Erro na pesquisa: {e}")
            await interaction.followup.send("❌ Erro na busca. Tente novamente."
                                            )

    @app_commands.command(name="ia", description="Perguntar para a IA")
    @app_commands.describe(pergunta="Sua pergunta para a IA")
    async def slash_ia(self, interaction: discord.Interaction, pergunta: str):
        if not Config.GEMINI_KEY:
            return await interaction.response.send_message(
                "❌ IA nao configurada (falta GEMINI_KEY).", ephemeral=True)

        if not self.check_cooldown(interaction.user.id, 'ia', 5):
            remaining = self.get_cooldown_remaining(interaction.user.id, 'ia',
                                                    5)
            return await interaction.response.send_message(
                f"⏳ Aguarde {remaining}s para perguntar novamente.",
                ephemeral=True)

        await interaction.response.defer()

        try:
            user_id = str(interaction.user.id)
            channel_id = str(interaction.channel.id)

            weather_info = ""
            if self.is_weather_question(pergunta):
                cidade = self.extract_city_from_question(pergunta)
                if cidade:
                    weather_data = await self.get_weather(cidade)
                    if weather_data:
                        current = weather_data.get('current_condition',
                                                   [{}])[0]
                        temp = current.get('temp_C', 'N/A')
                        humidity = current.get('humidity', 'N/A')
                        desc_list = current.get(
                            'lang_pt', current.get('weatherDesc', [{}]))
                        if isinstance(desc_list, list) and desc_list:
                            condition = desc_list[0].get(
                                'value', 'Desconhecido')
                        else:
                            condition = 'Desconhecido'

                        weather_info = f"\n\n=== DADOS DO CLIMA EM TEMPO REAL ({cidade}) ===\n"
                        weather_info += f"Temperatura: {temp}°C\n"
                        weather_info += f"Umidade: {humidity}%\n"
                        weather_info += f"Condição: {condition}\n"

                        weather = weather_data.get('weather', [])
                        if weather:
                            weather_info += "Previsão:\n"
                            for i, day in enumerate(weather[:3]):
                                max_temp = day.get('maxtempC', 'N/A')
                                min_temp = day.get('mintempC', 'N/A')
                                if i == 0:
                                    day_name = "Hoje"
                                elif i == 1:
                                    day_name = "Amanhã"
                                else:
                                    day_name = day.get('date', '')
                                weather_info += f"- {day_name}: {min_temp}°C a {max_temp}°C\n"
                        weather_info += "Use esses dados reais para responder sobre o clima.\n"

            user_history = self.chat_history.get(user_id, [])[-10:]
            channel_history = self.channel_history.get(channel_id, [])[-25:]

            context = Config.BOT_PERSONALITY + weather_info + "\n\n"

            if channel_history:
                context += "=== HISTORICO RECENTE DO CANAL ===\n"
                for idx, h in enumerate(channel_history, 1):
                    context += f"{idx}. {h['usuario']}: \"{h['pergunta']}\"\n"
                context += "\n"

            if user_history:
                context += "=== SEU HISTORICO PESSOAL ===\n"
                for h in user_history:
                    context += f"Voce perguntou: \"{h['pergunta']}\"\nEu respondi: \"{h['resposta']}\"\n---\n"
                context += "\n"

            context += f"=== PERGUNTA ATUAL ===\n{interaction.user.display_name}: {pergunta}"

            txt = await self.call_ai(context)
            if not txt:
                return await interaction.followup.send(
                    "❌ Não consegui conectar com a IA. Tenta de novo!")

            if user_id not in self.chat_history:
                self.chat_history[user_id] = []
            self.chat_history[user_id].append({
                'pergunta': pergunta,
                'resposta': txt[:200]
            })
            if len(self.chat_history[user_id]) > 30:
                self.chat_history[user_id] = self.chat_history[user_id][-30:]

            if channel_id not in self.channel_history:
                self.channel_history[channel_id] = []
            self.channel_history[channel_id].append({
                'usuario':
                interaction.user.display_name,
                'pergunta':
                pergunta[:200],
                'timestamp':
                datetime.now().isoformat(),
                'user_id':
                interaction.user.id
            })

            self.save_chat_history()
            self.save_channel_history()

            if len(txt) > 2000:
                for i in range(0, len(txt), 1900):
                    if i == 0:
                        await interaction.followup.send(txt[i:i + 1900])
                    else:
                        await interaction.channel.send(txt[i:i + 1900])
            else:
                await interaction.followup.send(txt)
        except Exception as e:
            logger.error(f"Erro na IA: {e}")
            await interaction.followup.send(
                "❌ Ops, deu um erro na IA. Tenta de novo!")

    @app_commands.command(name="calma",
                          description="Receber uma mensagem de suporte")
    async def slash_calma(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="💜 Realidade",
            description=f"*{random.choice(SUPPORT_MESSAGES)}*",
            color=discord.Color.dark_red())
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="ajuda",
                          description="Ver lista de comandos do bot")
    async def slash_help(self, interaction: discord.Interaction):
        embed = discord.Embed(title="📚 Comandos do Bot NextCompany",
                              description="Use `/comando` para executar",
                              color=discord.Color.blue())

        embed.add_field(
            name="🐾 Pokemon",
            value=
            "`/pokemon` - Encontrar Pokemon\n`/pokebola` - Capturar\n`/pokedex` - Ver colecao\n`/evoluir` - Evoluir Pokemon\n`/ranking` - Ver ranking\n`/trocar` - Trocar Pokemon\n`/batalhar` - Batalhar\n`/conquistas` - Ver conquistas",
            inline=False)

        embed.add_field(
            name="🛠️ Utilidades",
            value=
            "`/status` - Status do sistema\n`/pesquisar` - Buscar na web\n`/ia` - Perguntar para IA\n`/clima` - Previsão do tempo\n`/sorteio` - Sortear pessoa\n`/calma` - Mensagem de suporte",
            inline=False)

        embed.add_field(
            name="🎫 Desk.ms - Tickets",
            value=
            "`/tickets` - Listar tickets\n`/ticket` - Detalhes de um ticket\n`/relatorio` - Relatorios",
            inline=False)

        embed.set_footer(text="NextCompany Bot - Use os comandos com /")
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(ToolsCog(bot))