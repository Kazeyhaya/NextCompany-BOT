# Standard library
import asyncio
import logging
import random
import re
from datetime import datetime
from typing import Dict, List, Optional
from urllib.parse import quote
from zoneinfo import ZoneInfo

# Third-party
import aiohttp
import discord
from aiohttp import ClientTimeout
from discord import app_commands
from discord.ext import commands
from duckduckgo_search import DDGS

# Local
from ..config import Config
from ..constants import SUPPORT_MESSAGES
from ..utils.cooldown import CooldownManager
from ..utils.database import JsonDatabase

logger = logging.getLogger(__name__)

# Constants
MAX_HISTORY_PER_USER = 30
MAX_HISTORY_PER_CHANNEL = 50
MAX_SORTEO_HISTORY = 100
WEATHER_RETRY_MAX = 3
WEATHER_TIMEOUT_TOTAL = 15
WEATHER_TIMEOUT_CONNECT = 5
WEATHER_BACKOFF_BASE = 2
MAX_WEATHER_RESPONSE_LENGTH = 2000
MAX_WEATHER_CHUNK_SIZE = 1900
MAX_SEARCH_TERM_LENGTH = 200
MIN_SEARCH_TERM_LENGTH = 2
MAX_IA_QUESTION_LENGTH = 2000
MIN_IA_QUESTION_LENGTH = 3
MAX_IA_RESPONSE_LENGTH = 2000
MAX_IA_CHUNK_SIZE = 1900
MAX_USER_HISTORY_CONTEXT = 10
MAX_CHANNEL_HISTORY_CONTEXT = 25
MAX_CHAT_HISTORY_SAVED = 200

WEATHER_KEYWORDS = [
    'clima', 'tempo', 'previsao', 'previsão', 'temperatura', 'chuva', 
    'weather', 'sol', 'nublado', 'chover', 'frio', 'calor', 'quente',
    'umidade', 'vento', 'meteorologia', 'graus', 'celsius'
]

CONDITION_EMOJI = {
    'sunny': '☀️', 'clear': '☀️', 'partly cloudy': '⛅', 
    'cloudy': '☁️', 'overcast': '☁️', 'mist': '🌫️', 'fog': '🌫️',
    'rain': '🌧️', 'light rain': '🌦️', 'heavy rain': '🌧️', 'drizzle': '🌦️',
    'thunderstorm': '⛈️', 'thunder': '⛈️', 'snow': '❄️', 'sleet': '🌨️',
    'hail': '🌨️', 'blizzard': '❄️', 'wind': '💨', 'windy': '💨',
}


class ToolsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.cooldown_manager = CooldownManager()
        self.chat_history: Dict[str, List[Dict]] = {}
        self.channel_history: Dict[str, List[Dict]] = {}
        self.sorteo_history: List[Dict] = []
        self.load_chat_history()
        self.load_channel_history()
        self.load_sorteo_history()

    def load_chat_history(self) -> None:
        """Carregar histórico de conversa salvo"""
        try:
            self.chat_history = JsonDatabase.load('chat_history.json', {})
            logger.info(f"Histórico de conversa carregado: {len(self.chat_history)} usuários")
        except Exception as e:
            logger.error(f"Erro ao carregar histórico: {e}")
            self.chat_history = {}

    def load_channel_history(self) -> None:
        """Carregar histórico global dos canais"""
        try:
            self.channel_history = JsonDatabase.load('channel_history.json', {})
            logger.info(f"Histórico de canais carregado: {len(self.channel_history)} canais")
        except Exception as e:
            logger.error(f"Erro ao carregar histórico de canais: {e}")
            self.channel_history = {}

    def save_chat_history(self) -> None:
        """Salvar histórico de conversa com limite automático."""
        try:
            # Limitar histórico por usuário e remover usuários inativos
            for user_id in list(self.chat_history.keys()):
                if len(self.chat_history[user_id]) > MAX_HISTORY_PER_USER:
                    self.chat_history[user_id] = self.chat_history[user_id][-MAX_HISTORY_PER_USER:]
                # Remover usuários sem histórico
                if not self.chat_history[user_id]:
                    del self.chat_history[user_id]
            JsonDatabase.save('chat_history.json', self.chat_history)
        except Exception as e:
            logger.error(f"Erro ao salvar histórico: {e}", exc_info=True)

    def save_channel_history(self) -> None:
        """Salvar histórico global dos canais com limite automático."""
        try:
            # Limitar histórico por canal
            for channel_id in list(self.channel_history.keys()):
                if len(self.channel_history[channel_id]) > MAX_HISTORY_PER_CHANNEL:
                    self.channel_history[channel_id] = self.channel_history[channel_id][-MAX_HISTORY_PER_CHANNEL:]
                # Remover canais sem histórico
                if not self.channel_history[channel_id]:
                    del self.channel_history[channel_id]
            JsonDatabase.save('channel_history.json', self.channel_history)
        except Exception as e:
            logger.error(f"Erro ao salvar histórico de canais: {e}", exc_info=True)

    def load_sorteo_history(self) -> None:
        """Carregar histórico de sorteios"""
        try:
            self.sorteo_history = JsonDatabase.load('sorteo_history.json', {})
            if not isinstance(self.sorteo_history, list):
                self.sorteo_history = []
            logger.info(f"Histórico de sorteios carregado: {len(self.sorteo_history)} registros")
        except Exception as e:
            logger.error(f"Erro ao carregar histórico de sorteios: {e}")
            self.sorteo_history = []

    def save_sorteo_history(self) -> None:
        """Salvar histórico de sorteios"""
        try:
            history = self.sorteo_history[-MAX_SORTEO_HISTORY:] if len(self.sorteo_history) > MAX_SORTEO_HISTORY else self.sorteo_history
            JsonDatabase.save('sorteo_history.json', history)
        except Exception as e:
            logger.error(f"Erro ao salvar histórico de sorteios: {e}")

    def check_cooldown(self, user_id: int, command: str, seconds: int) -> bool:
        """Verificar cooldown do usuário"""
        return self.cooldown_manager.check_cooldown(user_id, command, seconds)

    def get_cooldown_remaining(self, user_id: int, command: str, seconds: int) -> int:
        """Obter tempo restante do cooldown"""
        return self.cooldown_manager.get_cooldown_remaining(user_id, command, seconds)

    async def get_weather(self, cidade: str) -> Optional[Dict]:
        """Buscar previsão do tempo via wttr.in com retry logic"""
        cidade_encoded = quote(cidade, safe='')
        url = f"https://wttr.in/{cidade_encoded}?format=j1&lang=pt"

        session = getattr(self.bot, 'session', None)  # type: ignore[attr-defined]
        if not session:
            logger.error("Session não disponível para buscar clima")
            return None

        # Headers para evitar bloqueio
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "application/json",
            "Accept-Language": "pt-BR,pt;q=0.9"
        }

        # Retry logic com backoff exponencial
        max_retries = WEATHER_RETRY_MAX
        for attempt in range(max_retries):
            try:
                timeout = ClientTimeout(total=WEATHER_TIMEOUT_TOTAL, connect=WEATHER_TIMEOUT_CONNECT)
                async with session.get(url, timeout=timeout, headers=headers) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data
                    elif resp.status == 404:
                        logger.warning(f"Cidade não encontrada: {cidade}")
                        return None
                    else:
                        logger.warning(f"Status HTTP {resp.status} ao buscar clima para {cidade}")
                        if attempt < max_retries - 1:
                            await asyncio.sleep(WEATHER_BACKOFF_BASE ** attempt)  # Backoff exponencial
                            continue
                        return None
            except asyncio.TimeoutError:
                logger.warning(f"Timeout ao buscar clima (tentativa {attempt + 1}/{max_retries})")
                if attempt < max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                    continue
                logger.error(f"Erro ao buscar clima: Timeout após {max_retries} tentativas")
                return None
            except aiohttp.ClientConnectorError as e:
                logger.warning(f"Erro de conexão ao buscar clima (tentativa {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                    continue
                logger.error(f"Erro ao buscar clima: Falha de conexão após {max_retries} tentativas")
                return None
            except aiohttp.ClientError as e:
                logger.warning(f"Erro do cliente HTTP (tentativa {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                    continue
                logger.error(f"Erro ao buscar clima: {e}")
                return None
            except Exception as e:
                logger.error(f"Erro inesperado ao buscar clima: {e}", exc_info=True)
                return None

        return None

    def get_condition_emoji(self, condition: str) -> str:
        """Retorna emoji baseado na condição do tempo"""
        condition_lower = condition.lower()
        for key, emoji in CONDITION_EMOJI.items():
            if key in condition_lower:
                return emoji
        return '🌡️'

    def format_weather_embed(self, data: Dict, cidade: str) -> discord.Embed:
        """Formata os dados do clima em um embed"""
        current = data.get('current_condition', [{}])[0]
        location = data.get('nearest_area', [{}])[0]

        temp = current.get('temp_C', 'N/A')
        feels_like = current.get('FeelsLikeC', 'N/A')
        humidity = current.get('humidity', 'N/A')
        wind_speed = current.get('windspeedKmph', 'N/A')
        wind_dir = current.get('winddir16Point', '')

        desc_list = current.get('lang_pt', current.get('weatherDesc', [{}]))
        if isinstance(desc_list, list) and desc_list:
            condition = desc_list[0].get('value', 'Desconhecido')
        else:
            condition = 'Desconhecido'

        city_name = location.get('areaName', [{}])[0].get('value', cidade) if location.get('areaName') else cidade
        region = location.get('region', [{}])[0].get('value', '') if location.get('region') else ''
        country = location.get('country', [{}])[0].get('value', '') if location.get('country') else ''

        location_str = city_name
        if region:
            location_str += f", {region}"
        if country:
            location_str += f" - {country}"

        emoji = self.get_condition_emoji(condition)

        embed = discord.Embed(
            title=f"{emoji} Clima em {location_str}",
            color=discord.Color.blue()
        )

        embed.add_field(name="🌡️ Temperatura", value=f"**{temp}°C**", inline=True)
        embed.add_field(name="🤒 Sensação", value=f"{feels_like}°C", inline=True)
        embed.add_field(name="💧 Umidade", value=f"{humidity}%", inline=True)
        embed.add_field(name="💨 Vento", value=f"{wind_speed} km/h {wind_dir}", inline=True)
        embed.add_field(name="📋 Condição", value=condition, inline=True)

        weather = data.get('weather', [])
        if len(weather) >= 3:
            forecast_text = ""
            for i, day in enumerate(weather[:3]):
                date = day.get('date', '')
                max_temp = day.get('maxtempC', 'N/A')
                min_temp = day.get('mintempC', 'N/A')

                day_desc = day.get('hourly', [{}])[4].get('lang_pt', day.get('hourly', [{}])[4].get('weatherDesc', [{}])) if day.get('hourly') and len(day.get('hourly', [])) > 4 else [{}]
                if isinstance(day_desc, list) and day_desc:
                    day_condition = day_desc[0].get('value', '')
                else:
                    day_condition = ''

                day_emoji = self.get_condition_emoji(day_condition)

                if i == 0:
                    day_name = "Hoje"
                elif i == 1:
                    day_name = "Amanhã"
                else:
                    day_name = date

                forecast_text += f"{day_emoji} **{day_name}**: {min_temp}°C - {max_temp}°C\n"

            embed.add_field(name="📅 Próximos Dias", value=forecast_text, inline=False)

        embed.set_footer(text="Dados: wttr.in")
        return embed

    def extract_city_from_question(self, question: str) -> Optional[str]:
        """Extrai nome da cidade de uma pergunta sobre clima"""
        patterns = [
            r'(?:clima|tempo|previs[aã]o|temperatura)\s+(?:em|de|do|da|no|na|para)\s+([a-zA-ZÀ-ÿ\s]+?)(?:\?|$|,|\.|!)',
            r'(?:em|de|do|da|no|na)\s+([a-zA-ZÀ-ÿ\s]+?)\s+(?:como|qual|está|ta|tá)',
            r'([a-zA-ZÀ-ÿ\s]+?)\s+(?:clima|tempo|previs[aã]o|temperatura)',
        ]

        for pattern in patterns:
            match = re.search(pattern, question, re.IGNORECASE)
            if match:
                city = match.group(1).strip()
                if len(city) >= 2 and len(city) <= 50:
                    return city
        return None

    def is_weather_question(self, question: str) -> bool:
        """Verifica se a pergunta é sobre clima/tempo meteorológico"""
        question_lower = question.lower()

        time_words = ['horas', 'hora', 'minuto', 'segundo', 'relogio', 'relógio', 'agora', 'tarde', 'manhã', 'noite']
        if any(word in question_lower for word in time_words) and 'tempo' in question_lower:
            if not any(word in question_lower for word in ['clima', 'chuva', 'sol', 'temperatura', 'graus', 'previsão', 'previsao']):
                return False

        weather_count = sum(1 for keyword in WEATHER_KEYWORDS if keyword in question_lower)
        return weather_count >= 1

    async def ask_groq(self, context: str) -> Optional[str]:
        """Chamar API do Groq para gerar resposta"""
        if not Config.GROQ_KEY:
            return None

        try:
            url = "https://api.groq.com/openai/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {Config.GROQ_KEY}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": "llama-3.3-70b-versatile",
                "messages": [
                    {
                        "role": "system",
                        "content": "Você é um assistente prestativo e objetivo. Use linguagem informal brasileira."
                    },
                    {
                        "role": "user",
                        "content": context
                    }
                ],
                "temperature": 0.7,
                "max_tokens": 2000
            }

            session = getattr(self.bot, 'session', None)  # type: ignore[attr-defined]
            if session:
                timeout = ClientTimeout(total=30)
                async with session.post(url, headers=headers, json=payload, timeout=timeout) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if 'choices' in data and len(data['choices']) > 0:
                            return data['choices'][0]['message']['content']
                    else:
                        error_text = await resp.text()
                        logger.error(f"Erro na API Groq (status {resp.status}): {error_text}")
                        return None
            return None
        except aiohttp.ClientError as e:
            logger.error(f"Erro de conexão na API Groq: {e}")
            return None
        except asyncio.TimeoutError:
            logger.error("Timeout ao chamar API Groq")
            return None
        except Exception as e:
            logger.error(f"Erro inesperado ao chamar API Groq: {e}", exc_info=True)
            return None

    @commands.command(name='clima')
    async def check_weather(self, ctx: commands.Context, *, cidade: Optional[str] = None) -> None:
        """Verificar previsão do tempo"""
        if not cidade:
            await ctx.send("Use: `!clima [cidade]`\nExemplo: `!clima São Paulo`")
            return

        if not self.check_cooldown(ctx.author.id, 'clima', 5):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'clima', 5)
            await ctx.send(f"⏳ Aguarde {remaining}s para consultar o clima novamente.")
            return

        msg = await ctx.send(f"🔍 Buscando clima em **{cidade}**...")

        data = await self.get_weather(cidade)

        if not data:
            await msg.edit(content=f"❌ Não consegui encontrar informações do clima para **{cidade}**.")
            return

        embed = self.format_weather_embed(data, cidade)
        await msg.delete()
        await ctx.send(embed=embed)

    @app_commands.command(name="clima", description="Ver previsão do tempo de uma cidade")
    @app_commands.describe(cidade="Nome da cidade para consultar o clima")
    async def slash_clima(self, interaction: discord.Interaction, cidade: str):
        if not self.check_cooldown(interaction.user.id, 'clima', 5):
            remaining = self.get_cooldown_remaining(interaction.user.id, 'clima', 5)
            return await interaction.response.send_message(f"⏳ Aguarde {remaining}s para consultar o clima novamente.", ephemeral=True)

        await interaction.response.defer()

        data = await self.get_weather(cidade)

        if not data:
            return await interaction.followup.send(f"❌ Não consegui encontrar informações do clima para **{cidade}**.")

        embed = self.format_weather_embed(data, cidade)
        await interaction.followup.send(embed=embed)

    @commands.command(name='calma')
    async def send_comfort(self, ctx: commands.Context) -> None:
        """Enviar mensagem de suporte/conforto"""
        embed = discord.Embed(
            title="Realidade",
            description=f"*{random.choice(SUPPORT_MESSAGES)}*",
            color=discord.Color.dark_red()
        )
        await ctx.send(embed=embed)

    @commands.command(name='status')
    async def check_status(self, ctx: commands.Context) -> None:
        """Verificar status do sistema"""
        msg = await ctx.send("Verificando conexoes... aguarde.")
        s_net, p_net = "Offline", "---"
        try:
            start = datetime.now()
            timeout = ClientTimeout(total=3)
            session = getattr(self.bot, 'session', None)  # type: ignore[attr-defined]
            if session:
                async with session.get("https://www.google.com", timeout=timeout) as resp:
                    if resp.status == 200:
                        p_net = f"{int((datetime.now() - start).total_seconds() * 1000)}ms"
                        s_net = "Online"
        except Exception as e:
            logger.warning(f"Erro ao verificar internet: {e}")

        config = JsonDatabase.load(Config.FILES['config'], Config.DEFAULT_CONFIG)

        embed = discord.Embed(title="Status do Sistema", color=discord.Color.blue())
        embed.add_field(name="Internet", value=f"{s_net} ({p_net})", inline=True)
        embed.add_field(name="Modo Nuvem", value="Ativado", inline=True)
        saida = config.get("saida_hoje", "18:00")
        embed.add_field(name="Saida Prevista", value=saida, inline=True)

        holidays = JsonDatabase.load(Config.FILES['feriados'], Config.DEFAULT_HOLIDAYS)
        embed.add_field(name="Feriados Cadastrados", value=str(len(holidays)), inline=True)

        await msg.delete()
        await ctx.send(embed=embed)

    @commands.command(name='sorteio')
    async def sortear(self, ctx: commands.Context) -> None:
        """Sortear uma pessoa do canal"""
        mencoes = ctx.message.mentions
        if not mencoes:
            if isinstance(ctx.channel, (discord.TextChannel, discord.VoiceChannel, discord.Thread)):
                members = [m for m in ctx.channel.members if not isinstance(m, discord.ThreadMember) and not m.bot and m != ctx.author]
            else:
                members = []
            if not members:
                await ctx.send("Ninguem disponivel para o sorteio!")
                return
            sorteado = random.choice(members)
        else:
            sorteado = random.choice(mencoes)

        embed = discord.Embed(
            title="Sorteio!",
            description=f"O escolhido foi: **{sorteado.display_name}**!",
            color=discord.Color.gold()
        )
        embed.set_thumbnail(url=sorteado.display_avatar.url)
        await ctx.send(embed=embed)

        self.sorteo_history.append({
            'timestamp': datetime.now().isoformat(),
            'ganhador': sorteado.display_name,
            'usuario_id': sorteado.id,
            'solicitante': ctx.author.display_name
        })
        self.save_sorteo_history()

    @commands.command(name='pesquisar')
    async def search_web(self, ctx: commands.Context, *, termo: Optional[str] = None) -> None:
        """Buscar na web"""
        if not termo:
            await ctx.send("Use: `!pesquisar [termo]`")
            return

        if not self.check_cooldown(ctx.author.id, 'pesquisar', 10):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'pesquisar', 10)
            await ctx.send(f"Aguarde {remaining}s para pesquisar novamente.")
            return

        msg = await ctx.send(f"Buscando: `{termo}`...")
        try:
            results = DDGS().text(termo, max_results=3)
            if not results:
                await msg.edit(content="Nada encontrado.")
                return

            embed = discord.Embed(title=f"Resultados: {termo}", color=discord.Color.blue())
            for res in results:
                body = res.get('body', '')[:150]
                embed.add_field(
                    name=res.get('title', 'Sem titulo')[:100],
                    value=f"{body}...\n[Link]({res.get('href', '#')})",
                    inline=False
                )
            await msg.delete()
            await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f"Erro na pesquisa: {e}")
            await msg.edit(content="Erro na busca. Tente novamente.")

    @commands.command(name='ia')
    async def ask_groq_command(self, ctx: commands.Context, *, pergunta: Optional[str] = None) -> None:
        """Perguntar para IA Groq com memória compartilhada"""
        if not Config.GROQ_KEY:
            await ctx.send("IA nao configurada (falta GROQ_KEY).")
            return
        if not pergunta:
            await ctx.send("Use: `!ia [sua pergunta]`")
            return

        if not self.check_cooldown(ctx.author.id, 'ia', 5):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'ia', 5)
            await ctx.send(f"Aguarde {remaining}s para perguntar novamente.")
            return

        async with ctx.typing():
            try:
                user_id = str(ctx.author.id)
                channel_id = str(ctx.channel.id)

                weather_info = ""
                if self.is_weather_question(pergunta):
                    cidade = self.extract_city_from_question(pergunta)
                    if cidade:
                        weather_data = await self.get_weather(cidade)
                        if weather_data:
                            current = weather_data.get('current_condition', [{}])[0]
                            temp = current.get('temp_C', 'N/A')
                            humidity = current.get('humidity', 'N/A')
                            desc_list = current.get('lang_pt', current.get('weatherDesc', [{}]))
                            if isinstance(desc_list, list) and desc_list:
                                condition = desc_list[0].get('value', 'Desconhecido')
                            else:
                                condition = 'Desconhecido'

                            weather_info = f"\n\n=== DADOS DO CLIMA EM TEMPO REAL ({cidade}) ===\n"
                            weather_info += f"Temperatura: {temp}°C\n"
                            weather_info += f"Umidade: {humidity}%\n"
                            weather_info += f"Condição: {condition}\n"

                            weather = weather_data.get('weather', [])
                            if weather:
                                weather_info += "Previsão:\n"
                                for i, day in enumerate(weather[:3]):
                                    max_temp = day.get('maxtempC', 'N/A')
                                    min_temp = day.get('mintempC', 'N/A')
                                    if i == 0:
                                        day_name = "Hoje"
                                    elif i == 1:
                                        day_name = "Amanhã"
                                    else:
                                        day_name = day.get('date', '')
                                    weather_info += f"- {day_name}: {min_temp}°C a {max_temp}°C\n"
                            weather_info += "Use esses dados reais para responder sobre o clima.\n"

                user_history = self.chat_history.get(user_id, [])[-MAX_USER_HISTORY_CONTEXT:]
                channel_history = self.channel_history.get(channel_id, [])[-MAX_CHANNEL_HISTORY_CONTEXT:]

                # CORREÇÃO: Adicionar data/hora atual ao contexto para a IA saber o dia de hoje
                now_br = datetime.now(ZoneInfo("America/Sao_Paulo"))
                data_atual = now_br.strftime("%d/%m/%Y")
                hora_atual = now_br.strftime("%H:%M")
                dia_semana = ["Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado", "Domingo"][now_br.weekday()]

                context = Config.BOT_PERSONALITY + weather_info + "\n\n"
                context += "=== DATA E HORA ATUAL (BRASIL) ===\n"
                context += f"Data: {data_atual} ({dia_semana})\n"
                context += f"Hora: {hora_atual}\n"
                context += "Use essas informações para responder perguntas sobre a data/hora atual.\n\n"

                if channel_history:
                    context += "=== HISTORICO RECENTE DO CANAL ===\n"
                    for idx, h in enumerate(channel_history, 1):
                        context += f"{idx}. {h['usuario']}: \"{h['pergunta']}\"\n"
                    context += "\n"

                if user_history:
                    context += "=== SEU HISTORICO PESSOAL ===\n"
                    for h in user_history:
                        context += f"Voce perguntou: \"{h['pergunta']}\"\nEu respondi: \"{h['resposta']}\"\n---\n"
                    context += "\n"

                context += f"=== PERGUNTA ATUAL ===\n{ctx.author.display_name}: {pergunta}"

                txt = await self.ask_groq(context)
                if not txt:
                    await ctx.send("Erro ao conectar com a IA. Tenta de novo!")
                    return

                if user_id not in self.chat_history:
                    self.chat_history[user_id] = []
                self.chat_history[user_id].append({'pergunta': pergunta, 'resposta': txt[:MAX_CHAT_HISTORY_SAVED]})
                if len(self.chat_history[user_id]) > MAX_HISTORY_PER_USER:
                    self.chat_history[user_id] = self.chat_history[user_id][-MAX_HISTORY_PER_USER:]

                if channel_id not in self.channel_history:
                    self.channel_history[channel_id] = []
                self.channel_history[channel_id].append({
                    'usuario': ctx.author.display_name,
                    'pergunta': pergunta[:MAX_CHAT_HISTORY_SAVED],
                    'timestamp': datetime.now().isoformat(),
                    'user_id': ctx.author.id
                })

                self.save_chat_history()
                self.save_channel_history()

                if len(txt) > MAX_IA_RESPONSE_LENGTH:
                    for i in range(0, len(txt), MAX_IA_CHUNK_SIZE):
                        await ctx.send(txt[i:i+MAX_IA_CHUNK_SIZE])
                else:
                    await ctx.send(txt)
            except Exception as e:
                logger.error(f"Erro na IA: {e}")
                await ctx.send("Ops, deu um erro na IA. Tenta de novo!")

    @commands.command(name='help', aliases=['ajuda', 'comandos'])
    async def show_help(self, ctx: commands.Context):
        """Mostrar lista de comandos"""
        embed = discord.Embed(
            title="📚 Comandos do Bot NextCompany",
            description="Use `!comando` ou `/comando` para executar",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="⏰ Horários",
            value="`!tempo` - Tempo restante do expediente\n`!horaextra HH:MM` - Ajustar saída\n`!normal` - Resetar horário\n`!lembrete [tempo] [msg]` - Criar lembrete",
            inline=False
        )

        embed.add_field(
            name="📅 Feriados",
            value="`!feriados` - Listar feriados\n`!addferiado DD/MM Nome` - Adicionar\n`!rmferiado DD/MM` - Remover",
            inline=False
        )

        embed.add_field(
            name="🛠️ Utilidades",
            value="`!status` ou `/status` - Status do sistema\n`!pesquisar [termo]` ou `/pesquisar` - Buscar na web\n`!ia [pergunta]` ou `/ia` - Perguntar para IA\n`!clima [cidade]` ou `/clima` - Previsão do tempo\n`!sorteio` ou `/sorteio` - Sortear pessoa\n`!calma` ou `/calma` - Mensagem de suporte",
            inline=False
        )

        embed.add_field(
            name="🎫 Desk.ms - Tickets",
            value="`!tickets` ou `/tickets` - Listar tickets abertos\n`!tickets [status]` - Filtrar por status\n`!tickets-fechados` - Tickets fechados\n`!ticket [ID]` ou `/ticket` - Detalhes de um ticket\n`!desk-status` - Status da API Desk\n`!abrir-ticket [titulo]` - Criar novo ticket",
            inline=False
        )

        embed.add_field(
            name="📚 Desk.ms - Base de Conhecimento",
            value="`!kb-search [termo]` - Buscar artigos\n`!kb-artigo [ID]` - Ver artigo completo",
            inline=False
        )

        embed.add_field(
            name="📊 Desk.ms - Relatórios",
            value="`!relatorio-resumo` - Resumo de tickets por status\n`!relatorio-operadores` - Tickets por operador\n`/relatorio` - Relatórios interativos",
            inline=False
        )

        embed.set_footer(text="NextCompany Bot - Use !help ou /ajuda para ver esta lista")
        await ctx.send(embed=embed)

    @app_commands.command(name="status", description="Verificar status do sistema")
    async def slash_status(self, interaction: discord.Interaction):
        await interaction.response.defer()

        s_net, p_net = "Offline", "---"
        try:
            start = datetime.now()
            timeout = ClientTimeout(total=3)
            session = getattr(self.bot, 'session', None)  # type: ignore[attr-defined]
            if session:
                async with session.get("https://www.google.com", timeout=timeout) as resp:
                    if resp.status == 200:
                        p_net = f"{int((datetime.now() - start).total_seconds() * 1000)}ms"
                        s_net = "Online"
        except Exception as e:
            logger.warning(f"Erro ao verificar internet: {e}")

        config = JsonDatabase.load(Config.FILES['config'], Config.DEFAULT_CONFIG)

        embed = discord.Embed(title="📊 Status do Sistema", color=discord.Color.blue())
        embed.add_field(name="🌐 Internet", value=f"{s_net} ({p_net})", inline=True)
        embed.add_field(name="☁️ Modo Nuvem", value="Ativado", inline=True)
        saida = config.get("saida_hoje", "18:00")
        embed.add_field(name="🕐 Saida Prevista", value=saida, inline=True)

        holidays = JsonDatabase.load(Config.FILES['feriados'], Config.DEFAULT_HOLIDAYS)
        embed.add_field(name="🎉 Feriados Cadastrados", value=str(len(holidays)), inline=True)

        await interaction.followup.send(embed=embed)

    @app_commands.command(name="sorteio", description="Sortear uma pessoa do canal")
    async def slash_sorteio(self, interaction: discord.Interaction):
        if not isinstance(interaction.channel, (discord.TextChannel, discord.VoiceChannel, discord.Thread)):
            return await interaction.response.send_message("❌ Este comando só funciona em canais de texto ou voz.", ephemeral=True)

        # Filtrar membros válidos (não bots, não o próprio usuário)
        members = [
            m for m in interaction.channel.members 
            if isinstance(m, discord.Member) and not m.bot and m != interaction.user
        ]

        if not members:
            return await interaction.response.send_message("❌ Ninguém disponível para o sorteio!", ephemeral=True)

        sorteado = random.choice(members)

        embed = discord.Embed(
            title="🎲 Sorteio!",
            description=f"O escolhido foi: **{sorteado.display_name}**!",
            color=discord.Color.gold()
        )
        embed.set_thumbnail(url=sorteado.display_avatar.url)
        await interaction.response.send_message(embed=embed)

        self.sorteo_history.append({
            'timestamp': datetime.now().isoformat(),
            'ganhador': sorteado.display_name,
            'usuario_id': sorteado.id,
            'solicitante': interaction.user.display_name
        })
        self.save_sorteo_history()

    @app_commands.command(name="pesquisar", description="Buscar na web")
    @app_commands.describe(termo="O que voce quer pesquisar")
    async def slash_pesquisar(self, interaction: discord.Interaction, termo: str):
        if not self.check_cooldown(interaction.user.id, 'pesquisar', 10):
            remaining = self.get_cooldown_remaining(interaction.user.id, 'pesquisar', 10)
            return await interaction.response.send_message(f"⏳ Aguarde {remaining}s para pesquisar novamente.", ephemeral=True)

        await interaction.response.defer()

        # Validar entrada
        if not termo or len(termo.strip()) < MIN_SEARCH_TERM_LENGTH:
            return await interaction.followup.send(f"❌ Termo de busca muito curto. Use pelo menos {MIN_SEARCH_TERM_LENGTH} caracteres.")

        if len(termo) > MAX_SEARCH_TERM_LENGTH:
            return await interaction.followup.send(f"❌ Termo de busca muito longo. Máximo {MAX_SEARCH_TERM_LENGTH} caracteres.")

        try:
            results = DDGS().text(termo.strip(), max_results=3)
            if not results:
                return await interaction.followup.send("❌ Nada encontrado para essa busca.")

            embed = discord.Embed(title=f"🔍 Resultados: {termo}", color=discord.Color.blue())
            for res in results:
                body = res.get('body', '')[:150]
                embed.add_field(
                    name=res.get('title', 'Sem titulo')[:100],
                    value=f"{body}...\n[Link]({res.get('href', '#')})",
                    inline=False
                )
            await interaction.followup.send(embed=embed)
        except (aiohttp.ClientError, TimeoutError) as e:
            logger.error(f"Erro de conexão na pesquisa: {e}")
            await interaction.followup.send("❌ Erro de conexão na busca. Tente novamente em alguns instantes.")
        except Exception as e:
            logger.error(f"Erro inesperado na pesquisa: {e}", exc_info=True)
            await interaction.followup.send("❌ Erro na busca. Tente novamente.")

    @app_commands.command(name="ia", description="Perguntar para a IA")
    @app_commands.describe(pergunta="Sua pergunta para a IA")
    async def slash_ia(self, interaction: discord.Interaction, pergunta: str):
        if not Config.GROQ_KEY:
            return await interaction.response.send_message("❌ IA nao configurada (falta GROQ_KEY).", ephemeral=True)

        # Validar entrada
        pergunta = pergunta.strip()
        if not pergunta or len(pergunta) < MIN_IA_QUESTION_LENGTH:
            return await interaction.response.send_message(f"❌ Pergunta muito curta. Use pelo menos {MIN_IA_QUESTION_LENGTH} caracteres.", ephemeral=True)

        if len(pergunta) > MAX_IA_QUESTION_LENGTH:
            return await interaction.response.send_message(f"❌ Pergunta muito longa. Máximo {MAX_IA_QUESTION_LENGTH} caracteres.", ephemeral=True)

        if not self.check_cooldown(interaction.user.id, 'ia', 5):
            remaining = self.get_cooldown_remaining(interaction.user.id, 'ia', 5)
            return await interaction.response.send_message(f"⏳ Aguarde {remaining}s para perguntar novamente.", ephemeral=True)

        await interaction.response.defer()

        try:
            user_id = str(interaction.user.id)
            channel_id = str(interaction.channel.id) if interaction.channel else "unknown"

            weather_info = ""
            if self.is_weather_question(pergunta):
                cidade = self.extract_city_from_question(pergunta)
                if cidade:
                    weather_data = await self.get_weather(cidade)
                    if weather_data:
                        current = weather_data.get('current_condition', [{}])[0]
                        temp = current.get('temp_C', 'N/A')
                        humidity = current.get('humidity', 'N/A')
                        desc_list = current.get('lang_pt', current.get('weatherDesc', [{}]))
                        if isinstance(desc_list, list) and desc_list:
                            condition = desc_list[0].get('value', 'Desconhecido')
                        else:
                            condition = 'Desconhecido'

                        weather_info = f"\n\n=== DADOS DO CLIMA EM TEMPO REAL ({cidade}) ===\n"
                        weather_info += f"Temperatura: {temp}°C\n"
                        weather_info += f"Umidade: {humidity}%\n"
                        weather_info += f"Condição: {condition}\n"

                        weather = weather_data.get('weather', [])
                        if weather:
                            weather_info += "Previsão:\n"
                            for i, day in enumerate(weather[:3]):
                                max_temp = day.get('maxtempC', 'N/A')
                                min_temp = day.get('mintempC', 'N/A')
                                if i == 0:
                                    day_name = "Hoje"
                                elif i == 1:
                                    day_name = "Amanhã"
                                else:
                                    day_name = day.get('date', '')
                                weather_info += f"- {day_name}: {min_temp}°C a {max_temp}°C\n"
                        weather_info += "Use esses dados reais para responder sobre o clima.\n"

            user_history = self.chat_history.get(user_id, [])[-10:]
            channel_history = self.channel_history.get(channel_id, [])[-25:]

            # CORREÇÃO: Adicionar data/hora atual ao contexto para a IA saber o dia de hoje
            now_br = datetime.now(ZoneInfo("America/Sao_Paulo"))
            data_atual = now_br.strftime("%d/%m/%Y")
            hora_atual = now_br.strftime("%H:%M")
            dia_semana = ["Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado", "Domingo"][now_br.weekday()]

            context = Config.BOT_PERSONALITY + weather_info + "\n\n"
            context += "=== DATA E HORA ATUAL (BRASIL) ===\n"
            context += f"Data: {data_atual} ({dia_semana})\n"
            context += f"Hora: {hora_atual}\n"
            context += "Use essas informações para responder perguntas sobre a data/hora atual.\n\n"

            if channel_history:
                context += "=== HISTORICO RECENTE DO CANAL ===\n"
                for idx, h in enumerate(channel_history, 1):
                    context += f"{idx}. {h['usuario']}: \"{h['pergunta']}\"\n"
                context += "\n"

            if user_history:
                context += "=== SEU HISTORICO PESSOAL ===\n"
                for h in user_history:
                    context += f"Voce perguntou: \"{h['pergunta']}\"\nEu respondi: \"{h['resposta']}\"\n---\n"
                context += "\n"

            context += f"=== PERGUNTA ATUAL ===\n{interaction.user.display_name}: {pergunta}"

            txt = await self.ask_groq(context)
            if not txt:
                return await interaction.followup.send("❌ Erro ao conectar com a IA. Tenta de novo!")

            if user_id not in self.chat_history:
                self.chat_history[user_id] = []
            self.chat_history[user_id].append({'pergunta': pergunta, 'resposta': txt[:MAX_CHAT_HISTORY_SAVED]})
            if len(self.chat_history[user_id]) > MAX_HISTORY_PER_USER:
                self.chat_history[user_id] = self.chat_history[user_id][-MAX_HISTORY_PER_USER:]

            if channel_id not in self.channel_history:
                self.channel_history[channel_id] = []
            self.channel_history[channel_id].append({
                'usuario': interaction.user.display_name,
                'pergunta': pergunta[:MAX_CHAT_HISTORY_SAVED],
                'timestamp': datetime.now().isoformat(),
                'user_id': interaction.user.id
            })

            self.save_chat_history()
            self.save_channel_history()

            if len(txt) > MAX_IA_RESPONSE_LENGTH:
                for i in range(0, len(txt), MAX_IA_CHUNK_SIZE):
                    if i == 0:
                        await interaction.followup.send(txt[i:i+MAX_IA_CHUNK_SIZE])
                    else:
                        if isinstance(interaction.channel, (discord.TextChannel, discord.Thread, discord.DMChannel)):
                            await interaction.channel.send(txt[i:i+MAX_IA_CHUNK_SIZE])
                        else:
                            # Se não for um canal que suporta send, envia via followup
                            await interaction.followup.send(txt[i:i+MAX_IA_CHUNK_SIZE])
            else:
                await interaction.followup.send(txt)
        except Exception as e:
            logger.error(f"Erro na IA: {e}")
            await interaction.followup.send("❌ Ops, deu um erro na IA. Tenta de novo!")

    @app_commands.command(name="calma", description="Receber uma mensagem de suporte")
    async def slash_calma(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="💜 Realidade",
            description=f"*{random.choice(SUPPORT_MESSAGES)}*",
            color=discord.Color.dark_red()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="ajuda", description="Ver lista de comandos do bot")
    async def slash_ajuda(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📚 Comandos do Bot NextCompany",
            description="Use `/comando` ou `!comando` para executar",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="🛠️ Utilidades",
            value="`/status` - Status do sistema\n`/pesquisar` - Buscar na web\n`/ia` - Perguntar para IA\n`/clima` - Previsão do tempo\n`/sorteio` - Sortear pessoa\n`/calma` - Mensagem de suporte",
            inline=False
        )

        embed.add_field(
            name="🎫 Desk Manager",
            value="`/desk-ajuda` ou `/desk-help` - Ver todos os comandos do Desk Manager",
            inline=False
        )

        embed.add_field(
            name="📊 Outros Comandos",
            value="Use `!help` para ver todos os comandos prefix (com !)\nAlguns comandos só estão disponíveis como prefix: `!tempo`, `!lembrete`, `!feriados`, etc.",
            inline=False
        )

        embed.set_footer(text="NextCompany Bot - Use /ajuda ou !help para ver esta lista")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="help", description="Ver lista de comandos do bot (alias de /ajuda)")
    async def slash_help(self, interaction: discord.Interaction):
        """Alias para /ajuda - chama a mesma função"""
        await self.slash_ajuda(interaction)  # type: ignore[misc]


async def setup(bot):
    cog = ToolsCog(bot)
    await bot.add_cog(cog)

    # Tarefa periódica para limpar cooldowns antigos (a cada hora)
    async def cleanup_cooldowns():
        await bot.wait_until_ready()
        while not bot.is_closed():
            try:
                await asyncio.sleep(3600)  # 1 hora
                removed = cog.cooldown_manager.cleanup_old_cooldowns(max_age_seconds=3600)
                if removed > 0:
                    logger.debug(f"Limpeza de cooldowns: {removed} entradas antigas removidas")
            except Exception as e:
                logger.error(f"Erro na limpeza de cooldowns: {e}", exc_info=True)

    bot.loop.create_task(cleanup_cooldowns())
