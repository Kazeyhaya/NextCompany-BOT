"""
Cooldown Manager for Discord Bot Commands

Manages cooldowns for user commands to prevent spam and abuse.
"""
import time
from typing import Dict, Tuple


class CooldownManager:
    """
    Manages cooldowns for commands per user.

    Tracks when users last executed commands and prevents
    them from using commands too frequently.
    """

    def __init__(self):
        """Initialize the cooldown manager with an empty cooldown dictionary."""
        # Structure: {(user_id, command): timestamp}
        self.cooldowns: Dict[Tuple[int, str], float] = {}

    def check_cooldown(self, user_id: int, command: str, seconds: int) -> bool:
        """
        Check if a user can execute a command (cooldown expired).

        Args:
            user_id: The Discord user ID
            command: The command name
            seconds: The cooldown duration in seconds

        Returns:
            True if the user can execute the command (cooldown expired or doesn't exist),
            False if the user is still on cooldown
        """
        key = (user_id, command)
        current_time = time.time()

        if key not in self.cooldowns:
            # No cooldown exists, user can execute
            self.cooldowns[key] = current_time
            return True

        last_used = self.cooldowns[key]
        elapsed = current_time - last_used

        if elapsed >= seconds:
            # Cooldown expired, update timestamp and allow
            self.cooldowns[key] = current_time
            return True

        # Still on cooldown
        return False

    def get_cooldown_remaining(self, user_id: int, command: str,
                               seconds: int) -> int:
        """
        Get the remaining cooldown time in seconds.

        Args:
            user_id: The Discord user ID
            command: The command name
            seconds: The cooldown duration in seconds

        Returns:
            The remaining cooldown time in seconds (0 if no cooldown or expired)
        """
        key = (user_id, command)
        current_time = time.time()

        if key not in self.cooldowns:
            return 0

        last_used = self.cooldowns[key]
        elapsed = current_time - last_used

        if elapsed >= seconds:
            return 0

        remaining = int(seconds - elapsed) + 1  # +1 to round up
        return remaining

    def cleanup_old_cooldowns(self, max_age_seconds: int) -> int:
        """
        Remove cooldown entries older than the specified age.

        This helps prevent memory leaks by cleaning up old cooldown data
        that is no longer needed.

        Args:
            max_age_seconds: Maximum age in seconds for cooldown entries to keep

        Returns:
            Number of cooldown entries removed
        """
        current_time = time.time()
        keys_to_remove = []

        for key, timestamp in self.cooldowns.items():
            age = current_time - timestamp
            if age > max_age_seconds:
                keys_to_remove.append(key)

        for key in keys_to_remove:
            del self.cooldowns[key]

        return len(keys_to_remove)
