import os
import json
import logging
from typing import Any, Union, Dict, Optional
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# Cache simples para dados JSON (TTL de 5 minutos)
_cache: Dict[str, tuple] = {}  # {filename: (data, timestamp)}


class JsonDatabase:
    CACHE_TTL = 300  # 5 minutos em segundos

    @staticmethod
    def load(filename: str,
             default: Any = None,
             use_cache: bool = True) -> Any:
        """Carrega arquivo JSON com cache opcional."""
        if default is None:
            default = {}

        # Verificar cache
        if use_cache and filename in _cache:
            data, timestamp = _cache[filename]
            if (datetime.now() -
                    timestamp).total_seconds() < JsonDatabase.CACHE_TTL:
                return data

        try:
            if os.path.exists(filename):
                with open(filename, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # Atualizar cache
                    if use_cache:
                        _cache[filename] = (data, datetime.now())
                    return data
        except Exception as e:
            logger.error(f"Erro ao carregar {filename}: {e}", exc_info=True)

        JsonDatabase.save(filename, default, use_cache=False)
        if use_cache:
            _cache[filename] = (default, datetime.now())
        return default

    @staticmethod
    def save(filename: str,
             data: Union[dict, list],
             use_cache: bool = True) -> bool:
        """Salva dados em arquivo JSON e atualiza cache."""
        try:
            # Criar backup antes de salvar (apenas se arquivo existe)
            if os.path.exists(filename):
                backup_name = f"{filename}.backup"
                try:
                    with open(filename, "r", encoding="utf-8") as src:
                        with open(backup_name, "w", encoding="utf-8") as dst:
                            dst.write(src.read())
                except Exception:
                    pass  # Ignorar erros de backup

            with open(filename, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            # Atualizar cache
            if use_cache:
                _cache[filename] = (data, datetime.now())

            return True
        except Exception as e:
            logger.error(f"Erro ao salvar {filename}: {e}", exc_info=True)
            return False

    @staticmethod
    def clear_cache(filename: Optional[str] = None) -> None:
        """Limpa cache de um arquivo específico ou de todos."""
        if filename:
            _cache.pop(filename, None)
        else:
            _cache.clear()
