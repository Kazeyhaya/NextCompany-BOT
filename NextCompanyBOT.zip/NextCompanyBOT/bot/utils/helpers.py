from datetime import timedelta
import re


def fix_text(texto):
    """Corrige encoding de texto usando múltiplas estratégias agressivas."""
    if not texto:
        return ""

    texto_str = str(texto)
    original = texto_str

    # Estratégia 1: Detectar e corrigir UTF-8 mal interpretado como latin-1
    # Este é o caso mais comum: texto UTF-8 foi lido como latin-1
    try:
        if any(ord(c) > 127 for c in texto_str):
            # Tentar: texto está como string latin-1, mas deveria ser UTF-8
            # Codificar como latin-1 (para obter bytes) e decodificar como UTF-8
            fixed = texto_str.encode('latin-1',
                                     errors='ignore').decode('utf-8',
                                                             errors='ignore')
            if fixed and fixed != texto_str and len(fixed) > 0:
                # Verificar se melhorou (menos caracteres estranhos)
                if not any(
                        ord(c) in range(128, 160)
                        for c in fixed if ord(c) < 256):
                    texto_str = fixed
    except (UnicodeEncodeError, UnicodeDecodeError, AttributeError):
        pass

    # Estratégia 2: Tentar cp1252 -> utf-8
    try:
        if any(ord(c) > 127 for c in texto_str):
            fixed = texto_str.encode('cp1252',
                                     errors='ignore').decode('utf-8',
                                                             errors='ignore')
            if fixed and fixed != texto_str and len(fixed) > 0:
                if not any(
                        ord(c) in range(128, 160)
                        for c in fixed if ord(c) < 256):
                    texto_str = fixed
    except (UnicodeEncodeError, UnicodeDecodeError, AttributeError):
        pass

    # Estratégia 3: Corrigir padrões mojibake específicos (mais completo)
    # Aplicar correções em ordem específica para evitar conflitos
    # Primeiro: padrões duplos (mais específicos)
    mojibake_fixes_duplos = {
        'InteraÃ§Ã£o': 'Interação',
        'InteraÃ§ao': 'Interação',
        'ConfiguraÃ§Ã£o': 'Configuração',
        'ConfiguraÃ§ao': 'Configuração',
        'InformaÃ§Ã£o': 'Informação',
        'InformaÃ§ao': 'Informação',
        'OrientaÃ§Ã£o': 'Orientação',
        'OrientaÃ§ao': 'Orientação',
        'InstalaÃ§Ã£o': 'Instalação',
        'InstalaÃ§ao': 'Instalação',
        'AtualizaÃ§Ã£o': 'Atualização',
        'AtualizaÃ§ao': 'Atualização',
    }

    for mojibake, correct in mojibake_fixes_duplos.items():
        texto_str = texto_str.replace(mojibake, correct)

    # Segundo: padrões simples (UTF-8 mal interpretado como latin-1)
    mojibake_fixes_simples = {
        'Ã§': 'ç',
        'Ã£': 'ã',
        'Ã¡': 'á',
        'Ã©': 'é',
        'Ã­': 'í',
        'Ã³': 'ó',
        'Ãº': 'ú',
        'Ã ': 'à',
        'Ãª': 'ê',
        'Ã´': 'ô',
    }

    for mojibake, correct in mojibake_fixes_simples.items():
        texto_str = texto_str.replace(mojibake, correct)

    # Terceiro: caracteres maiúsculos (aplicar via regex para evitar duplicatas)
    # Estes são bytes específicos que aparecem como 'Ã' + byte
    mojibake_maiusculos = [
        (b'\xc3\x80'.decode('latin-1'), 'À'),  # Ã seguido de byte 0x80
        (b'\xc3\x81'.decode('latin-1'), 'Á'),  # Ã seguido de byte 0x81
        (b'\xc3\x82'.decode('latin-1'), 'Â'),  # Ã seguido de byte 0x82
        (b'\xc3\x83'.decode('latin-1'), 'Ã'),  # Ã seguido de byte 0x83
        (b'\xc3\x89'.decode('latin-1'), 'É'),  # Ã seguido de byte 0x89
        (b'\xc3\x8a'.decode('latin-1'), 'Ê'),  # Ã seguido de byte 0x8a
        (b'\xc3\x8d'.decode('latin-1'), 'Í'),  # Ã seguido de byte 0x8d
        (b'\xc3\x93'.decode('latin-1'), 'Ó'),  # Ã seguido de byte 0x93
        (b'\xc3\x94'.decode('latin-1'), 'Ô'),  # Ã seguido de byte 0x94
        (b'\xc3\x95'.decode('latin-1'), 'Õ'),  # Ã seguido de byte 0x95
        (b'\xc3\x9a'.decode('latin-1'), 'Ú'),  # Ã seguido de byte 0x9a
        (b'\xc3\x9c'.decode('latin-1'), 'Ü'),  # Ã seguido de byte 0x9c
        (b'\xc3\x87'.decode('latin-1'), 'Ç'),  # Ã seguido de byte 0x87
    ]

    for mojibake, correct in mojibake_maiusculos:
        texto_str = texto_str.replace(mojibake, correct)

    # Estratégia 4: Correções contextuais de palavras comuns (ANTES da regex)
    # Isso previne que palavras conhecidas sejam corrompidas pela regex
    # IMPORTANTE: Ordem importa! Palavras mais específicas primeiro
    # Aplicar em ordem específica para evitar conflitos
    word_fixes_pre_list = [
        # Primeiro: palavras que terminam com "acao" (mais comum)
        ('Atualizacao', 'Atualização'),
        ('Configuracao', 'Configuração'),
        ('Informacao', 'Informação'),
        ('Orientacao', 'Orientação'),
        ('Instalacao', 'Instalação'),
        ('Aplicacao', 'Aplicação'),
        ('Implementacao', 'Implementação'),
        ('Execucao', 'Execução'),
        ('Emissao', 'Emissão'),
        ('Emisso', 'Emissão'),  # Corrigir se já foi corrompido
        ('Interacao', 'Interação'),
        ('Interao', 'Interação'),  # Corrigir se já foi corrompido
        ('Intero',
         'Interação'),  # Caso específico: "Sem Intero" → "Sem Interação"
        # Depois: palavras que já foram corrompidas (terminam com "aco" ou "ão")
        ('Atualizaco', 'Atualização'),
        ('Configuraco', 'Configuração'),
        ('Configurão', 'Configuração'),  # Corrigir 'ão' para 'ção'
        ('Informaco', 'Informação'),
        ('Orientaco', 'Orientação'),
        ('Instalaco', 'Instalação'),
        # Correções específicas para palavras comuns que podem ser corrompidas
        ('Validato', 'Validação'),
        ('Validão', 'Validação'),
        ('Validac', 'Validação'),
        # Depois: palavras com "ao" no meio
        ('Relatorios', 'Relatórios'),
        ('Relatorio', 'Relatório'),
        ('Relatrios', 'Relatórios'),  # Corrigir se já foi corrompido
        ('Rotatrios',
         'Relatórios'),  # Corrigir se foi corrompido de forma estranha
        # Padrões com mojibake duplo
        ('AtualizaÃ§Ã£o', 'Atualização'),
        ('AtualizaÃ§ao', 'Atualização'),
        ('EmissaÃ§Ã£o', 'Emissão'),
        ('EmissaÃ§ao', 'Emissão'),
        # Corrigir também variações com espaços
        (' e Relatorios', ' e Relatórios'),
        (' e Relatorio', ' e Relatório'),
        (' e Relatrios', ' e Relatórios'),
        # Correção específica para nome de cliente
        ('GRo EM GRo', 'Grão em Grão'),
        ('GRo em GRo', 'Grão em Grão'),
        ('gro em gro', 'Grão em Grão'),
        ('Gro em Gro', 'Grão em Grão'),
        ('GRo EM GRo -', 'Grão em Grão -'),
        ('GRo em GRo -', 'Grão em Grão -'),
        ('gro em gro -', 'Grão em Grão -'),
        ('Gro em Gro -', 'Grão em Grão -'),
    ]

    for wrong, correct in word_fixes_pre_list:
        # Usar replace simples (mais rápido e confiável)
        texto_str = texto_str.replace(wrong, correct)
        # Também usar regex com word boundary para garantir
        texto_str = re.sub(r'\b' + re.escape(wrong) + r'\b',
                           correct,
                           texto_str,
                           flags=re.IGNORECASE)

    # Estratégia 5: Correção por regex para padrões comuns de palavras
    # "ao" no final de palavras geralmente deveria ser "ão"
    # Mas NÃO aplicar em palavras que já foram corrigidas acima
    palavras_protegidas = [
        'relat', 'relatóri', 'atualiz', 'configur', 'inform', 'orient',
        'instal', 'aplic', 'implement', 'execu', 'emiss', 'intera'
    ]

    def corrigir_ao(match):
        palavra_completa = match.group(0).lower()
        # Proteger palavras que já foram corrigidas ou que não devem ser alteradas
        for protegida in palavras_protegidas:
            if protegida in palavra_completa:
                return match.group(0)  # Não alterar
        return match.group(1) + 'ão' + (match.group(2)
                                        if len(match.groups()) > 1 else '')

    texto_str = re.sub(r'([a-záéíóúàêô])ao\b',
                       corrigir_ao,
                       texto_str,
                       flags=re.IGNORECASE)
    texto_str = re.sub(r'([a-záéíóúàêô])ao([A-Z])', corrigir_ao, texto_str)

    # Estratégia 6: Correções contextuais de palavras comuns (após regex)
    word_fixes = {
        'Interao': 'Interação',
        'Configurao': 'Configuração',
        'Configurão': 'Configuração',  # Corrigir 'ão' para 'ção' em Configuração
        'Informao': 'Informação',
        'Orientao': 'Orientação',
        'Instalao': 'Instalação',
        'Atualizao': 'Atualização',
        'Aplicao': 'Aplicação',
        'Implementao': 'Implementação',
        'Execuao': 'Execução',
        'Relatrios': 'Relatórios',  # Corrigir se ainda foi corrompido
        'Rotatrios':
        'Relatórios',  # Corrigir se foi corrompido de forma estranha
    }

    for wrong, correct in word_fixes.items():
        texto_str = re.sub(r'\b' + re.escape(wrong) + r'\b',
                           correct,
                           texto_str,
                           flags=re.IGNORECASE)

    # Estratégia 6.5: Correção GENÉRICA para palavras que terminam em "ão" mas deveriam ser "ção"
    # Esta regra detecta automaticamente padrões comuns sem precisar listar cada palavra

    # IMPORTANTE: Lista de palavras que terminam CORRETAMENTE em "ão" e NÃO devem ser alteradas
    palavras_corretas_com_ao = [
        'emissão', 'missão', 'sessão', 'pressão', 'expressão', 'impressão',
        'profissão', 'discussão', 'permissão', 'admissão', 'transmissão',
        'opressão', 'repressão', 'depressão', 'agressão', 'progressão',
        'regressão', 'digressão', 'obsessão', 'possessão', 'cessão',
        'concessão', 'recessão', 'processão', 'sucessão', 'ascensão',
        'descensão', 'ascensão', 'extensão', 'tensão', 'intenção',
        'atenção', 'retenção', 'detenção', 'manutenção', 'sustentação',
        'alimentação', 'complementação', 'suplementação', 'fermentação',
        'documentação', 'argumentação', 'comentário', 'inventário',
        'salário', 'voluntário', 'contrário', 'necessário', 'ordinário',
        'extraordinário', 'temporário', 'solário', 'diário', 'aniversário'
    ]

    # Lista de prefixos que SEMPRE devem terminar em 'ção' (não 'ão')
    # NOTA: Removido 'emiss' porque "Emissão" é a forma correta
    prefixos_que_terminam_em_cao = [
        'configur', 'atualiz', 'inform', 'orient', 'instal', 
        'aplic', 'implement', 'execu', 'intera',
        'comunic', 'organiz', 'especializ', 'generaliz',
        'personaliz', 'visualiz', 'finaliz', 'inicializ',
        'normaliz', 'otimiz', 'prioriz', 'realiz', 'utiliz',
        'criac', 'publicac', 'verificac', 'modificac', 'identificac',
        'classificac', 'qualificac', 'quantificac', 'notificac',
        'certificac', 'justificac', 'especificac', 'simplificac',
        'valid', 'autentic', 'autoriz', 'capacit', 'complet',
        'confirm', 'consult', 'contempl', 'demonstr', 'document',
        'estabelec', 'formul', 'habilit', 'indic', 'justific',
        'localiz', 'mencion', 'negoci', 'operacion', 'posicion',
        'prepar', 'present', 'process', 'program', 'projet',
        'proporcion', 'protej', 'public', 'qualific', 'quantific',
        'ratific', 'reconhec', 'registr', 'regulament', 'relacion',
        'represent', 'requisit', 'selecion', 'situ', 'solicit',
        'substitu', 'supervis', 'transmit', 'transport', 'trat'
    ]

    def corrigir_ao_para_cao(match):
        """Corrige palavras que terminam em 'ão' mas deveriam terminar em 'ção'"""
        palavra_completa = match.group(0)
        palavra_lower = palavra_completa.lower()

        # PRIMEIRO: Verificar se a palavra já está correta (não deve ser alterada)
        if palavra_lower in palavras_corretas_com_ao:
            return palavra_completa  # Retornar original sem alterar

        # Verificar se a palavra (sem o 'ão' final) corresponde a um prefixo conhecido
        palavra_sem_ao = palavra_lower[:-2]  # Remove 'ão'

        for prefixo in prefixos_que_terminam_em_cao:
            if palavra_sem_ao.endswith(prefixo):
                # Manter capitalização original
                if palavra_completa[0].isupper():
                    return palavra_completa[:-2].capitalize() + 'ação'
                return palavra_completa[:-2] + 'ação'

        # Se não encontrou padrão, retornar original
        return palavra_completa

    # Aplicar correção genérica: detecta palavras terminadas em "ão" que deveriam ser "ção"
    # Busca palavras que terminam em "ão" e verifica se o prefixo está na lista
    texto_str = re.sub(
        r'\b([A-Za-záéíóúàêô]{4,})ão\b',
        corrigir_ao_para_cao,
        texto_str,
        flags=re.IGNORECASE
    )

    # Correção adicional: palavras terminadas em "ato" que deveriam ser "ação"
    # Exemplo: "Validato" -> "Validação"
    def corrigir_ato_para_cao(match):
        """Corrige palavras que terminam em 'ato' mas deveriam terminar em 'ação'"""
        palavra_completa = match.group(0)
        palavra_lower = palavra_completa.lower()

        # Verificar se seria uma palavra que termina corretamente em "ão" (não "ação")
        # Exemplo: "Emissato" não existe, mas se existisse, não deveria virar "Emissação"
        # porque "Emissão" é a forma correta
        palavra_como_ao = palavra_lower[:-1] + 'ão'  # Transforma "ato" em "ão"
        if palavra_como_ao in palavras_corretas_com_ao:
            # Se a palavra com "ão" está na lista de corretas, não corrigir
            return palavra_completa

        palavra_sem_ato = palavra_lower[:-3]  # Remove 'ato'

        for prefixo in prefixos_que_terminam_em_cao:
            if palavra_sem_ato.endswith(prefixo):
                # Manter capitalização original
                if palavra_completa[0].isupper():
                    return palavra_completa[:-3].capitalize() + 'ação'
                return palavra_completa[:-3] + 'ação'

        return palavra_completa

    texto_str = re.sub(
        r'\b([A-Za-záéíóúàêô]{4,})ato\b',
        corrigir_ato_para_cao,
        texto_str,
        flags=re.IGNORECASE
    )

    # Estratégia 7: Se ainda tem caracteres problemáticos, tentar recodificação forçada
    if any(ord(c) in range(128, 160) for c in texto_str if ord(c) < 256):
        try:
            bytes_str = texto_str.encode('latin-1', errors='ignore')
            texto_str = bytes_str.decode('utf-8', errors='ignore')
        except (UnicodeEncodeError, UnicodeDecodeError, AttributeError):
            pass

    # Estratégia 8: Correções finais para padrões comuns que podem ter passado despercebidos
    correcoes_finais = {
        # Padrões de mojibake que podem ter passado
        'Ã§': 'ç',
        'Ã£': 'ã',
        'Ã¡': 'á',
        'Ã©': 'é',
        'Ã­': 'í',
        'Ã³': 'ó',
        'Ãº': 'ú',
        'Ã ': 'à',
        'Ãª': 'ê',
        'Ã´': 'ô',
        # Padrões duplos que podem ter passado
        'Ã§Ã£o': 'ção',
        'Ã§ao': 'ção',
        'Ã£o': 'ão',
        # Palavras comuns que podem ter sido corrompidas
        'Interacao': 'Interação',
        'Configuracao': 'Configuração',
        'Atualizacao': 'Atualização',
        'Informacao': 'Informação',
        'Orientacao': 'Orientação',
        'Instalacao': 'Instalação',
        'Emissao': 'Emissão',
        'Conexao': 'Conexão',
        'Duvida': 'Dúvida',
        'Relatorios': 'Relatórios',
        'Relatorio': 'Relatório',
        # Correção específica para nome de cliente
        'GRo EM GRo': 'Grão em Grão',
        'GRo em GRo': 'Grão em Grão',
        'GRo EM GRo -': 'Grão em Grão -',
        'GRo em GRo -': 'Grão em Grão -',
    }

    for errado, correto in correcoes_finais.items():
        texto_str = texto_str.replace(errado, correto)
        # Também tentar com maiúsculas
        texto_str = texto_str.replace(errado.upper(), correto.upper())
        # E com primeira letra maiúscula
        if errado and correto:
            texto_str = texto_str.replace(errado.capitalize(), correto.capitalize())

    # Correção específica para "GRo EM GRo" -> "Grão em Grão" (case-insensitive)
    # Usar regex para capturar todas as variações de capitalização, incluindo com texto adicional depois
    # Primeiro: capturar quando está isolado (com word boundary)
    texto_str = re.sub(
        r'\b([Gg][Rr][Oo])\s+([Ee][Mm])\s+([Gg][Rr][Oo])\b',
        r'Grão em Grão',
        texto_str,
        flags=re.IGNORECASE
    )
    # Segundo: capturar quando há hífen e texto depois (sem word boundary no final)
    texto_str = re.sub(
        r'\b([Gg][Rr][Oo])\s+([Ee][Mm])\s+([Gg][Rr][Oo])(\s*-\s*)',
        r'Grão em Grão\4',
        texto_str,
        flags=re.IGNORECASE
    )

    # Se nada funcionou, retornar o original (melhor que string vazia)
    if not texto_str:
        return original

    return texto_str


def get_protocolo(data):
    campos = ['chamado', 'chave', 'protocolo', 'TicketID']
    for campo in campos:
        valor = str(data.get(campo, ''))
        if '-' in valor and len(valor) > 5:
            return valor
    return data.get('chamado_cod', 'N/A')


def format_time_delta(dt: timedelta) -> str:
    total_seconds = int(dt.total_seconds())
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    return f"{hours}h e {minutes}m"


def parse_time_input(tempo: str) -> int:
    total_minutes = 0
    tempo_lower = tempo.lower()

    if 'h' in tempo_lower:
        parts = tempo_lower.split('h')
        total_minutes += int(parts[0]) * 60
        if len(parts) > 1 and parts[1]:
            min_part = parts[1].replace('m', '')
            if min_part:
                total_minutes += int(min_part)
    elif 'm' in tempo_lower:
        total_minutes = int(tempo_lower.replace('m', ''))
    else:
        total_minutes = int(tempo_lower)

    return total_minutes
