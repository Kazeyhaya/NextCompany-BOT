import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import ssl
import certifi
import logging

from .config import Config

logger = logging.getLogger(__name__)


class WorkBot(commands.Bot):

    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(command_prefix='!',
                         intents=intents,
                         help_command=None)
        self.session = None
        self.synced = False

    async def setup_hook(self):
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_context,
                                         limit=100,
                                         limit_per_host=30,
                                         enable_cleanup_closed=True)
        timeout = aiohttp.ClientTimeout(total=30, connect=10, sock_read=20)
        self.session = aiohttp.ClientSession(connector=connector,
                                             timeout=timeout,
                                             headers={
                                                 "User-Agent":
                                                 "NextCompanyBot/1.0",
                                                 "Accept": "application/json"
                                             })

        cogs = [
            'bot.cogs.schedule', 'bot.cogs.tools', 'bot.cogs.deskmanager',
            'bot.cogs.desk'
        ]

        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"✅ Cog carregado: {cog}")
            except ImportError as e:
                logger.error(f"❌ Erro de importação ao carregar {cog}: {e}")
            except SyntaxError as e:
                logger.error(f"❌ Erro de sintaxe em {cog}: {e}")
            except Exception as e:
                logger.error(f"❌ Erro ao carregar {cog}: {e}", exc_info=True)

    async def on_ready(self):
        logger.info(f"Bot conectado como {self.user}")
        logger.info(f"Servidores: {len(self.guilds)}")

        if not self.synced:
            try:
                synced = await self.tree.sync()
                self.synced = True
                logger.info(
                    f"Comandos slash sincronizados: {len(synced)} comandos")
            except Exception as e:
                logger.error(f"Erro ao sincronizar comandos slash: {e}")

    async def on_command_error(self, ctx: commands.Context,
                               error: commands.CommandError):
        """Tratar erros de comandos"""
        if isinstance(error, commands.CommandNotFound):
            # Ignorar erros de comando não encontrado silenciosamente
            # (pode acontecer durante inicialização ou com comandos inválidos)
            return
        # Para outros erros, logar normalmente
        logger.error(f"Erro no comando {ctx.command}: {error}", exc_info=error)

    async def close(self):
        if self.session:
            await self.session.close()
        await super().close()
